# Dynamic QR Personal Domain Web Resolver & Redirector

This website is the public-facing web resolver for your dynamic QR codes. When physical QR codes are generated in the mobile app, they point to:
`https://qr-redirector-xb5h.onrender.com/r/{SERIAL_NUMBER}`
(No `/review?sn=` is appended to the link)

## Features
- **Strict Coordinates Navigation:** The "Open in Google Maps / Navigate" button strictly uses only `latitude` and `longitude` (`https://www.google.com/maps/search/?api=1&query=${lat},${lng}`) and never the place name.
- **Direct WhatsApp Messaging:** 1-tap "Send WhatsApp Message" button opens WhatsApp directly with a prefilled message referencing the serial number and coordinate Google Maps link.
- **In-Browser Camera Scanner:** Visitors can scan physical QR stickers using their mobile/desktop camera directly on the web.
- **Android App Deep Linking:** Includes 1-tap launch into the Android app via `dynamicqr://tag/{serial}`.
- **Data Sync:** Import/Export JSON tags database directly between the Android app and this website.

## How to Link to Your Personal Domain

### Option 1: Cloudflare Pages / Vercel / Netlify (Recommended - 2 Minutes)
1. Upload the `index.html` file from this folder.
2. Under your project settings, click **Custom Domains**.
3. Add your domain (e.g. `qr.yourdomain.com` or `yourdomain.com`).
4. Follow the automatic DNS instructions (add CNAME record).

### Option 2: GitHub Pages
1. Push this folder to a GitHub repository.
2. In Repository Settings > **Pages**, select **Deploy from Branch**.
3. Add your custom domain under **Custom domain** and configure your DNS `CNAME` record.

### Option 3: Apache / Nginx / Node / Web Server
Place `index.html` in your web server's document root (e.g. `/var/www/html/`).

#### Nginx Configuration (to route `/r/:serial` to `index.html`):
```nginx
server {
    server_name yourdomain.com;
    root /var/www/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## Configure in the Android App
1. Open the Android application.
2. Tap the **Globe** icon in the header (Personal Domain Settings).
3. Enter your domain: `https://yourdomain.com`.
4. Tap **Save & Apply Domain**.
5. All newly generated dynamic QR codes and sticker tags will now automatically point to your personal domain!
