package com.example

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ReviewStandRepository
import com.example.ui.screens.ReviewStandApp
import com.example.ui.theme.DynamicQrTheme
import com.example.ui.viewmodel.AppMode
import com.example.ui.viewmodel.ReviewStandViewModel
import com.example.util.NfcLinkingHelper
import com.example.util.NfcWriteResult
import com.example.util.SerialGenerator

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var pendingIntent: PendingIntent? = null
    private var latestIntent by mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        latestIntent = intent

        if (BuildConfig.RENDER_BACKEND_URL.startsWith("http") &&
            !BuildConfig.RENDER_BACKEND_URL.contains("YOUR-EXACT-RENDER-URL", ignoreCase = true)
        ) {
            SerialGenerator.customDomain = BuildConfig.RENDER_BACKEND_URL
        }

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        val intentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val nfcIntent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        pendingIntent = PendingIntent.getActivity(this, 0, nfcIntent, intentFlags)

        setContent {
            DynamicQrTheme {
                val viewModel: ReviewStandViewModel = viewModel(
                    factory = ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                )

                LaunchedEffect(latestIntent) {
                    handleIncomingIntent(latestIntent, viewModel)
                }

                ReviewStandApp(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        nfcAdapter?.let { adapter ->
            if (adapter.isEnabled && pendingIntent != null) {
                val filters = arrayOf(
                    IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED).apply { addCategory(Intent.CATEGORY_DEFAULT) },
                    IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED)
                )
                try {
                    adapter.enableForegroundDispatch(this, pendingIntent, filters, null)
                } catch (_: Exception) {
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            nfcAdapter?.disableForegroundDispatch(this)
        } catch (_: Exception) {
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        latestIntent = intent
    }

    private fun handleIncomingIntent(intent: Intent?, viewModel: ReviewStandViewModel) {
        if (intent == null) return

        // 1. Check NFC tag discovery (write pending tag or scan stand URL)
        if (intent.action == NfcAdapter.ACTION_NDEF_DISCOVERED ||
            intent.action == NfcAdapter.ACTION_TAG_DISCOVERED ||
            intent.action == NfcAdapter.ACTION_TECH_DISCOVERED
        ) {
            val tag: Tag? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(NfcAdapter.EXTRA_TAG) as? Tag
            }
            if (tag != null) {
                if (NfcLinkingHelper.isWaitingForTag) {
                    val writeResult = NfcLinkingHelper.handleTagDetectedForWriting(tag)
                    if (writeResult is NfcWriteResult.Success) {
                        Toast.makeText(
                            this,
                            "NFC Tag Successfully Written (${writeResult.info.uid})",
                            Toast.LENGTH_LONG
                        ).show()
                    } else if (writeResult is NfcWriteResult.Failure) {
                        Toast.makeText(this, "NFC Write Failed: ${writeResult.message}", Toast.LENGTH_LONG).show()
                    }
                    return
                }

                val uidHex = NfcLinkingHelper.bytesToHex(tag.id)
                val readUrl = NfcLinkingHelper.readNdefUrl(tag)
                if (!readUrl.isNullOrBlank()) {
                    val slug = ReviewStandRepository.extractStandSlugFromUri(readUrl)
                        ?: SerialGenerator.extractSerialNumber(readUrl).lowercase()
                    if (slug.isNotBlank()) {
                        viewModel.openStandFromExternalLink(slug)
                        Toast.makeText(this, "NFC Stand Scanned: $slug", Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                Toast.makeText(this, "NFC Tag detected: $uidHex", Toast.LENGTH_SHORT).show()
            }
        }

        // 2. Check standard deep links (?s=, ?qr_id=, /r/<slug>, #owner)
        val uri = intent.data ?: return
        val fragment = uri.fragment.orEmpty().lowercase()
        if (fragment == "owner") {
            val loggedIn = viewModel.uiState.value.loggedInEmail != null
            viewModel.navigateTo(if (loggedIn) AppMode.DASHBOARD else AppMode.LOGIN)
            return
        }

        val slug = ReviewStandRepository.extractStandSlugFromUri(uri.toString())
        if (!slug.isNullOrBlank()) {
            viewModel.openStandFromExternalLink(slug)
        }
    }
}
