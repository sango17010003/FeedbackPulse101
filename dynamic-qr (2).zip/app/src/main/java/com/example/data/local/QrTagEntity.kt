package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "qr_tags",
    indices = [
        Index(value = ["serialNumber"], unique = true)
    ]
)
data class QrTagEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val serialNumber: String,
    val token: String,
    val batchName: String = "General Batch",
    val status: String = STATUS_UNLINKED, // "unlinked", "linked", "linked_location", "linked_weblink"
    
    // One-Time Shop Registration & Linking fields
    val shopName: String? = null,
    val whatsappNumber: String? = null,
    val instagramHandle: String? = null, // Instagram profile/handle e.g. @chahatsweets
    val googleReviewUrl: String? = null,
    val qrCountTaken: Int = 1,
    val moneyReceived: Double = 0.0,
    val currency: String = "₹",

    // NFC Tag Integration (Both QR Code & NFC open the exact same link)
    val nfcLinked: Boolean = false,
    val nfcTagUid: String? = null,
    val nfcLinkedAt: Long? = null,

    // Optional Location & Web details
    val title: String? = null,
    val address: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val destinationUrl: String? = null,
    val linkType: String? = null, // "google_maps", "custom_weblink", "trust_review"
    val notes: String? = null,
    val operatorName: String? = null,
    val contactName: String? = null,
    val contactPhone: String? = null,

    // Analytics & Timestamps
    val createdAt: Long = System.currentTimeMillis(),
    val linkedAt: Long? = null,
    val lastScannedAt: Long? = null,
    val scanCount: Int = 0,
    val positiveReviewsCount: Int = 0, // Reviews >= 9/15 stars redirected to Google
    val privateFeedbacksCount: Int = 0  // Reviews < 9/15 stars captured privately
) {
    val isLinked: Boolean
        get() = status == STATUS_LINKED || status == "linked_location" || status == "linked_weblink"

    val effectiveShopName: String
        get() = shopName?.takeIf { it.isNotBlank() }
            ?: title?.takeIf { it.isNotBlank() }
            ?: "Unassigned Shop"

    val effectiveWhatsApp: String?
        get() = whatsappNumber?.takeIf { it.isNotBlank() }
            ?: contactPhone?.takeIf { it.isNotBlank() }

    val effectiveWhatsAppChatUrl: String?
        get() {
            val phone = effectiveWhatsApp ?: return null
            val digits = phone.filter { it.isDigit() }
            return if (digits.isNotBlank()) "https://wa.me/$digits" else null
        }

    val effectiveInstagramUrl: String?
        get() {
            val raw = instagramHandle?.trim() ?: return null
            if (raw.isBlank()) return null
            return when {
                raw.startsWith("http://", ignoreCase = true) || raw.startsWith("https://", ignoreCase = true) -> raw
                raw.startsWith("@") -> "https://instagram.com/${raw.removePrefix("@")}"
                raw.contains("instagram.com", ignoreCase = true) -> "https://$raw"
                else -> "https://instagram.com/$raw"
            }
        }

    val hasInstagram: Boolean
        get() = !effectiveInstagramUrl.isNullOrBlank()

    val effectiveGoogleReviewUrl: String?
        get() = when {
            !googleReviewUrl.isNullOrBlank() && googleReviewUrl != "https://www.google.com/maps" -> googleReviewUrl
            !destinationUrl.isNullOrBlank() && destinationUrl != "https://www.google.com/maps" -> destinationUrl
            latitude != null && longitude != null -> "https://www.google.com/maps/search/?api=1&query=$latitude,$longitude&action=openreviews"
            !shopName.isNullOrBlank() -> {
                val query = listOfNotNull(shopName, address).joinToString(" ")
                "https://www.google.com/maps/search/?api=1&query=" + java.net.URLEncoder.encode(query, "UTF-8") + "&action=openreviews"
            }
            else -> effectiveMapUrl
        }

    val effectiveDirectWriteReviewUrl: String
        get() = com.example.util.GoogleReviewLinkHelper.getDirectWriteReviewUrl(
            urlOrInput = googleReviewUrl ?: destinationUrl ?: "",
            shopName = shopName ?: title
        )

    val hasContact: Boolean
        get() = !effectiveWhatsApp.isNullOrBlank()

    val isGoogleLocation: Boolean
        get() = status == STATUS_LINKED_LOCATION || (!googleReviewUrl.isNullOrBlank())

    val effectiveMapUrl: String?
        get() = when {
            latitude != null && longitude != null -> "https://www.google.com/maps/search/?api=1&query=$latitude,$longitude"
            !googleReviewUrl.isNullOrBlank() -> googleReviewUrl
            destinationUrl != null -> {
                val coords = com.example.util.LocationHelper.parseCoordinatesFromUrlOrText(destinationUrl)
                if (coords != null) {
                    "https://www.google.com/maps/search/?api=1&query=${coords.first},${coords.second}"
                } else {
                    destinationUrl
                }
            }
            else -> null
        }

    val displaySubtitle: String
        get() = when {
            isLinked -> {
                val phone = effectiveWhatsApp?.let { " · 📱 $it" } ?: ""
                "QRs: $qrCountTaken · Paid: $currency${"%.0f".format(moneyReceived)}$phone"
            }
            !address.isNullOrBlank() -> address
            else -> "Ready for one-time shop linking"
        }

    companion object {
        const val STATUS_UNLINKED = "unlinked"
        const val STATUS_LINKED = "linked"
        const val STATUS_LINKED_LOCATION = "linked_location"
        const val STATUS_LINKED_WEBLINK = "linked_weblink"
    }
}
