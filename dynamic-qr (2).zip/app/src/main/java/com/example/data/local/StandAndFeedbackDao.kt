package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface StandDao {
    @Query("SELECT * FROM qr_stands ORDER BY createdAt DESC")
    suspend fun getAllStands(): List<QrStandEntity>

    @Query("SELECT * FROM qr_stands WHERE LOWER(ownerEmail) = LOWER(:email) ORDER BY createdAt DESC")
    suspend fun getStandsByOwner(email: String): List<QrStandEntity>

    @Query("SELECT * FROM qr_stands WHERE LOWER(standSlug) = LOWER(:slug) LIMIT 1")
    suspend fun getStandBySlug(slug: String): QrStandEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStand(stand: QrStandEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStands(stands: List<QrStandEntity>)

    @Query("DELETE FROM qr_stands WHERE LOWER(ownerEmail) = LOWER(:email)")
    suspend fun deleteStandsByOwner(email: String)
}

@Dao
interface FeedbackDao {
    @Query("SELECT * FROM feedback_logs ORDER BY createdAt DESC")
    suspend fun getAllFeedback(): List<FeedbackLogEntity>

    @Query(
        """
        SELECT f.* FROM feedback_logs f
        INNER JOIN qr_stands s ON LOWER(f.standSlug) = LOWER(s.standSlug)
        WHERE LOWER(s.ownerEmail) = LOWER(:ownerEmail)
        ORDER BY f.createdAt DESC
        """
    )
    suspend fun getFeedbackForOwner(ownerEmail: String): List<FeedbackLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFeedback(feedback: FeedbackLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllFeedback(items: List<FeedbackLogEntity>)

    @Query("UPDATE feedback_logs SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("DELETE FROM feedback_logs WHERE LOWER(standSlug) IN (:standSlugs)")
    suspend fun deleteFeedbackForStands(standSlugs: List<String>)
}
