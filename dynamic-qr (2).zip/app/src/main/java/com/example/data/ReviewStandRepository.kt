package com.example.data

import android.content.Context
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.local.FeedbackLogEntity
import com.example.data.local.QrStandEntity
import com.example.data.local.QrTagEntity
import com.example.util.GoogleReviewLinkHelper
import com.example.util.SerialGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit

data class AuthSession(
    val email: String,
    val accessToken: String
)

data class CreateStandResult(
    val stand: QrStandEntity,
    val qrUrl: String,
    val extractorSource: String
)

data class ResolvedLinkPreview(
    val directUrl: String,
    val linkType: String,
    val source: String,
    val opensWriteReviewModal: Boolean = false
)

class ReviewStandRepository(context: Context) {

    private val appContext = context.applicationContext
    private val db: AppDatabase by lazy { AppDatabase.getInstance(appContext) }
    private val standDao by lazy { db.standDao() }
    private val feedbackDao by lazy { db.feedbackDao() }
    private val qrTagDao by lazy { db.qrTagDao() }
    private val prefs by lazy { appContext.getSharedPreferences("review_stand_auth", Context.MODE_PRIVATE) }

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private val jsonMediaType by lazy { "application/json; charset=utf-8".toMediaType() }

    val supabaseUrl: String
        get() = normalizeSupabaseBaseUrl(BuildConfig.SUPABASE_URL)

    val supabaseAnonKey: String
        get() = BuildConfig.SUPABASE_ANON_KEY.trim().trim('"', '\'', ' ')

    val renderBackendUrl: String
        get() = BuildConfig.RENDER_BACKEND_URL.trim().trim('"', '\'', ' ').trimEnd('/')

    val configuredAdminEmail: String
        get() = BuildConfig.ADMIN_EMAIL.trim().trim('"', '\'', ' ')

    fun isSupabaseConfigured(): Boolean {
        return supabaseUrl.startsWith("http") &&
            !supabaseUrl.contains("YOUR_PROJECT_REF", ignoreCase = true) &&
            supabaseAnonKey.isNotBlank() &&
            supabaseAnonKey != "YOUR_SUPABASE_ANON_KEY"
    }

    fun isRenderBackendConfigured(): Boolean {
        return renderBackendUrl.startsWith("http") &&
            !renderBackendUrl.contains("YOUR-EXACT-RENDER-URL", ignoreCase = true)
    }

    /**
     * Super Admin view access: true when ADMIN_EMAIL secret matches the logged-in user, OR
     * in Preview / Fallback Mode when logged in with the built-in Super Admin preview account.
     */
    fun isSuperAdmin(email: String?): Boolean {
        if (isConfiguredDirectoryOperator(email, configuredAdminEmail)) return true
        val token = prefs.getString(KEY_TOKEN, null).orEmpty()
        if ((!isSupabaseConfigured() || token == "demo-local-token") &&
            email?.trim().equals(DEMO_SUPER_ADMIN_EMAIL, ignoreCase = true)
        ) {
            return true
        }
        return false
    }

    fun hasDirectoryAccess(email: String?): Boolean = isSuperAdmin(email)

    fun observeAllLocalTags(): Flow<List<QrTagEntity>> = qrTagDao.getAllTags()

    fun getCurrentSession(): AuthSession? {
        val email = prefs.getString(KEY_EMAIL, null)?.takeIf { it.isNotBlank() } ?: return null
        val token = prefs.getString(KEY_TOKEN, null).orEmpty()
        return AuthSession(email = email, accessToken = token)
    }

    private fun saveSession(email: String, accessToken: String) {
        prefs.edit()
            .putString(KEY_EMAIL, email.trim())
            .putString(KEY_TOKEN, accessToken)
            .apply()
    }

    fun saveRegisteredOwnerName(email: String, ownerName: String, standSlug: String? = null) {
        val cleanName = ownerName.trim()
        if (cleanName.isBlank()) return
        val editor = prefs.edit()
        val cleanEmail = email.trim().lowercase(Locale.US)
        if (cleanEmail.isNotBlank()) {
            editor.putString("$KEY_OWNER_NAME_EMAIL_PREFIX$cleanEmail", cleanName)
        }
        val cleanStand = standSlug?.let { cleanSlug(it) }.orEmpty()
        if (cleanStand.isNotBlank()) {
            editor.putString("$KEY_OWNER_NAME_SLUG_PREFIX$cleanStand", cleanName)
        }
        editor.apply()
    }

    fun saveOwnerAgeProfile(email: String, isBelow18: Boolean, parentGuardianName: String) {
        val cleanEmail = email.trim().lowercase(Locale.US)
        if (cleanEmail.isBlank()) return
        prefs.edit()
            .putBoolean("$KEY_OWNER_BELOW18_EMAIL_PREFIX$cleanEmail", isBelow18)
            .putString("$KEY_OWNER_PARENT_EMAIL_PREFIX$cleanEmail", parentGuardianName.trim())
            .apply()
    }

    fun getRegisteredOwnerName(standSlug: String, ownerEmail: String): String {
        val cleanStand = cleanSlug(standSlug)
        if (cleanStand.isNotBlank()) {
            val bySlug = prefs.getString("$KEY_OWNER_NAME_SLUG_PREFIX$cleanStand", null)?.trim()
            if (!bySlug.isNullOrBlank()) return bySlug
        }
        val cleanEmail = ownerEmail.trim().lowercase(Locale.US)
        if (cleanEmail.isNotBlank()) {
            val byEmail = prefs.getString("$KEY_OWNER_NAME_EMAIL_PREFIX$cleanEmail", null)?.trim()
            if (!byEmail.isNullOrBlank()) return byEmail
        }
        return ""
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_EMAIL)
            .remove(KEY_TOKEN)
            .apply()
    }

    suspend fun fetchStand(standSlug: String): QrStandEntity? = withContext(Dispatchers.IO) {
        val cleanSlug = cleanSlug(standSlug)
        if (cleanSlug.isBlank()) return@withContext null

        if (isSupabaseConfigured()) {
            try {
                val encodedSlug = URLEncoder.encode(cleanSlug, "UTF-8")
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/qr_stands?stand_slug=eq.$encodedSlug&select=*")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.startsWith("[")) {
                        val arr = JSONArray(body)
                        if (arr.length() > 0) {
                            val stand = parseStandJson(arr.getJSONObject(0))
                            standDao.upsertStand(stand)
                            return@withContext stand
                        } else {
                            return@withContext null
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        ensureSeededLocally()
        val localStand = standDao.getStandBySlug(cleanSlug) ?: return@withContext null
        val enrichedOwner = localStand.ownerName.trim().ifBlank {
            getRegisteredOwnerName(localStand.standSlug, localStand.ownerEmail)
        }
        if (enrichedOwner != localStand.ownerName) {
            localStand.copy(ownerName = enrichedOwner)
        } else {
            localStand
        }
    }

    suspend fun submitNegativeFeedback(
        standSlug: String,
        shopName: String,
        totalScore: Int,
        customerPhone: String?,
        customerComment: String
    ): Result<FeedbackLogEntity> = withContext(Dispatchers.IO) {
        val cleanPhone = customerPhone?.trim()?.takeIf { it.isNotBlank() }
        val cleanComment = customerComment.trim()
        val entry = FeedbackLogEntity(
            id = UUID.randomUUID().toString(),
            standSlug = cleanSlug(standSlug),
            shopName = shopName.trim(),
            totalScore = totalScore,
            customerPhone = cleanPhone,
            customerComment = cleanComment,
            status = FeedbackLogEntity.STATUS_PENDING,
            createdAt = System.currentTimeMillis()
        )

        if (isSupabaseConfigured()) {
            try {
                val payload = JSONObject().apply {
                    put("stand_slug", entry.standSlug)
                    put("shop_name", entry.shopName)
                    put("total_score", entry.totalScore)
                    put("customer_phone", entry.customerPhone ?: JSONObject.NULL)
                    put("customer_comment", entry.customerComment)
                    put("status", entry.status)
                }
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/feedback_logs")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .header("Prefer", "return=representation")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val saved = if (body.startsWith("[")) {
                            val arr = JSONArray(body)
                            if (arr.length() > 0) parseFeedbackJson(arr.getJSONObject(0)) else entry
                        } else entry
                        feedbackDao.insertFeedback(saved)
                        return@withContext Result.success(saved)
                    } else {
                        val errMsg = parseSupabaseError(body, "Submission failed (${response.code})")
                        return@withContext Result.failure(IllegalStateException(errMsg))
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
        }

        feedbackDao.insertFeedback(entry)
        Result.success(entry)
    }

    suspend fun sendLoginOtp(email: String): Result<String> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || !cleanEmail.contains("@")) {
            return@withContext Result.failure(IllegalArgumentException("Please enter a valid email address."))
        }

        if (isSupabaseConfigured()) {
            try {
                val payload = JSONObject().apply {
                    put("email", cleanEmail)
                    put("create_user", true)
                }
                val request = Request.Builder()
                    .url("$supabaseUrl/auth/v1/otp")
                    .header("apikey", supabaseAnonKey)
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        return@withContext Result.success("6-digit OTP sent to your email! Check inbox/spam.")
                    } else {
                        val msg = parseSupabaseError(body, "Failed to send OTP (${response.code})")
                        if (isInvalidUrlPathResponse(response.code, msg)) {
                            return@withContext Result.success(
                                "Supabase URL path rejected ($msg). Check SUPABASE_URL uses https://<project-ref>.supabase.co — Preview OTP 123456 enabled for $cleanEmail."
                            )
                        }
                        return@withContext Result.failure(IllegalStateException(msg))
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(IllegalStateException("Network error: ${e.message}"))
            }
        }

        Result.success("Preview Mode: Enter OTP 123456 to sign in as $cleanEmail")
    }

    suspend fun verifyLoginOtp(
        email: String,
        otp: String,
        ownerName: String = "",
        isBelow18: Boolean = false,
        parentGuardianName: String = ""
    ): Result<AuthSession> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        val cleanOtp = otp.trim()
        val cleanOwnerName = ownerName.trim()
        if (cleanOtp.length < 6) {
            return@withContext Result.failure(IllegalArgumentException("Please enter the 6-digit OTP."))
        }

        if (isSupabaseConfigured()) {
            try {
                val payload = JSONObject().apply {
                    put("email", cleanEmail)
                    put("token", cleanOtp)
                    put("type", "email")
                }
                val request = Request.Builder()
                    .url("$supabaseUrl/auth/v1/verify")
                    .header("apikey", supabaseAnonKey)
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val json = JSONObject(body)
                        val token = json.optString("access_token")
                        val verifiedEmail = json.optJSONObject("user")?.optString("email")?.takeIf { it.isNotBlank() }
                            ?: cleanEmail
                        val session = AuthSession(email = verifiedEmail, accessToken = token)
                        saveSession(session.email, session.accessToken)
                        if (cleanOwnerName.isNotBlank()) {
                            saveRegisteredOwnerName(session.email, cleanOwnerName)
                            applyOwnerNameToOwnedStands(session.email, cleanOwnerName)
                        }
                        saveOwnerAgeProfile(session.email, isBelow18, parentGuardianName)
                        return@withContext Result.success(session)
                    } else {
                        val msg = parseSupabaseError(body, "Invalid OTP (${response.code})")
                        if (isInvalidUrlPathResponse(response.code, msg) && cleanOtp == DEMO_OTP_CODE) {
                            val session = AuthSession(email = cleanEmail, accessToken = "demo-local-token")
                            saveSession(session.email, session.accessToken)
                            if (cleanOwnerName.isNotBlank()) {
                                saveRegisteredOwnerName(session.email, cleanOwnerName)
                                applyOwnerNameToOwnedStands(session.email, cleanOwnerName)
                            }
                            saveOwnerAgeProfile(session.email, isBelow18, parentGuardianName)
                            return@withContext Result.success(session)
                        }
                        return@withContext Result.failure(IllegalStateException(msg))
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(IllegalStateException("Verification error: ${e.message}"))
            }
        }

        if (cleanOtp == DEMO_OTP_CODE) {
            val session = AuthSession(email = cleanEmail, accessToken = "demo-local-token")
            saveSession(session.email, session.accessToken)
            if (cleanOwnerName.isNotBlank()) {
                saveRegisteredOwnerName(session.email, cleanOwnerName)
                applyOwnerNameToOwnedStands(session.email, cleanOwnerName)
            }
            saveOwnerAgeProfile(session.email, isBelow18, parentGuardianName)
            Result.success(session)
        } else {
            Result.failure(IllegalArgumentException("Invalid demo OTP. Please enter 123456."))
        }
    }

    /**
     * Sends OTP #1 or OTP #2 for 2-OTP Shop Owner Account Deletion verification.
     */
    suspend fun sendAccountDeletionOtp(email: String, step: Int): Result<String> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("No active account email found."))
        }

        if (isSupabaseConfigured()) {
            try {
                val payload = JSONObject().apply {
                    put("email", cleanEmail)
                    put("create_user", false)
                }
                val request = Request.Builder()
                    .url("$supabaseUrl/auth/v1/otp")
                    .header("apikey", supabaseAnonKey)
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val label = if (step == 1) "1st deletion verification OTP" else "2nd final deletion OTP"
                        return@withContext Result.success("Sent $label to $cleanEmail.")
                    } else {
                        val msg = parseSupabaseError(body, "Failed to send deletion OTP (${response.code})")
                        return@withContext Result.failure(IllegalStateException(msg))
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(IllegalStateException("Network error: ${e.message}"))
            }
        }

        val demoCode = if (step == 1) DEMO_DELETE_OTP_1 else DEMO_DELETE_OTP_2
        val ordinal = if (step == 1) "1st" else "2nd"
        Result.success("Preview Mode: Enter $ordinal verification OTP $demoCode for $cleanEmail")
    }

    /**
     * Verifies OTP #1 or OTP #2 for account deletion. Step 2 enforces a distinct OTP from Step 1.
     */
    suspend fun verifyAccountDeletionOtp(
        email: String,
        otp: String,
        step: Int,
        firstOtpUsed: String = ""
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        val cleanOtp = otp.trim()
        val basicCheck = validateDeletionOtpInput(cleanOtp, step, firstOtpUsed)
        if (basicCheck.isFailure) {
            return@withContext basicCheck
        }

        if (isSupabaseConfigured()) {
            try {
                val payload = JSONObject().apply {
                    put("email", cleanEmail)
                    put("token", cleanOtp)
                    put("type", "email")
                }
                val request = Request.Builder()
                    .url("$supabaseUrl/auth/v1/verify")
                    .header("apikey", supabaseAnonKey)
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        return@withContext Result.success(Unit)
                    } else {
                        val msg = parseSupabaseError(body, "Invalid OTP (${response.code})")
                        return@withContext Result.failure(IllegalStateException(msg))
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(IllegalStateException("Verification failed: ${e.message}"))
            }
        }

        val expectedDemoOtp = if (step == 1) DEMO_DELETE_OTP_1 else DEMO_DELETE_OTP_2
        if (cleanOtp == expectedDemoOtp) {
            Result.success(Unit)
        } else {
            Result.failure(
                IllegalArgumentException(
                    if (step == 1) "Invalid 1st demo OTP. Enter $DEMO_DELETE_OTP_1."
                    else "Invalid 2nd demo OTP. Enter $DEMO_DELETE_OTP_2."
                )
            )
        }
    }

    /**
     * Permanently deletes the Shop Owner's stands, associated reviews, local ledger tags,
     * and registration metadata after 2-OTP verification completes.
     */
    suspend fun deleteShopOwnerAccount(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("No logged-in shop owner."))
        }

        val ownedStands = standDao.getStandsByOwner(cleanEmail)
        val ownedSlugs = ownedStands.map { it.standSlug.lowercase(Locale.US) }
        val ownedShopNames = ownedStands.map { it.shopName.lowercase(Locale.US) }.filter { it.isNotBlank() }

        if (isSupabaseConfigured()) {
            try {
                val encodedOwner = URLEncoder.encode(cleanEmail, "UTF-8")
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/qr_stands?owner_email=ilike.$encodedOwner")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .delete()
                    .build()
                httpClient.newCall(request).execute().close()
            } catch (_: Exception) {
            }
        }

        if (ownedSlugs.isNotEmpty()) {
            feedbackDao.deleteFeedbackForStands(ownedSlugs)
        }
        standDao.deleteStandsByOwner(cleanEmail)
        qrTagDao.deleteTagsByOperator(cleanEmail)
        if (ownedShopNames.isNotEmpty()) {
            qrTagDao.deleteTagsByShopNames(ownedShopNames)
        }

        val cleanKeyEmail = cleanEmail.lowercase(Locale.US)
        val editor = prefs.edit()
            .remove(KEY_EMAIL)
            .remove(KEY_TOKEN)
            .remove("$KEY_OWNER_NAME_EMAIL_PREFIX$cleanKeyEmail")
            .remove("$KEY_OWNER_BELOW18_EMAIL_PREFIX$cleanKeyEmail")
            .remove("$KEY_OWNER_PARENT_EMAIL_PREFIX$cleanKeyEmail")
        ownedSlugs.forEach { slug ->
            editor.remove("$KEY_OWNER_NAME_SLUG_PREFIX$slug")
        }
        editor.apply()

        Result.success(Unit)
    }

    private suspend fun applyOwnerNameToOwnedStands(ownerEmail: String, ownerName: String) {
        val cleanName = ownerName.trim()
        if (cleanName.isBlank()) return
        ensureSeededLocally()
        val ownedStands = standDao.getStandsByOwner(ownerEmail.trim())
        if (ownedStands.isNotEmpty()) {
            standDao.upsertStands(ownedStands.map { it.copy(ownerName = cleanName) })
        }
    }

    suspend fun logout() = withContext(Dispatchers.IO) {
        val session = getCurrentSession()
        if (isSupabaseConfigured() && session != null && session.accessToken.isNotBlank()) {
            try {
                val request = Request.Builder()
                    .url("$supabaseUrl/auth/v1/logout")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${session.accessToken}")
                    .post("{}".toRequestBody(jsonMediaType))
                    .build()
                httpClient.newCall(request).execute().close()
            } catch (_: Exception) {
            }
        }
        clearSession()
    }

    /**
     * Owner Dashboard: loads ONLY stands owned by the logged-in user.
     */
    suspend fun loadOwnerStands(ownerEmail: String): List<QrStandEntity> = withContext(Dispatchers.IO) {
        val cleanOwner = ownerEmail.trim()
        if (isSupabaseConfigured()) {
            try {
                val encodedOwner = URLEncoder.encode(cleanOwner, "UTF-8")
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/qr_stands?owner_email=ilike.$encodedOwner&select=*&order=created_at.desc")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.startsWith("[")) {
                        val arr = JSONArray(body)
                        val stands = buildList {
                            for (i in 0 until arr.length()) {
                                add(parseStandJson(arr.getJSONObject(i)))
                            }
                        }
                        if (stands.isNotEmpty()) standDao.upsertStands(stands)
                        return@withContext stands
                    }
                }
            } catch (_: Exception) {
            }
        }

        ensureSeededLocally()
        standDao.getStandsByOwner(cleanOwner)
    }

    /**
     * Owner Dashboard: loads ONLY negative reviews for stands owned by the logged-in user.
     */
    suspend fun loadOwnerReviews(ownerEmail: String): List<FeedbackLogEntity> = withContext(Dispatchers.IO) {
        val cleanOwner = ownerEmail.trim()
        if (isSupabaseConfigured()) {
            try {
                val myStands = loadOwnerStands(cleanOwner).map { it.standSlug.lowercase() }.toSet()
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/feedback_logs?select=*&order=created_at.desc")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.startsWith("[")) {
                        val arr = JSONArray(body)
                        val remoteList = buildList {
                            for (i in 0 until arr.length()) {
                                add(parseFeedbackJson(arr.getJSONObject(i)))
                            }
                        }
                        if (remoteList.isNotEmpty()) feedbackDao.insertAllFeedback(remoteList)
                        return@withContext remoteList.filter { it.standSlug.lowercase() in myStands }
                    }
                }
            } catch (_: Exception) {
            }
        }

        ensureSeededLocally()
        feedbackDao.getFeedbackForOwner(cleanOwner)
    }

    /**
     * Separated Directory Screen (only accessible when ADMIN_EMAIL is explicitly configured & matches).
     */
    suspend fun loadAllStandsDirectory(): List<QrStandEntity> = withContext(Dispatchers.IO) {
        if (isSupabaseConfigured()) {
            try {
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/qr_stands?select=*&order=created_at.desc")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.startsWith("[")) {
                        val arr = JSONArray(body)
                        val stands = buildList {
                            for (i in 0 until arr.length()) {
                                add(parseStandJson(arr.getJSONObject(i)))
                            }
                        }
                        if (stands.isNotEmpty()) standDao.upsertStands(stands)
                        return@withContext stands
                    }
                }
            } catch (_: Exception) {
            }
        }
        ensureSeededLocally()
        standDao.getAllStands()
    }

    suspend fun loadAllReviewsDirectory(): List<FeedbackLogEntity> = withContext(Dispatchers.IO) {
        if (isSupabaseConfigured()) {
            try {
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/feedback_logs?select=*&order=created_at.desc")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .get()
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.startsWith("[")) {
                        val arr = JSONArray(body)
                        val remoteList = buildList {
                            for (i in 0 until arr.length()) {
                                add(parseFeedbackJson(arr.getJSONObject(i)))
                            }
                        }
                        if (remoteList.isNotEmpty()) feedbackDao.insertAllFeedback(remoteList)
                        return@withContext remoteList
                    }
                }
            } catch (_: Exception) {
            }
        }
        ensureSeededLocally()
        feedbackDao.getAllFeedback()
    }

    suspend fun toggleReviewStatus(reviewId: String, currentStatus: String): Result<String> = withContext(Dispatchers.IO) {
        val nextStatus = if (currentStatus.equals(FeedbackLogEntity.STATUS_PENDING, ignoreCase = true)) {
            FeedbackLogEntity.STATUS_RESOLVED
        } else {
            FeedbackLogEntity.STATUS_PENDING
        }

        if (isSupabaseConfigured()) {
            try {
                val payload = JSONObject().put("status", nextStatus)
                val request = Request.Builder()
                    .url("$supabaseUrl/rest/v1/feedback_logs?id=eq.${URLEncoder.encode(reviewId, "UTF-8")}")
                    .header("apikey", supabaseAnonKey)
                    .header("Authorization", "Bearer ${getAuthBearerToken()}")
                    .patch(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        val body = response.body?.string().orEmpty()
                        return@withContext Result.failure(
                            IllegalStateException(parseSupabaseError(body, "Status update failed (${response.code})"))
                        )
                    }
                }
            } catch (e: Exception) {
                return@withContext Result.failure(e)
            }
        }

        feedbackDao.updateStatus(reviewId, nextStatus)
        Result.success(nextStatus)
    }

    /**
     * Resolves any pasted Google Maps link into a direct Google Write-Review / Reviews-Tab URL.
     */
    suspend fun resolveDirectReviewUrl(mapsLink: String): ResolvedLinkPreview = withContext(Dispatchers.IO) {
        val cleanMaps = mapsLink.trim()
        var backendUrl: String? = null
        var sourceLabel = "On-Device Review Resolver"

        if (isRenderBackendConfigured()) {
            try {
                val payload = JSONObject().put("shareUrl", cleanMaps)
                val request = Request.Builder()
                    .url("$renderBackendUrl/api/extract-review-link")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.startsWith("{")) {
                        val json = JSONObject(body)
                        if (json.optBoolean("success", false)) {
                            val extracted = json.optString("directReviewUrl")
                            if (extracted.isNotBlank()) {
                                backendUrl = extracted
                                sourceLabel = "Render Link Extractor"
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        val targetToUpgrade = backendUrl ?: cleanMaps
        val resolved = GoogleReviewLinkHelper.generateDirectReviewLink(targetToUpgrade)
        val finalDirect = resolved.writeReviewUrl?.takeIf { it.isNotBlank() }
            ?: resolved.directReviewUrl.takeIf { it.isNotBlank() }
            ?: GoogleReviewLinkHelper.getDirectWriteReviewUrl(cleanMaps)

        ResolvedLinkPreview(
            directUrl = finalDirect,
            linkType = resolved.linkType,
            source = sourceLabel,
            opensWriteReviewModal = resolved.opensWriteReviewModal
        )
    }

    /**
     * Generates a batch of guaranteed-unique QR code strings (e.g. TR-8421-MPK -> /r/TR-8421-MPK)
     * in the merchant's unlinked serials pool.
     */
    suspend fun generateUniqueSerialBatch(
        count: Int,
        prefix: String,
        batchName: String,
        ownerEmail: String
    ): List<QrTagEntity> = withContext(Dispatchers.IO) {
        ensureSeededLocally()
        val safeCount = count.coerceIn(1, 25)
        val existingSerials = qrTagDao.getAllTagsOnce().map { it.serialNumber.uppercase() }.toMutableSet()
        val cleanBatch = batchName.trim().ifBlank { "Counter Stand" }
        val cleanOwner = ownerEmail.trim()
        val now = System.currentTimeMillis()
        val created = ArrayList<QrTagEntity>(safeCount)

        repeat(safeCount) { index ->
            var serial: String
            var attempts = 0
            do {
                serial = SerialGenerator.generateSerial(prefix)
                attempts++
            } while (existingSerials.contains(serial.uppercase()) && attempts < 50)
            existingSerials.add(serial.uppercase())

            created += QrTagEntity(
                serialNumber = serial,
                token = SerialGenerator.generateToken(),
                batchName = cleanBatch,
                status = QrTagEntity.STATUS_UNLINKED,
                operatorName = cleanOwner,
                createdAt = now + index
            )
        }
        qrTagDao.insertTags(created)
        created
    }

    /**
     * Assigns an unlinked QR serial string to a merchant's shop, converting the Google Maps link
     * into a direct Write-Review Modal URL, updating the merchant's local ledger, and registering
     * the live dynamic QR stand so scanning /r/<serial> works immediately.
     */
    suspend fun assignUnlinkedSerialToShop(
        serial: String,
        shopName: String,
        ownerEmail: String,
        mapsLink: String,
        whatsappNumber: String?,
        instagramHandle: String?,
        qrCountTaken: Int,
        moneyReceived: Double,
        notes: String?
    ): Result<CreateStandResult> = withContext(Dispatchers.IO) {
        val cleanSerial = serial.trim().uppercase()
        val cleanShop = shopName.trim()
        val cleanOwner = ownerEmail.trim()
        val cleanMaps = mapsLink.trim()
        if (cleanSerial.isBlank() || cleanShop.isBlank() || cleanOwner.isBlank() || cleanMaps.isBlank()) {
            return@withContext Result.failure(
                IllegalArgumentException("Please enter Shop Name and a Google Maps link.")
            )
        }

        val standResult = saveDynamicQrStand(
            rawSlug = cleanSerial,
            shopName = cleanShop,
            ownerEmail = cleanOwner,
            mapsLink = cleanMaps
        )

        val savedStand = standResult.getOrElse { return@withContext Result.failure(it) }
        val now = System.currentTimeMillis()
        val existingTag = qrTagDao.findTagBySerial(cleanSerial)
        val updatedTag = (existingTag ?: QrTagEntity(
            serialNumber = cleanSerial,
            token = SerialGenerator.generateToken(),
            createdAt = now
        )).copy(
            status = QrTagEntity.STATUS_LINKED,
            shopName = cleanShop,
            whatsappNumber = whatsappNumber?.trim()?.takeIf { it.isNotBlank() },
            instagramHandle = instagramHandle?.trim()?.takeIf { it.isNotBlank() },
            googleReviewUrl = savedStand.stand.googleReviewUrl,
            destinationUrl = savedStand.stand.googleReviewUrl,
            qrCountTaken = qrCountTaken.coerceAtLeast(1),
            moneyReceived = moneyReceived.coerceAtLeast(0.0),
            operatorName = cleanOwner,
            notes = notes?.trim()?.takeIf { it.isNotBlank() },
            linkedAt = now
        )
        qrTagDao.insertTag(updatedTag)
        Result.success(savedStand)
    }

    suspend fun unlinkLocalTag(serial: String) = withContext(Dispatchers.IO) {
        val existing = qrTagDao.findTagBySerial(serial.trim()) ?: return@withContext
        qrTagDao.updateTag(
            existing.copy(
                status = QrTagEntity.STATUS_UNLINKED,
                shopName = null,
                googleReviewUrl = null,
                destinationUrl = null,
                whatsappNumber = null,
                instagramHandle = null,
                linkedAt = null
            )
        )
    }

    suspend fun markTagNfcLinked(serial: String, nfcUid: String) = withContext(Dispatchers.IO) {
        val existing = qrTagDao.findTagBySerial(serial.trim()) ?: return@withContext
        qrTagDao.updateTag(
            existing.copy(
                nfcLinked = true,
                nfcTagUid = nfcUid.trim(),
                nfcLinkedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * Creates or dynamically edits a QR stand (updating Shop Name, Owner Email, and Google Review URL)
     * while preserving the same scannable dynamic QR Stand URL.
     */
    suspend fun saveDynamicQrStand(
        rawSlug: String,
        shopName: String,
        ownerEmail: String,
        mapsLink: String,
        ownerName: String = ""
    ): Result<CreateStandResult> = withContext(Dispatchers.IO) {
        val cleanStandSlug = cleanSlug(rawSlug)
        val cleanShop = shopName.trim()
        val cleanOwner = ownerEmail.trim()
        val cleanMaps = mapsLink.trim()
        val resolvedOwnerName = ownerName.trim().ifBlank {
            getRegisteredOwnerName(cleanStandSlug, cleanOwner)
        }

        if (cleanStandSlug.isBlank() || cleanShop.isBlank() || cleanOwner.isBlank() || cleanMaps.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please fill Stand ID, Shop Name, Owner Email, and Google Maps link."))
        }

        val resolved = resolveDirectReviewUrl(cleanMaps)

        val stand = QrStandEntity(
            standSlug = cleanStandSlug,
            shopName = cleanShop,
            ownerEmail = cleanOwner,
            googleReviewUrl = resolved.directUrl,
            ownerName = resolvedOwnerName,
            createdAt = System.currentTimeMillis()
        )

        if (resolvedOwnerName.isNotBlank()) {
            saveRegisteredOwnerName(cleanOwner, resolvedOwnerName, cleanStandSlug)
        }

        if (isSupabaseConfigured()) {
            try {
                fun buildPayload(includeOwnerName: Boolean): JSONObject = JSONObject().apply {
                    put("stand_slug", stand.standSlug)
                    put("shop_name", stand.shopName)
                    put("owner_email", stand.ownerEmail)
                    put("google_review_url", stand.googleReviewUrl)
                    if (includeOwnerName && resolvedOwnerName.isNotBlank()) {
                        put("owner_name", resolvedOwnerName)
                    }
                }

                fun executeUpsert(payload: JSONObject): Pair<Boolean, String> {
                    val request = Request.Builder()
                        .url("$supabaseUrl/rest/v1/qr_stands?on_conflict=stand_slug")
                        .header("apikey", supabaseAnonKey)
                        .header("Authorization", "Bearer ${getAuthBearerToken()}")
                        .header("Prefer", "resolution=merge-duplicates,return=representation")
                        .post(payload.toString().toRequestBody(jsonMediaType))
                        .build()

                    return httpClient.newCall(request).execute().use { response ->
                        response.isSuccessful to response.body?.string().orEmpty()
                    }
                }

                var (ok, body) = executeUpsert(buildPayload(includeOwnerName = resolvedOwnerName.isNotBlank()))
                if (!ok && resolvedOwnerName.isNotBlank() &&
                    (body.contains("owner_name", ignoreCase = true) || body.contains("PGRST204", ignoreCase = true))
                ) {
                    val retry = executeUpsert(buildPayload(includeOwnerName = false))
                    ok = retry.first
                    body = retry.second
                }

                if (!ok) {
                    val msg = parseSupabaseError(body, "Database Error")
                    return@withContext Result.failure(IllegalStateException(msg))
                }
            } catch (e: Exception) {
                return@withContext Result.failure(IllegalStateException("Supabase error: ${e.message}"))
            }
        }

        standDao.upsertStand(stand)
        val qrUrl = buildStandQrUrl(cleanStandSlug, renderBackendUrl)
        Result.success(CreateStandResult(stand = stand, qrUrl = qrUrl, extractorSource = resolved.source))
    }

    suspend fun ensureSeededLocally() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (standDao.getAllStands().isEmpty()) {
            standDao.upsertStands(
                listOf(
                    QrStandEntity(
                        standSlug = "stand1",
                        shopName = "Chahat Sweets & Namkeen",
                        ownerEmail = "owner@chahatsweets.com",
                        googleReviewUrl = "https://www.google.com/search?q=Chahat+Sweets+And+Namkeen&ludocid=14030330594820419582#lrd=0x397c69e557517a07:0xc2b5be90a7626ffe,3,,,",
                        ownerName = "Chahat Gupta",
                        createdAt = now - 86400000L * 3
                    ),
                    QrStandEntity(
                        standSlug = "stand2",
                        shopName = "Urban Roasters Coffee",
                        ownerEmail = "owner@urbanroasters.com",
                        googleReviewUrl = "https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4",
                        ownerName = "Aarav Mehta",
                        createdAt = now - 86400000L
                    )
                )
            )
        }
        if (feedbackDao.getAllFeedback().isEmpty()) {
            feedbackDao.insertAllFeedback(
                listOf(
                    FeedbackLogEntity(
                        id = "fb-demo-101",
                        standSlug = "stand1",
                        shopName = "Chahat Sweets & Namkeen",
                        totalScore = 7,
                        customerPhone = "+919876543210",
                        customerComment = "Evening samosa batch was slightly cold, counter staff took a bit long.",
                        status = FeedbackLogEntity.STATUS_PENDING,
                        createdAt = now - 3600000L * 4
                    ),
                    FeedbackLogEntity(
                        id = "fb-demo-102",
                        standSlug = "stand2",
                        shopName = "Urban Roasters Coffee",
                        totalScore = 8,
                        customerPhone = null,
                        customerComment = "Table near window needed wiping when we arrived.",
                        status = FeedbackLogEntity.STATUS_RESOLVED,
                        createdAt = now - 86400000L
                    )
                )
            )
        }
        if (qrTagDao.countTagsOnce() == 0) {
            qrTagDao.insertTags(
                listOf(
                    QrTagEntity(
                        serialNumber = "TR-8421-MPK",
                        token = "tkn_chahat1",
                        batchName = "Counter Stand",
                        status = QrTagEntity.STATUS_LINKED,
                        shopName = "Chahat Sweets & Namkeen",
                        whatsappNumber = "+919876543210",
                        instagramHandle = "@chahatsweets",
                        googleReviewUrl = "https://www.google.com/search?q=Chahat+Sweets+And+Namkeen&ludocid=14030330594820419582#lrd=0x397c69e557517a07:0xc2b5be90a7626ffe,3,,,",
                        qrCountTaken = 2,
                        moneyReceived = 600.0,
                        currency = "₹",
                        nfcLinked = true,
                        nfcTagUid = "04A83C91F2",
                        nfcLinkedAt = now - 86400000L * 2,
                        operatorName = "owner@chahatsweets.com",
                        scanCount = 42,
                        positiveReviewsCount = 31,
                        privateFeedbacksCount = 4,
                        createdAt = now - 86400000L * 3,
                        linkedAt = now - 86400000L * 3
                    ),
                    QrTagEntity(
                        serialNumber = "TR-4821-KMP",
                        token = "tkn_unlinked1",
                        batchName = "Table Tent",
                        status = QrTagEntity.STATUS_UNLINKED,
                        operatorName = "owner@chahatsweets.com",
                        createdAt = now - 3600000L * 8
                    ),
                    QrTagEntity(
                        serialNumber = "TR-9304-XVT",
                        token = "tkn_unlinked2",
                        batchName = "Counter Stand",
                        status = QrTagEntity.STATUS_UNLINKED,
                        operatorName = "owner@chahatsweets.com",
                        createdAt = now - 3600000L * 6
                    ),
                    QrTagEntity(
                        serialNumber = "TR-7102-URB",
                        token = "tkn_urban1",
                        batchName = "Espresso Bar",
                        status = QrTagEntity.STATUS_LINKED,
                        shopName = "Urban Roasters Coffee",
                        whatsappNumber = "+919820011223",
                        instagramHandle = "@urbanroasters",
                        googleReviewUrl = "https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4",
                        qrCountTaken = 3,
                        moneyReceived = 900.0,
                        currency = "₹",
                        operatorName = "owner@urbanroasters.com",
                        scanCount = 28,
                        positiveReviewsCount = 24,
                        privateFeedbacksCount = 2,
                        createdAt = now - 86400000L * 1,
                        linkedAt = now - 86400000L * 1
                    )
                )
            )
        }
    }

    private fun getAuthBearerToken(): String {
        val token = prefs.getString(KEY_TOKEN, null)
        return if (!token.isNullOrBlank() && token != "demo-local-token") token else supabaseAnonKey
    }

    private fun parseStandJson(json: JSONObject): QrStandEntity {
        val createdRaw = json.optString("created_at")
        val slug = json.optString("stand_slug")
        val ownerEmail = json.optString("owner_email")
        val remoteOwnerName = json.optString("owner_name").trim()
        val resolvedOwnerName = remoteOwnerName.ifBlank { getRegisteredOwnerName(slug, ownerEmail) }
        return QrStandEntity(
            standSlug = slug,
            shopName = json.optString("shop_name"),
            ownerEmail = ownerEmail,
            googleReviewUrl = json.optString("google_review_url"),
            ownerName = resolvedOwnerName,
            createdAt = parseIsoTimestamp(createdRaw)
        )
    }

    private fun parseFeedbackJson(json: JSONObject): FeedbackLogEntity {
        val phoneRaw = if (json.isNull("customer_phone")) null else json.optString("customer_phone").takeIf { it.isNotBlank() }
        val createdRaw = json.optString("created_at")
        return FeedbackLogEntity(
            id = json.optString("id").ifBlank { UUID.randomUUID().toString() },
            standSlug = json.optString("stand_slug"),
            shopName = json.optString("shop_name"),
            totalScore = json.optInt("total_score", 0),
            customerPhone = phoneRaw,
            customerComment = json.optString("customer_comment"),
            status = json.optString("status", FeedbackLogEntity.STATUS_PENDING),
            createdAt = parseIsoTimestamp(createdRaw)
        )
    }

    private fun parseSupabaseError(body: String, fallback: String): String {
        return try {
            val obj = JSONObject(body)
            obj.optString("msg").takeIf { it.isNotBlank() }
                ?: obj.optString("message").takeIf { it.isNotBlank() }
                ?: obj.optString("error_description").takeIf { it.isNotBlank() }
                ?: obj.optString("error").takeIf { it.isNotBlank() }
                ?: fallback
        } catch (_: Exception) {
            fallback
        }
    }

    private fun parseIsoTimestamp(iso: String): Long {
        if (iso.isBlank()) return System.currentTimeMillis()
        return try {
            val trimmed = iso.substringBefore(".").substringBefore("+").substringBefore("Z")
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.parse(trimmed)?.time ?: System.currentTimeMillis()
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }

    companion object {
        const val DEFAULT_STAND_SLUG = "stand1"
        const val DEMO_OTP_CODE = "123456"
        const val DEMO_DELETE_OTP_1 = "111111"
        const val DEMO_DELETE_OTP_2 = "222222"
        const val DEMO_SUPER_ADMIN_EMAIL = "admin@dynamicqr.local"
        private const val KEY_EMAIL = "auth_email"
        private const val KEY_TOKEN = "auth_token"
        private const val KEY_OWNER_NAME_EMAIL_PREFIX = "owner_name_email_"
        private const val KEY_OWNER_NAME_SLUG_PREFIX = "owner_name_slug_"
        private const val KEY_OWNER_BELOW18_EMAIL_PREFIX = "owner_below18_email_"
        private const val KEY_OWNER_PARENT_EMAIL_PREFIX = "owner_parent_email_"

        fun normalizeSupabaseBaseUrl(rawUrl: String): String {
            val clean = rawUrl.trim().trim('"', '\'', ' ').trimEnd('/')
            if (clean.isBlank() || clean.contains("YOUR_PROJECT_REF", ignoreCase = true)) {
                return ""
            }

            // Convert Supabase Dashboard URLs: https://supabase.com/dashboard/project/<ref>/...
            val dashboardMatch = Regex(
                """supabase\.com/dashboard/project/([a-z0-9]+)""",
                RegexOption.IGNORE_CASE
            ).find(clean)
            if (dashboardMatch != null) {
                val ref = dashboardMatch.groupValues[1].lowercase(Locale.US)
                if (ref.isNotBlank()) return "https://$ref.supabase.co"
            }

            val withScheme = if (clean.startsWith("http://", ignoreCase = true) ||
                clean.startsWith("https://", ignoreCase = true)
            ) {
                clean
            } else {
                "https://$clean"
            }

            return try {
                val uri = java.net.URI(withScheme)
                val host = uri.host?.lowercase(Locale.US).orEmpty()
                if (host.isBlank() ||
                    host == "supabase.com" ||
                    host == "www.supabase.com" ||
                    host == "app.supabase.com"
                ) {
                    ""
                } else {
                    val scheme = uri.scheme?.lowercase(Locale.US) ?: "https"
                    val portPart = if (uri.port != -1) ":${uri.port}" else ""
                    "$scheme://$host$portPart"
                }
            } catch (_: Exception) {
                ""
            }
        }

        fun isInvalidUrlPathResponse(httpCode: Int, errorMsg: String): Boolean {
            return httpCode == 404 || errorMsg.contains("invalid path", ignoreCase = true)
        }

        fun validateDeletionOtpInput(
            otp: String,
            step: Int,
            firstOtpUsed: String = ""
        ): Result<Unit> {
            val clean = otp.trim()
            if (clean.length < 6) {
                return Result.failure(IllegalArgumentException("Please enter the 6-digit verification OTP."))
            }
            if (step == 2 && firstOtpUsed.isNotBlank() && clean == firstOtpUsed.trim()) {
                return Result.failure(
                    IllegalArgumentException("For security, the 2nd OTP must be a newly sent code, not the 1st OTP.")
                )
            }
            return Result.success(Unit)
        }

        fun cleanSlug(rawSlug: String): String {
            return rawSlug.trim().lowercase().replace(Regex("\\s+"), "")
        }

        fun isConfiguredDirectoryOperator(email: String?, configuredAdminEmail: String): Boolean {
            val clean = email?.trim()?.lowercase() ?: return false
            val admin = configuredAdminEmail.trim().lowercase()
            if (clean.isBlank() || admin.isBlank() || admin == "your_master_email@gmail.com") return false
            return clean == admin
        }

        /**
         * Ensures a Shop Owner only accesses local ledger tags and unlinked serials
         * belonging to their own account or owned shop names.
         */
        fun filterTagsForOwner(
            tags: List<QrTagEntity>,
            ownerEmail: String?,
            ownerStandShopNames: Set<String>
        ): List<QrTagEntity> {
            val cleanOwner = ownerEmail?.trim()?.lowercase() ?: return emptyList()
            if (cleanOwner.isBlank()) return emptyList()
            val cleanShopNames = ownerStandShopNames.map { it.trim().lowercase() }.filter { it.isNotBlank() }.toSet()
            return tags.filter { tag ->
                val tagOperator = tag.operatorName?.trim()?.lowercase().orEmpty()
                val tagShop = tag.shopName?.trim()?.lowercase().orEmpty()
                when {
                    tagOperator.isNotBlank() -> tagOperator == cleanOwner
                    tagShop.isNotBlank() -> tagShop in cleanShopNames
                    else -> !tag.isLinked
                }
            }
        }

        fun buildStandQrUrl(standSlug: String, backendBaseUrl: String = BuildConfig.RENDER_BACKEND_URL): String {
            val clean = cleanSlug(standSlug).ifBlank { DEFAULT_STAND_SLUG }
            val normalizedBase = if (backendBaseUrl.startsWith("http") &&
                !backendBaseUrl.contains("YOUR-EXACT-RENDER-URL", ignoreCase = true)
            ) {
                backendBaseUrl.trim().trimEnd('/')
            } else {
                "https://qr-redirector-xb5h.onrender.com"
            }
            return if (normalizedBase.endsWith("/r", ignoreCase = true)) {
                "$normalizedBase/$clean"
            } else {
                "$normalizedBase/r/$clean"
            }
        }

        fun extractStandSlugFromUri(rawUri: String): String? {
            val trimmed = rawUri.trim()
            if (trimmed.isBlank()) return null
            return try {
                val queryPart = trimmed.substringAfter("?", "").substringBefore("#")
                if (queryPart.isNotBlank()) {
                    for (pair in queryPart.split("&")) {
                        val key = pair.substringBefore("=", "")
                        val value = pair.substringAfter("=", "")
                        if ((key.equals("s", ignoreCase = true) || key.equals("qr_id", ignoreCase = true)) &&
                            value.isNotBlank()
                        ) {
                            return cleanSlug(java.net.URLDecoder.decode(value, "UTF-8"))
                        }
                    }
                }

                val pathOnly = trimmed.substringBefore("?").substringBefore("#")
                when {
                    pathOnly.contains("/r/") -> {
                        cleanSlug(pathOnly.substringAfterLast("/r/").substringBefore("/")).takeIf { it.isNotBlank() }
                    }
                    pathOnly.contains("/qr/") -> {
                        cleanSlug(pathOnly.substringAfterLast("/qr/").substringBefore("/")).takeIf { it.isNotBlank() }
                    }
                    trimmed.startsWith("dynamicqr://", ignoreCase = true) -> {
                        val seg = pathOnly.removePrefix("dynamicqr://").trimEnd('/').substringAfterLast("/")
                        cleanSlug(seg).takeIf { it.isNotBlank() }
                    }
                    else -> null
                }
            } catch (_: Exception) {
                null
            }
        }

        fun shouldRedirectToGoogleReview(q1: Int, q2: Int, q3: Int): Boolean {
            return (q1 + q2 + q3) > 9
        }
    }
}
