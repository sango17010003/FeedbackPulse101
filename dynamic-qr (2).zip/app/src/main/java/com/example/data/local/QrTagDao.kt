package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface QrTagDao {
    @Query("SELECT * FROM qr_tags ORDER BY createdAt DESC")
    fun getAllTags(): Flow<List<QrTagEntity>>

    @Query("SELECT * FROM qr_tags ORDER BY createdAt DESC")
    suspend fun getAllTagsOnce(): List<QrTagEntity>

    @Query("SELECT COUNT(*) FROM qr_tags")
    suspend fun countTagsOnce(): Int

    @Query("SELECT * FROM qr_tags WHERE id = :id")
    fun getTagById(id: Long): Flow<QrTagEntity?>

    @Query("SELECT * FROM qr_tags WHERE UPPER(serialNumber) = UPPER(:serial)")
    fun getTagBySerial(serial: String): Flow<QrTagEntity?>

    @Query("SELECT * FROM qr_tags WHERE UPPER(serialNumber) = UPPER(:serial) LIMIT 1")
    suspend fun findTagBySerial(serial: String): QrTagEntity?

    @Query("""
        SELECT * FROM qr_tags 
        WHERE UPPER(serialNumber) LIKE '%' || UPPER(:query) || '%' 
           OR UPPER(title) LIKE '%' || UPPER(:query) || '%'
           OR UPPER(address) LIKE '%' || UPPER(:query) || '%'
           OR UPPER(batchName) LIKE '%' || UPPER(:query) || '%'
        ORDER BY createdAt DESC
    """)
    fun searchTags(query: String): Flow<List<QrTagEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTag(tag: QrTagEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTags(tags: List<QrTagEntity>): List<Long>

    @Update
    suspend fun updateTag(tag: QrTagEntity)

    @Delete
    suspend fun deleteTag(tag: QrTagEntity)

    @Query("DELETE FROM qr_tags WHERE id = :id")
    suspend fun deleteTagById(id: Long)

    @Query("DELETE FROM qr_tags WHERE LOWER(operatorName) = LOWER(:email)")
    suspend fun deleteTagsByOperator(email: String)

    @Query("DELETE FROM qr_tags WHERE LOWER(shopName) IN (:shopNames)")
    suspend fun deleteTagsByShopNames(shopNames: List<String>)

    @Query("UPDATE qr_tags SET scanCount = scanCount + 1, lastScannedAt = :timestamp WHERE UPPER(serialNumber) = UPPER(:serial)")
    suspend fun recordScan(serial: String, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM qr_tags")
    fun countAll(): Flow<Int>

    @Query("SELECT COUNT(*) FROM qr_tags WHERE status != 'unlinked'")
    fun countLinked(): Flow<Int>

    @Query("SELECT COUNT(*) FROM qr_tags WHERE status = 'unlinked'")
    fun countUnlinked(): Flow<Int>

    @Query("SELECT SUM(scanCount) FROM qr_tags")
    fun sumScans(): Flow<Int?>
}
