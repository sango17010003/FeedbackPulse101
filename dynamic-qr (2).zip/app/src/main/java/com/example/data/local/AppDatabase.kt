package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [QrTagEntity::class, QrStandEntity::class, FeedbackLogEntity::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun qrTagDao(): QrTagDao
    abstract fun standDao(): StandDao
    abstract fun feedbackDao(): FeedbackDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            val appContext = context.applicationContext
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    appContext,
                    AppDatabase::class.java,
                    "dynamic_qr.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getInstance(appContext)
                                seedInitialStandsAndFeedback(
                                    database.standDao(),
                                    database.feedbackDao(),
                                    database.qrTagDao()
                                )
                            }
                        }

                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getInstance(appContext)
                                if (database.standDao().getAllStands().isEmpty() || database.qrTagDao().countTagsOnce() == 0) {
                                    seedInitialStandsAndFeedback(
                                        database.standDao(),
                                        database.feedbackDao(),
                                        database.qrTagDao()
                                    )
                                }
                            }
                        }
                    })
                    .build()
                    .also { INSTANCE = it }
            }
        }

        private suspend fun seedInitialStandsAndFeedback(
            standDao: StandDao,
            feedbackDao: FeedbackDao,
            qrTagDao: QrTagDao
        ) {
            val now = System.currentTimeMillis()
            if (standDao.getAllStands().isEmpty()) {
                val sampleStands = listOf(
                    QrStandEntity(
                        standSlug = "stand1",
                        shopName = "Chahat Sweets & Namkeen",
                        ownerEmail = "owner@chahatsweets.com",
                        googleReviewUrl = "https://www.google.com/search?q=Chahat+Sweets+And+Namkeen&ludocid=14030330594820419582#lrd=0x397c69e557517a07:0xc2b5be90a7626ffe,3,,,",
                        ownerName = "Chahat Gupta",
                        createdAt = now - 86400000L * 3
                    ),
                    QrStandEntity(
                        standSlug = "stand2",
                        shopName = "Urban Roasters Coffee",
                        ownerEmail = "owner@urbanroasters.com",
                        googleReviewUrl = "https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4",
                        ownerName = "Aarav Mehta",
                        createdAt = now - 86400000L * 1
                    )
                )
                standDao.upsertStands(sampleStands)
            }

            if (feedbackDao.getAllFeedback().isEmpty()) {
                val sampleLogs = listOf(
                    FeedbackLogEntity(
                        id = "fb-demo-101",
                        standSlug = "stand1",
                        shopName = "Chahat Sweets & Namkeen",
                        totalScore = 7,
                        customerPhone = "+919876543210",
                        customerComment = "Evening samosa batch was slightly cold, counter staff took a bit long.",
                        status = FeedbackLogEntity.STATUS_PENDING,
                        createdAt = now - 3600000L * 4
                    ),
                    FeedbackLogEntity(
                        id = "fb-demo-102",
                        standSlug = "stand2",
                        shopName = "Urban Roasters Coffee",
                        totalScore = 8,
                        customerPhone = null,
                        customerComment = "Table near window needed wiping when we arrived.",
                        status = FeedbackLogEntity.STATUS_RESOLVED,
                        createdAt = now - 86400000L
                    )
                )
                feedbackDao.insertAllFeedback(sampleLogs)
            }

            if (qrTagDao.countTagsOnce() == 0) {
                qrTagDao.insertTags(
                    listOf(
                        QrTagEntity(
                            serialNumber = "TR-8421-MPK",
                            token = "tkn_chahat1",
                            batchName = "Counter Stand",
                            status = QrTagEntity.STATUS_LINKED,
                            shopName = "Chahat Sweets & Namkeen",
                            whatsappNumber = "+919876543210",
                            instagramHandle = "@chahatsweets",
                            googleReviewUrl = "https://www.google.com/search?q=Chahat+Sweets+And+Namkeen&ludocid=14030330594820419582#lrd=0x397c69e557517a07:0xc2b5be90a7626ffe,3,,,",
                            qrCountTaken = 2,
                            moneyReceived = 600.0,
                            currency = "₹",
                            nfcLinked = true,
                            nfcTagUid = "04A83C91F2",
                            nfcLinkedAt = now - 86400000L * 2,
                            operatorName = "owner@chahatsweets.com",
                            scanCount = 42,
                            positiveReviewsCount = 31,
                            privateFeedbacksCount = 4,
                            createdAt = now - 86400000L * 3,
                            linkedAt = now - 86400000L * 3
                        ),
                        QrTagEntity(
                            serialNumber = "TR-4821-KMP",
                            token = "tkn_unlinked1",
                            batchName = "Table Tent",
                            status = QrTagEntity.STATUS_UNLINKED,
                            operatorName = "owner@chahatsweets.com",
                            createdAt = now - 3600000L * 8
                        ),
                        QrTagEntity(
                            serialNumber = "TR-9304-XVT",
                            token = "tkn_unlinked2",
                            batchName = "Counter Stand",
                            status = QrTagEntity.STATUS_UNLINKED,
                            operatorName = "owner@chahatsweets.com",
                            createdAt = now - 3600000L * 6
                        ),
                        QrTagEntity(
                            serialNumber = "TR-7102-URB",
                            token = "tkn_urban1",
                            batchName = "Espresso Bar",
                            status = QrTagEntity.STATUS_LINKED,
                            shopName = "Urban Roasters Coffee",
                            whatsappNumber = "+919820011223",
                            instagramHandle = "@urbanroasters",
                            googleReviewUrl = "https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4",
                            qrCountTaken = 3,
                            moneyReceived = 900.0,
                            currency = "₹",
                            operatorName = "owner@urbanroasters.com",
                            scanCount = 28,
                            positiveReviewsCount = 24,
                            privateFeedbacksCount = 2,
                            createdAt = now - 86400000L * 1,
                            linkedAt = now - 86400000L * 1
                        )
                    )
                )
            }
        }
    }
}
