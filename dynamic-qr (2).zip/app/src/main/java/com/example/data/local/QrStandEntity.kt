package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Locale

@Entity(tableName = "qr_stands")
data class QrStandEntity(
    @PrimaryKey
    val standSlug: String,
    val shopName: String,
    val ownerEmail: String,
    val googleReviewUrl: String,
    val ownerName: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val displayOwnerName: String
        get() = ownerName.trim().ifBlank { deriveOwnerNameFromEmail(ownerEmail) }

    companion object {
        private val GENERIC_EMAIL_PREFIXES = setOf("owner", "admin", "info", "contact", "support", "hello", "mail")

        fun deriveOwnerNameFromEmail(email: String): String {
            val clean = email.trim()
            if (clean.isBlank() || !clean.contains("@")) return ""
            val localPart = clean.substringBefore("@").trim()
            if (localPart.lowercase(Locale.US) in GENERIC_EMAIL_PREFIXES) {
                return ""
            }
            return localPart
                .split('.', '_', '-', '+')
                .filter { it.isNotBlank() }
                .joinToString(" ") { part ->
                    part.lowercase(Locale.US).replaceFirstChar { ch -> ch.titlecase(Locale.US) }
                }
        }
    }
}
