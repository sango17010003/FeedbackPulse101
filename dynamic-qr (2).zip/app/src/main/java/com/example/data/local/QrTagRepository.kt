package com.example.data.local

import kotlinx.coroutines.flow.Flow

class QrTagRepository(private val dao: QrTagDao) {
    val allTags: Flow<List<QrTagEntity>> = dao.getAllTags()
    val totalCount: Flow<Int> = dao.countAll()
    val linkedCount: Flow<Int> = dao.countLinked()
    val unlinkedCount: Flow<Int> = dao.countUnlinked()
    val totalScans: Flow<Int?> = dao.sumScans()

    fun getTagById(id: Long): Flow<QrTagEntity?> = dao.getTagById(id)
    fun getTagBySerial(serial: String): Flow<QrTagEntity?> = dao.getTagBySerial(serial)
    suspend fun findTagBySerial(serial: String): QrTagEntity? = dao.findTagBySerial(serial)
    fun searchTags(query: String): Flow<List<QrTagEntity>> = dao.searchTags(query)

    suspend fun insertTag(tag: QrTagEntity): Long = dao.insertTag(tag)
    suspend fun insertTags(tags: List<QrTagEntity>): List<Long> = dao.insertTags(tags)
    suspend fun updateTag(tag: QrTagEntity) = dao.updateTag(tag)
    suspend fun deleteTag(tag: QrTagEntity) = dao.deleteTag(tag)
    suspend fun deleteTagById(id: Long) = dao.deleteTagById(id)
    suspend fun recordScan(serial: String) = dao.recordScan(serial)
}
