package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "feedback_logs")
data class FeedbackLogEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val standSlug: String,
    val shopName: String,
    val totalScore: Int,
    val customerPhone: String? = null,
    val customerComment: String,
    val status: String = STATUS_PENDING,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isPending: Boolean
        get() = status.equals(STATUS_PENDING, ignoreCase = true)

    companion object {
        const val STATUS_PENDING = "pending"
        const val STATUS_RESOLVED = "resolved"
    }
}
