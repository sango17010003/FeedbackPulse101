package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FeedbackLogEntity
import com.example.data.local.QrTagEntity
import com.example.ui.theme.AmberLightContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanLightContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldLightContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoLightContainer
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.RoseError
import com.example.ui.theme.RoseLightContainer
import com.example.ui.theme.SlateLightBorder
import com.example.ui.theme.SlateLightBorderSubtle
import com.example.ui.theme.SlateLightSurface
import com.example.ui.theme.SlateLightSurfaceVariant
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.viewmodel.ReviewStandUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class OwnerSectionFilter {
    ALL,
    REVIEWS,
    LEDGER
}

/**
 * Distinct Shop Owner Dashboard: displays ONLY the logged-in Shop Owner's specific customer
 * reviews and their own scoped local ledger data (never the Super Admin Global Registry),
 * plus a Delete Account action safeguarded by 2-OTP verification.
 */
@Composable
fun DashboardScreen(
    uiState: ReviewStandUiState,
    onRefresh: () -> Unit,
    onLogout: () -> Unit,
    onOpenSuperAdmin: () -> Unit,
    onOpenDeleteAccount: () -> Unit,
    onCancelDeleteAccount: () -> Unit,
    onSendDeleteOtp1: () -> Unit,
    onVerifyDeleteOtp1: () -> Unit,
    onConfirmDeleteOtp2: () -> Unit,
    onDeleteOtp1Change: (String) -> Unit,
    onDeleteOtp2Change: (String) -> Unit,
    onMarkTagNfcLinked: (serial: String, uid: String) -> Unit,
    buildQrUrlForStand: (String) -> String,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(OwnerSectionFilter.ALL) }
    var nfcTargetTag by remember { mutableStateOf<QrTagEntity?>(null) }
    var qrPreviewTag by remember { mutableStateOf<QrTagEntity?>(null) }

    val allOwnerLedgerTags = remember(uiState.ownerLedgerTags, uiState.unlinkedSerials) {
        uiState.ownerLedgerTags + uiState.unlinkedSerials
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Shop Owner Header Card
        item {
            Surface(
                color = SlateLightSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, SlateLightBorderSubtle),
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "My Shop Reviews & Ledger",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            if (!uiState.loggedInEmail.isNullOrBlank()) {
                                Text(
                                    text = uiState.loggedInEmail,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (uiState.isSuperAdmin) {
                                IconButton(
                                    onClick = onOpenSuperAdmin,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("open_super_admin_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = "Super Admin Global Registry",
                                        tint = IndigoPrimary
                                    )
                                }
                            }

                            IconButton(
                                onClick = onRefresh,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("refresh_dashboard_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Refresh owner dashboard",
                                    tint = IndigoPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Account Actions Row: Logout & Delete Account (with 2-OTP guard)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onLogout,
                            border = BorderStroke(1.dp, SlateLightBorder),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimaryLight),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Logout", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onOpenDeleteAccount,
                            border = BorderStroke(1.dp, RoseError.copy(alpha = 0.55f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = RoseLightContainer,
                                contentColor = RoseError
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(44.dp)
                                .testTag("delete_account_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteForever,
                                contentDescription = "Delete Shop Owner Account",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delete Account", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section Filter Tabs (Reviews vs Local Ledger)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedFilter == OwnerSectionFilter.ALL,
                    onClick = { selectedFilter = OwnerSectionFilter.ALL },
                    label = {
                        Text(
                            "All (${uiState.reviews.size + allOwnerLedgerTags.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IndigoLightContainer,
                        selectedLabelColor = IndigoPrimary
                    ),
                    modifier = Modifier.testTag("owner_filter_all")
                )

                FilterChip(
                    selected = selectedFilter == OwnerSectionFilter.REVIEWS,
                    onClick = { selectedFilter = OwnerSectionFilter.REVIEWS },
                    label = {
                        Text(
                            "Reviews (${uiState.reviews.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IndigoLightContainer,
                        selectedLabelColor = IndigoPrimary
                    ),
                    modifier = Modifier.testTag("owner_filter_reviews")
                )

                FilterChip(
                    selected = selectedFilter == OwnerSectionFilter.LEDGER,
                    onClick = { selectedFilter = OwnerSectionFilter.LEDGER },
                    label = {
                        Text(
                            "Local Ledger (${allOwnerLedgerTags.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IndigoLightContainer,
                        selectedLabelColor = IndigoPrimary
                    ),
                    modifier = Modifier.testTag("owner_filter_ledger")
                )
            }
        }

        // SECTION 1: Owner's Specific Customer Reviews
        if (selectedFilter == OwnerSectionFilter.ALL || selectedFilter == OwnerSectionFilter.REVIEWS) {
            item {
                Text(
                    text = "SHOP REVIEWS (${uiState.reviews.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiaryLight,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (uiState.reviews.isEmpty()) {
                item {
                    Surface(
                        color = SlateLightSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, SlateLightBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No customer reviews submitted for your shops yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextTertiaryLight,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(uiState.reviews, key = { "rev_${it.id}" }) { review ->
                    OwnerReviewCard(review = review)
                }
            }
        }

        // SECTION 2: Owner's Scoped Local Ledger Data
        if (selectedFilter == OwnerSectionFilter.ALL || selectedFilter == OwnerSectionFilter.LEDGER) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                            contentDescription = null,
                            tint = IndigoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "MY LOCAL LEDGER DATA (${allOwnerLedgerTags.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextTertiaryLight,
                            letterSpacing = 1.sp
                        )
                    }

                    val totalCollected = allOwnerLedgerTags.sumOf { it.moneyReceived }
                    Text(
                        text = "Paid: ₹${"%.0f".format(totalCollected)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldLight
                    )
                }
            }

            if (allOwnerLedgerTags.isEmpty()) {
                item {
                    Surface(
                        color = SlateLightSurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, SlateLightBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No local ledger entries found for this owner account.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextTertiaryLight,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(allOwnerLedgerTags, key = { "ledger_${it.serialNumber}" }) { tag ->
                    OwnerLocalLedgerCard(
                        tag = tag,
                        onPreviewQr = { qrPreviewTag = tag },
                        onWriteNfc = { nfcTargetTag = tag }
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    // Shop QR Modal triggered from a Local Ledger entry
    qrPreviewTag?.let { tag ->
        val payloadUrl = buildQrUrlForStand(tag.serialNumber)
        ShopQrCodeModal(
            serialNumber = tag.serialNumber,
            shopName = tag.effectiveShopName,
            qrPayloadUrl = payloadUrl,
            destinationReviewUrl = tag.googleReviewUrl,
            onDismiss = { qrPreviewTag = null },
            onWriteNfc = {
                qrPreviewTag = null
                nfcTargetTag = tag
            }
        )
    }

    // Write to NFC Tag Modal triggered from a Local Ledger entry
    nfcTargetTag?.let { tag ->
        val dynamicUrl = buildQrUrlForStand(tag.serialNumber)
        WriteNfcTagModal(
            standSlug = tag.serialNumber,
            shopName = tag.effectiveShopName,
            dynamicFeedbackUrl = dynamicUrl,
            onDismiss = { nfcTargetTag = null },
            onWriteSuccess = { info ->
                onMarkTagNfcLinked(tag.serialNumber, info.uid)
            }
        )
    }

    // 2-OTP Account Deletion Verification Modal (protects against accidental clicks)
    if (uiState.showDeleteAccountDialog) {
        DeleteAccount2OtpDialog(
            email = uiState.loggedInEmail.orEmpty(),
            step = uiState.deleteAccountStep,
            otp1 = uiState.deleteOtp1Input,
            otp2 = uiState.deleteOtp2Input,
            statusMessage = uiState.deleteAuthMsg,
            busy = uiState.deleteBusy,
            onOtp1Change = onDeleteOtp1Change,
            onOtp2Change = onDeleteOtp2Change,
            onSendOtp1 = onSendDeleteOtp1,
            onVerifyOtp1 = onVerifyDeleteOtp1,
            onConfirmDeleteOtp2 = onConfirmDeleteOtp2,
            onCancel = onCancelDeleteAccount
        )
    }
}

@Composable
private fun OwnerReviewCard(review: FeedbackLogEntity) {
    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy · hh:mm a", Locale.getDefault()) }

    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("review_card_${review.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = IndigoLightContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Stand #${review.standSlug}",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .testTag("review_stand_number_${review.id}")
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = dateFormatter.format(Date(review.createdAt)),
                    fontSize = 11.sp,
                    color = TextTertiaryLight,
                    modifier = Modifier.testTag("review_time_${review.id}")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = review.customerComment,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimaryLight,
                modifier = Modifier.testTag("review_comment_${review.id}")
            )
        }
    }
}

@Composable
private fun OwnerLocalLedgerCard(
    tag: QrTagEntity,
    onPreviewQr: () -> Unit,
    onWriteNfc: () -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()) }

    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("owner_ledger_card_${tag.serialNumber}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = IndigoLightContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = tag.serialNumber,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    color = if (tag.isLinked) EmeraldLightContainer else AmberLightContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (tag.isLinked) "Linked" else "Unlinked Serial",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (tag.isLinked) EmeraldLight else AmberWarning,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = tag.effectiveShopName,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Text(
                text = "Batch: ${tag.batchName} · Created ${dateFormatter.format(Date(tag.createdAt))}",
                fontSize = 12.sp,
                color = TextSecondaryLight
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("QRs Taken", fontSize = 10.sp, color = TextTertiaryLight)
                        Text(
                            text = "${tag.qrCountTaken}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                    }
                }
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Ledger Paid", fontSize = 10.sp, color = TextTertiaryLight)
                        Text(
                            text = "${tag.currency}${"%.0f".format(tag.moneyReceived)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldLight
                        )
                    }
                }
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Scans", fontSize = 10.sp, color = TextTertiaryLight)
                        Text(
                            text = "${tag.scanCount}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = IndigoPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onPreviewQr,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("ledger_preview_qr_${tag.serialNumber}")
                ) {
                    Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Preview QR", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onWriteNfc,
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = CyanLightContainer,
                        contentColor = CyanAccent
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(44.dp)
                        .testTag("ledger_write_nfc_${tag.serialNumber}")
                ) {
                    Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (tag.nfcLinked) "NFC Linked ✓" else "Write to NFC Tag",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun DeleteAccount2OtpDialog(
    email: String,
    step: Int,
    otp1: String,
    otp2: String,
    statusMessage: String?,
    busy: Boolean,
    onOtp1Change: (String) -> Unit,
    onOtp2Change: (String) -> Unit,
    onSendOtp1: () -> Unit,
    onVerifyOtp1: () -> Unit,
    onConfirmDeleteOtp2: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        containerColor = SlateLightSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (step == 0) Icons.Default.Warning else Icons.Default.Shield,
                    contentDescription = "Account Deletion 2-OTP Verification",
                    tint = RoseError,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Delete Account (2-OTP Guard)",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
            }
        },
        text = {
            Column {
                // Step progress indicators
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = if (step >= 2) EmeraldLightContainer else IndigoLightContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (step >= 2) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "OTP 1 verified",
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = if (step >= 2) "1st OTP ✓" else "1st OTP",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (step >= 2) EmeraldLight else IndigoPrimary
                            )
                        }
                    }

                    Surface(
                        color = if (step == 2) RoseLightContainer else SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "2nd Final OTP",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (step == 2) RoseError else TextTertiaryLight,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (step) {
                    0 -> {
                        Surface(
                            color = RoseLightContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Activated by mistake?",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = RoseError
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Deleting $email removes your stands, local ledger records, and shop reviews. Two separate OTP verifications are required so you never lose data by accident.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimaryLight
                                )
                            }
                        }
                    }

                    1 -> {
                        Text(
                            text = "Step 1 of 2: Enter the 1st 6-digit OTP sent to $email.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = otp1,
                            onValueChange = onOtp1Change,
                            label = { Text("1st Verification OTP") },
                            placeholder = { Text("Enter 1st 6-digit OTP") },
                            enabled = !busy,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("delete_otp1_input")
                        )
                    }

                    else -> {
                        Text(
                            text = "Step 2 of 2 (Final): Enter the 2nd distinct 6-digit OTP to permanently delete $email.",
                            style = MaterialTheme.typography.bodySmall,
                            color = RoseError,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = otp2,
                            onValueChange = onOtp2Change,
                            label = { Text("2nd Final OTP") },
                            placeholder = { Text("Enter 2nd 6-digit OTP") },
                            enabled = !busy,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("delete_otp2_input")
                        )
                    }
                }

                if (!statusMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = IndigoLightContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = IndigoPrimary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            when (step) {
                0 -> {
                    Button(
                        onClick = onSendOtp1,
                        enabled = !busy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoseError,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("send_delete_otp1_button")
                    ) {
                        if (busy) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("Send 1st Deletion OTP", fontWeight = FontWeight.Bold)
                    }
                }

                1 -> {
                    Button(
                        onClick = onVerifyOtp1,
                        enabled = !busy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("verify_delete_otp1_button")
                    ) {
                        if (busy) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("Verify 1st & Send 2nd OTP", fontWeight = FontWeight.Bold)
                    }
                }

                else -> {
                    Button(
                        onClick = onConfirmDeleteOtp2,
                        enabled = !busy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RoseError,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("confirm_delete_account_button")
                    ) {
                        if (busy) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("Confirm Delete Account", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onCancel,
                enabled = !busy,
                modifier = Modifier.testTag("cancel_delete_account_button")
            ) {
                Text(
                    text = if (step == 0) "Cancel (Keep Account)" else "Abort & Keep Account",
                    color = TextSecondaryLight,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        modifier = Modifier.testTag("delete_account_2otp_dialog")
    )
}
