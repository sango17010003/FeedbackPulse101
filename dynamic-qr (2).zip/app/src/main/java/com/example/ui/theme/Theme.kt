package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = IndigoPrimary,
    onPrimary = Color.White,
    primaryContainer = IndigoLightContainer,
    onPrimaryContainer = IndigoDark,
    secondary = EmeraldSuccess,
    onSecondary = Color.White,
    secondaryContainer = EmeraldLightContainer,
    onSecondaryContainer = EmeraldLight,
    tertiary = CyanAccent,
    onTertiary = Color.White,
    tertiaryContainer = CyanLightContainer,
    onTertiaryContainer = CyanAccentGlow,
    background = SlateLightBackground,
    onBackground = TextPrimaryLight,
    surface = SlateLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = SlateLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = SlateLightBorder,
    outlineVariant = SlateLightBorderSubtle,
    error = RoseError,
    onError = Color.White,
    errorContainer = RoseLightContainer,
    onErrorContainer = RoseError
)

@Composable
fun DynamicQrTheme(
    content: @Composable () -> Unit
) {
    // Strictly Light Mode per user requirement (dark mode removed)
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
