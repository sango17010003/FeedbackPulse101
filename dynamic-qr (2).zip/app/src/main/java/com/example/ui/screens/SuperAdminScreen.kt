package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FeedbackLogEntity
import com.example.data.local.QrStandEntity
import com.example.data.local.QrTagEntity
import com.example.ui.theme.AmberLightContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanLightContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldLightContainer
import com.example.ui.theme.IndigoLightContainer
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.RoseError
import com.example.ui.theme.RoseLightContainer
import com.example.ui.theme.SlateLightBorder
import com.example.ui.theme.SlateLightBorderSubtle
import com.example.ui.theme.SlateLightSurface
import com.example.ui.theme.SlateLightSurfaceVariant
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.viewmodel.ReviewStandUiState
import com.example.util.WhatsAppHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dedicated Super Admin Global Shop Registry screen.
 * Completely separate from individual Shop Owners' dashboards.
 */
@Composable
fun SuperAdminScreen(
    uiState: ReviewStandUiState,
    onSearchQueryChange: (String) -> Unit,
    onSlugChange: (String) -> Unit,
    onShopNameChange: (String) -> Unit,
    onOwnerNameChange: (String) -> Unit,
    onOwnerEmailChange: (String) -> Unit,
    onMapsLinkChange: (String) -> Unit,
    onPreviewDirectLink: () -> Unit,
    onSaveGlobalStand: () -> Unit,
    onEditStand: (QrStandEntity) -> Unit,
    onCancelEdit: () -> Unit,
    onTestReviewUrl: (String) -> Unit,
    onOpenStandSurvey: (String) -> Unit,
    onToggleReviewStatus: (FeedbackLogEntity) -> Unit,
    onRefreshGlobal: () -> Unit,
    onSwitchToOwnerView: () -> Unit,
    onLogout: () -> Unit,
    buildQrUrlForStand: (String) -> String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var feedbackFilter by remember { mutableStateOf("ALL") }
    var nfcTargetStand by remember { mutableStateOf<QrStandEntity?>(null) }
    var qrModalStand by remember { mutableStateOf<QrStandEntity?>(null) }

    val filteredStands = remember(uiState.superAdminStands, uiState.superAdminSearchQuery) {
        val q = uiState.superAdminSearchQuery.trim()
        if (q.isBlank()) uiState.superAdminStands
        else uiState.superAdminStands.filter {
            it.shopName.contains(q, ignoreCase = true) ||
                it.standSlug.contains(q, ignoreCase = true) ||
                it.ownerName.contains(q, ignoreCase = true) ||
                it.ownerEmail.contains(q, ignoreCase = true)
        }
    }

    val filteredReviews = remember(uiState.superAdminReviews, feedbackFilter, uiState.superAdminSearchQuery) {
        val q = uiState.superAdminSearchQuery.trim()
        uiState.superAdminReviews
            .filter {
                when (feedbackFilter) {
                    "PENDING" -> it.isPending
                    "RESOLVED" -> !it.isPending
                    else -> true
                }
            }
            .filter {
                q.isBlank() ||
                    it.shopName.contains(q, ignoreCase = true) ||
                    it.standSlug.contains(q, ignoreCase = true) ||
                    it.customerComment.contains(q, ignoreCase = true)
            }
    }

    val uniqueOwnersCount = remember(uiState.superAdminStands) {
        uiState.superAdminStands.map { it.ownerEmail.trim().lowercase() }.filter { it.isNotBlank() }.toSet().size
    }
    val pendingCount = remember(uiState.superAdminReviews) {
        uiState.superAdminReviews.count { it.isPending }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("super_admin_screen_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Super Admin Header Card
        item {
            Surface(
                color = SlateLightSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, IndigoLightContainer),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Surface(
                                color = IndigoLightContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = IndigoPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "SUPER ADMIN · GLOBAL REGISTRY",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = uiState.loggedInEmail.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onRefreshGlobal,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("refresh_super_admin_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh global registry", tint = IndigoPrimary)
                            }
                            OutlinedButton(
                                onClick = onLogout,
                                border = BorderStroke(1.dp, RoseLightContainer),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = RoseError),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .height(40.dp)
                                    .testTag("super_admin_logout_button")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Logout", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Global KPI strip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SuperAdminStatChip("Stands", uiState.superAdminStands.size.toString(), IndigoPrimary, Modifier.weight(1f))
                        SuperAdminStatChip("Merchants", uniqueOwnersCount.toString(), EmeraldLight, Modifier.weight(1f))
                        SuperAdminStatChip("Pending Issues", pendingCount.toString(), RoseError, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onSwitchToOwnerView,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("switch_to_owner_dashboard_button")
                    ) {
                        Icon(Icons.Default.Storefront, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open My Personal Shop View", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // 2. Global Shop Registry Stand Registration / Editor Form
        item {
            val isEditing = uiState.editingSlug != null
            Surface(
                color = SlateLightSurface,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.5.dp, if (isEditing) AmberWarning else IndigoLightContainer),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("super_admin_registry_editor")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isEditing) "Edit Global Stand (#${uiState.editingSlug})" else "Register Shop in Global Registry",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                        if (isEditing) {
                            TextButton(onClick = onCancelEdit) {
                                Text("New", fontSize = 12.sp)
                            }
                        }
                    }

                    Text(
                        text = "Assign any Stand ID to any Shop Owner email and auto-convert their Google Maps link into a direct Write-Review modal.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = if (isEditing) uiState.editingSlug.orEmpty() else uiState.newSlug,
                        onValueChange = onSlugChange,
                        enabled = !isEditing,
                        label = { Text("Stand ID / Unique Serial") },
                        placeholder = { Text("e.g. stand3 or TR-4821-KMP") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = SlateLightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_stand_slug_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = uiState.newShopName,
                        onValueChange = onShopNameChange,
                        label = { Text("Shop Name") },
                        placeholder = { Text("e.g. Sharma Bakery") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = SlateLightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_shop_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = uiState.newOwnerName,
                        onValueChange = onOwnerNameChange,
                        label = { Text("Shop Owner Name") },
                        placeholder = { Text("e.g. Rahul Sharma") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = SlateLightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_owner_name_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = uiState.newOwnerEmail,
                        onValueChange = onOwnerEmailChange,
                        label = { Text("Assigned Owner Email") },
                        placeholder = { Text("owner@shop.com") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = SlateLightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_owner_email_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = uiState.mapsLink,
                        onValueChange = onMapsLinkChange,
                        label = { Text("Google Maps Share Link / Place ID") },
                        placeholder = { Text("maps.app.goo.gl/..., share.google/..., or Place URL") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = SlateLightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_maps_link_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = onPreviewDirectLink,
                        enabled = !uiState.busy && uiState.mapsLink.isNotBlank(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("admin_convert_review_link_button")
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Convert to Write-Review Modal URL", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    if (uiState.resolvedDirectReviewUrl.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = EmeraldLightContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("resolved_direct_review_box")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (uiState.resolvedOpensWriteReviewModal) {
                                        "DIRECT WRITE-REVIEW MODAL DESTINATION"
                                    } else {
                                        "DIRECT REVIEWS TAB DESTINATION"
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldLight
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = uiState.resolvedDirectReviewUrl,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimaryLight,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { onTestReviewUrl(uiState.resolvedDirectReviewUrl) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Test Review Page", fontSize = 12.sp)
                                    }
                                    Button(
                                        onClick = {
                                            val currentSerial = (uiState.editingSlug ?: uiState.newSlug).trim()
                                                .ifBlank { uiState.lastSavedStandSlug.ifBlank { uiState.standSlug } }
                                            val currentShopName = uiState.newShopName.trim()
                                                .ifBlank { uiState.shop?.shopName ?: "Stand #$currentSerial" }
                                            qrModalStand = QrStandEntity(
                                                standSlug = currentSerial,
                                                shopName = currentShopName,
                                                googleReviewUrl = uiState.resolvedDirectReviewUrl,
                                                ownerEmail = uiState.newOwnerEmail,
                                                ownerName = uiState.newOwnerName
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary, contentColor = Color.White),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(40.dp)
                                            .testTag("preview_qr_resolver_button")
                                    ) {
                                        Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Preview QR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onSaveGlobalStand,
                        enabled = !uiState.busy,
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary, contentColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_save_stand_button")
                    ) {
                        if (uiState.busy) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(
                            text = if (isEditing) "Update Global Shop Stand" else "Register Shop Stand",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (!uiState.editorMsg.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = uiState.editorMsg,
                            style = MaterialTheme.typography.bodySmall,
                            color = IndigoPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // 3. Global Search Input
        item {
            OutlinedTextField(
                value = uiState.superAdminSearchQuery,
                onValueChange = onSearchQueryChange,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondaryLight) },
                placeholder = { Text("Search shop name, stand ID, or owner email...") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = SlateLightBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("super_admin_search_input")
            )
        }

        // 4. Global Registered Stands
        item {
            Text(
                text = "Global Shop Registry (${filteredStands.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
        }

        if (filteredStands.isEmpty()) {
            item {
                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SlateLightBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No shops match the global registry filter.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextTertiaryLight,
                        modifier = Modifier.padding(20.dp)
                    )
                }
            }
        } else {
            items(filteredStands, key = { "global_${it.standSlug}" }) { stand ->
                val qrUrl = buildQrUrlForStand(stand.standSlug)
                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SlateLightBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("global_stand_${stand.standSlug}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    color = IndigoLightContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "#${stand.standSlug}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (stand.displayOwnerName.isNotBlank()) {
                                        "${stand.displayOwnerName} · ${stand.ownerEmail}"
                                    } else {
                                        stand.ownerEmail
                                    },
                                    fontSize = 11.sp,
                                    color = TextSecondaryLight,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = { qrModalStand = stand },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .testTag("admin_show_qr_${stand.standSlug}")
                                ) {
                                    Icon(Icons.Default.QrCode2, contentDescription = "Show QR code modal for ${stand.standSlug}", tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                                }
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Stand QR URL", qrUrl))
                                        Toast.makeText(context, "Copied $qrUrl", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy QR link", tint = TextSecondaryLight, modifier = Modifier.size(16.dp))
                                }
                                IconButton(
                                    onClick = { nfcTargetStand = stand },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Default.Nfc, contentDescription = "Write NFC tag", tint = CyanAccent, modifier = Modifier.size(18.dp))
                                }
                                IconButton(
                                    onClick = { onEditStand(stand) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit stand", tint = IndigoPrimary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = stand.shopName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = stand.googleReviewUrl,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextTertiaryLight,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onOpenStandSurvey(stand.standSlug) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("Preview Survey", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { onTestReviewUrl(stand.googleReviewUrl) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Test Review Link", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // 5. Global Customer Feedback Audit
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Global Customer Feedback (${filteredReviews.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ALL" to "All", "PENDING" to "Pending", "RESOLVED" to "Resolved").forEach { (key, label) ->
                    FilterChip(
                        selected = feedbackFilter == key,
                        onClick = { feedbackFilter = key },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IndigoLightContainer,
                            selectedLabelColor = IndigoPrimary
                        )
                    )
                }
            }
        }

        items(filteredReviews, key = { "global_rev_${it.id}" }) { review ->
            NegativeReviewCard(
                review = review,
                onToggleStatus = { onToggleReviewStatus(review) },
                onCallPhone = { phone -> WhatsAppHelper.openDialer(context, phone) },
                onWhatsAppPhone = { phone ->
                    val msg = "Hello, thank you for sharing feedback about ${review.shopName}."
                    WhatsAppHelper.sendWhatsAppMessage(context, phone, msg)
                }
            )
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    qrModalStand?.let { stand ->
        ShopQrCodeModal(
            serialNumber = stand.standSlug,
            shopName = stand.shopName,
            qrPayloadUrl = buildQrUrlForStand(stand.standSlug),
            destinationReviewUrl = stand.googleReviewUrl,
            onDismiss = { qrModalStand = null },
            onWriteNfc = { nfcTargetStand = stand }
        )
    }

    nfcTargetStand?.let { stand ->
        WriteNfcTagModal(
            standSlug = stand.standSlug,
            shopName = stand.shopName,
            dynamicFeedbackUrl = buildQrUrlForStand(stand.standSlug),
            onDismiss = { nfcTargetStand = null },
            onWriteSuccess = { info ->
                Toast.makeText(
                    context,
                    "NFC tag ${info.uid} written with ${stand.standSlug} feedback URL",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }
}

@Composable
private fun SuperAdminStatChip(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SlateLightSurfaceVariant,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
            Text(
                text = label,
                fontSize = 11.sp,
                color = TextSecondaryLight,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun NegativeReviewCard(
    review: FeedbackLogEntity,
    onToggleStatus: () -> Unit,
    onCallPhone: (String) -> Unit,
    onWhatsAppPhone: (String) -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()) }

    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("review_card_${review.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${review.shopName} (#${review.standSlug})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = dateFormatter.format(Date(review.createdAt)),
                        fontSize = 11.sp,
                        color = TextTertiaryLight
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    color = if (review.totalScore <= 6) RoseLightContainer else AmberLightContainer,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "${review.totalScore}/15",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (review.totalScore <= 6) RoseError else AmberWarning,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = review.customerComment,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val phone = review.customerPhone
                if (!phone.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = CyanLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.clickable { onCallPhone(phone) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Call, contentDescription = "Call customer", tint = CyanAccent, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(phone, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = CyanAccent)
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { onWhatsAppPhone(phone) },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("whatsapp_customer_${review.id}")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Chat,
                                contentDescription = "Message customer on WhatsApp",
                                tint = EmeraldLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                } else {
                    Text(
                        text = "No phone provided",
                        fontSize = 11.sp,
                        color = TextTertiaryLight
                    )
                }

                Surface(
                    color = if (review.isPending) RoseLightContainer else EmeraldLightContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .clickable(onClick = onToggleStatus)
                        .testTag("toggle_status_${review.id}")
                ) {
                    Text(
                        text = if (review.isPending) "pending" else "resolved",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (review.isPending) RoseError else EmeraldLight,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}
