package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.util.GoogleReviewLinkHelper
import com.example.util.ReviewLinkResult
import kotlinx.coroutines.launch

@Composable
fun LinkGeneratorScreen(
    onAssignToQr: (generatedUrl: String, shopName: String?) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var inputLink by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var linkResult by remember { mutableStateOf<ReviewLinkResult?>(null) }
    var showPreviewQrModal by remember { mutableStateOf(false) }

    fun processLink(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) {
            linkResult = null
            return
        }
        isProcessing = true
        coroutineScope.launch {
            val result = GoogleReviewLinkHelper.generateDirectReviewLink(trimmed)
            linkResult = result
            isProcessing = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateLightBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("link_generator_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Direct Review Link Generator",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Convert Google Maps links into direct 5-star review selection popups",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight
                )
            }
            Surface(
                color = AmberLightContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.RateReview,
                    contentDescription = null,
                    tint = AmberWarning,
                    modifier = Modifier
                        .padding(10.dp)
                        .size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Input Card
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, SlateLightBorder),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Enter Google Maps or Place Link",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Paste a Google Maps share URL (maps.app.goo.gl), Place ID (ChIJ...), or CID:",
                    fontSize = 12.sp,
                    color = TextSecondaryLight
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = inputLink,
                    onValueChange = {
                        inputLink = it
                        if (it.isNotBlank()) {
                            processLink(it)
                        } else {
                            linkResult = null
                        }
                    },
                    label = { Text("Google Link / Place ID / Maps URL *") },
                    placeholder = { Text("e.g. https://maps.app.goo.gl/... or ChIJ...") },
                    leadingIcon = {
                        Icon(Icons.Default.Place, contentDescription = null, tint = CyanAccent)
                    },
                    trailingIcon = {
                        if (inputLink.isNotEmpty()) {
                            IconButton(onClick = {
                                inputLink = ""
                                linkResult = null
                            }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondaryLight)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = SlateLightBorder,
                        focusedTextColor = TextPrimaryLight,
                        unfocusedTextColor = TextPrimaryLight,
                        focusedContainerColor = SlateLightSurface,
                        unfocusedContainerColor = SlateLightSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("google_link_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Action Chips (Paste from Clipboard & Sample Presets)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val item = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
                            if (!item.isNullOrBlank()) {
                                inputLink = item
                                processLink(item)
                                Toast.makeText(context, "Pasted from clipboard", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(14.dp), tint = TextSecondaryLight)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Paste Clipboard", fontSize = 11.sp, color = TextPrimaryLight)
                    }

                    OutlinedButton(
                        onClick = {
                            val samplePlaceId = "ChIJN1t_tDeuEmsRUsoyG83frY4"
                            inputLink = samplePlaceId
                            processLink(samplePlaceId)
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyanAccent)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sample Place ID", fontSize = 11.sp, color = CyanAccent)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Convert Button
                Button(
                    onClick = { processLink(inputLink) },
                    enabled = inputLink.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("convert_link_button")
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Resolving & Converting...", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Generate Direct Review Link", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // RESULT CARD
        if (linkResult != null && linkResult!!.directReviewUrl.isNotBlank()) {
            val result = linkResult!!

            Surface(
                color = SlateLightSurface,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.5.dp, EmeraldSuccess),
                shadowElevation = 3.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("direct_review_result_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = EmeraldLightContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = EmeraldSuccess,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Direct Review Link Generated",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextPrimaryLight
                                )
                                Text(
                                    text = result.linkType,
                                    fontSize = 11.sp,
                                    color = EmeraldLight,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Surface(
                            color = EmeraldLightContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Skips Overview",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldLight,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // How it works comparison
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = RoseError, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Standard Google Maps Link:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextSecondaryLight
                                    )
                                    Text(
                                        text = "Lands on place search, overview tab, photos, contact info, and requires the customer to manually scroll down to find 'Write a review'.",
                                        fontSize = 11.sp,
                                        color = TextSecondaryLight
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Generated Direct Review Link:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldLight
                                    )
                                    Text(
                                        text = "Directly triggers the Google Reviews dialog! The 5-star rating selection and review textbox appear instantly on screen.",
                                        fontSize = 11.sp,
                                        color = TextPrimaryLight,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Primary: Direct Google Maps Review & Rating Link Box
                    Text(
                        text = "DIRECT GOOGLE MAPS REVIEW & RATING LINK",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldSuccess,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Direct Review Link", result.googleMapsReviewUrl))
                                Toast.makeText(context, "Google Maps review link copied!", Toast.LENGTH_SHORT).show()
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = result.googleMapsReviewUrl,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = IndigoPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Optional: Secondary write review dialog link if available
                    if (!result.writeReviewUrl.isNullOrBlank() && result.writeReviewUrl != result.googleMapsReviewUrl) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "5-STAR WRITE REVIEW MODAL LINK (OPTIONAL)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextTertiaryLight,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            color = SlateLightSurfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, SlateLightBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Write Review Link", result.writeReviewUrl))
                                    Toast.makeText(context, "Write review link copied!", Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = result.writeReviewUrl,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextSecondaryLight,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = TextSecondaryLight,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action Buttons Row (Direct Write Review Popup, Open in Maps & Copy)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // 1. Primary: Direct Write Review Popup (Opens 5-star rating & review prompt directly)
                        val writeTarget = result.writeReviewUrl ?: result.directReviewUrl
                        Button(
                            onClick = {
                                try {
                                    val uri = Uri.parse(writeTarget)
                                    val intent = Intent(Intent.ACTION_VIEW, uri)
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Could not open review popup", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberWarning,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("open_write_review_popup_button")
                        ) {
                            Icon(Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("✍️ Open Direct Write Review Popup", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 2. Open in Google Maps button
                            OutlinedButton(
                                onClick = {
                                    try {
                                        val uri = Uri.parse(result.googleMapsReviewUrl)
                                        val mapIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                                            setPackage("com.google.android.apps.maps")
                                        }
                                        if (mapIntent.resolveActivity(context.packageManager) != null) {
                                            context.startActivity(mapIntent)
                                        } else {
                                            val browserIntent = Intent(Intent.ACTION_VIEW, uri)
                                            context.startActivity(browserIntent)
                                        }
                                    } catch (e: Exception) {
                                        val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(result.googleMapsReviewUrl))
                                        context.startActivity(fallbackIntent)
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, SlateLightBorder),
                                modifier = Modifier
                                    .weight(1.1f)
                                    .height(44.dp)
                                    .testTag("open_in_google_maps_button")
                            ) {
                                Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(15.dp), tint = TextSecondaryLight)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Open on Maps", fontSize = 11.sp, color = TextPrimaryLight, fontWeight = FontWeight.SemiBold)
                            }

                            // 3. Copy Button
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Direct Review Link", writeTarget))
                                    Toast.makeText(context, "Direct write review link copied!", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, SlateLightBorder),
                                modifier = Modifier
                                    .weight(0.9f)
                                    .height(44.dp)
                                    .testTag("copy_direct_link_button")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp), tint = TextPrimaryLight)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy Link", color = TextPrimaryLight, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 4. Preview QR Button (Generates ZXing QR in small modal overlay for currently viewed shop)
                    OutlinedButton(
                        onClick = { showPreviewQrModal = true },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, IndigoPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("preview_qr_resolver_button")
                    ) {
                        Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp), tint = IndigoPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Preview QR", color = IndigoPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Primary Button: Assign to Dynamic QR Code
                    Button(
                        onClick = {
                            onAssignToQr(result.googleMapsReviewUrl, result.placeName)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldSuccess,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("assign_link_to_qr_button")
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Assign to Dynamic QR Code", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // GUIDE CARD: Where to find Place ID / Maps Link
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SlateLightBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Supported Link Formats",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimaryLight
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val formats = listOf(
                    "Google Maps Share URLs" to "maps.app.goo.gl/... or goo.gl/maps/...",
                    "Google Place IDs" to "ChIJN1t_tDeuEmsRUsoyG83frY4",
                    "Google Maps Browser URLs" to "google.com/maps/place/Shop+Name/@...",
                    "Google Business Profiles" to "g.page/r/...",
                    "Google CID Numbers" to "maps.google.com/?cid=123456789..."
                )

                formats.forEach { (title, example) ->
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(text = "• $title", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimaryLight)
                        Text(text = "   $example", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TextSecondaryLight)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    if (showPreviewQrModal && linkResult != null) {
        val currentResult = linkResult!!
        val targetQrUrl = currentResult.writeReviewUrl?.takeIf { it.isNotBlank() }
            ?: currentResult.directReviewUrl
        val shopSerial = currentResult.placeId?.takeIf { it.isNotBlank() }
            ?: currentResult.placeName?.takeIf { it.isNotBlank() }
            ?: "PREVIEW-QR"
        ShopQrCodeModal(
            serialNumber = shopSerial,
            shopName = currentResult.placeName ?: "Resolved Shop Review",
            qrPayloadUrl = targetQrUrl,
            destinationReviewUrl = currentResult.googleMapsReviewUrl,
            onDismiss = { showPreviewQrModal = false }
        )
    }
}
