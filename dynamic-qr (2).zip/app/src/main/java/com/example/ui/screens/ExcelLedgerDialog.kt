package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.util.ExcelExportHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LedgerSortColumn {
    SERIAL,
    SHOP_NAME,
    WHATSAPP,
    QRS_TAKEN,
    MONEY_RECEIVED,
    STATUS,
    DATE
}

@Composable
fun ExcelLedgerDialog(
    tags: List<QrTagEntity>,
    onDismiss: () -> Unit,
    onExportExcel: () -> Unit
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    var searchQuery by remember { mutableStateOf("") }
    var sortColumn by remember { mutableStateOf(LedgerSortColumn.MONEY_RECEIVED) }
    var sortAscending by remember { mutableStateOf(false) }

    val filteredAndSortedList = remember(tags, searchQuery, sortColumn, sortAscending) {
        val filtered = if (searchQuery.isBlank()) {
            tags
        } else {
            val q = searchQuery.trim().lowercase()
            tags.filter {
                it.serialNumber.lowercase().contains(q) ||
                it.effectiveShopName.lowercase().contains(q) ||
                (it.effectiveWhatsApp?.lowercase()?.contains(q) == true) ||
                (it.notes?.lowercase()?.contains(q) == true)
            }
        }

        when (sortColumn) {
            LedgerSortColumn.SERIAL -> {
                if (sortAscending) filtered.sortedBy { it.serialNumber }
                else filtered.sortedByDescending { it.serialNumber }
            }
            LedgerSortColumn.SHOP_NAME -> {
                if (sortAscending) filtered.sortedBy { it.effectiveShopName.lowercase() }
                else filtered.sortedByDescending { it.effectiveShopName.lowercase() }
            }
            LedgerSortColumn.WHATSAPP -> {
                if (sortAscending) filtered.sortedBy { it.effectiveWhatsApp ?: "" }
                else filtered.sortedByDescending { it.effectiveWhatsApp ?: "" }
            }
            LedgerSortColumn.QRS_TAKEN -> {
                if (sortAscending) filtered.sortedBy { it.qrCountTaken }
                else filtered.sortedByDescending { it.qrCountTaken }
            }
            LedgerSortColumn.MONEY_RECEIVED -> {
                if (sortAscending) filtered.sortedBy { it.moneyReceived }
                else filtered.sortedByDescending { it.moneyReceived }
            }
            LedgerSortColumn.STATUS -> {
                if (sortAscending) filtered.sortedBy { if (it.isLinked) 1 else 0 }
                else filtered.sortedByDescending { if (it.isLinked) 1 else 0 }
            }
            LedgerSortColumn.DATE -> {
                if (sortAscending) filtered.sortedBy { it.linkedAt ?: it.createdAt }
                else filtered.sortedByDescending { it.linkedAt ?: it.createdAt }
            }
        }
    }

    val linkedTags = tags.filter { it.isLinked }
    val totalRevenue = linkedTags.sumOf { it.moneyReceived }
    val totalQrsTaken = linkedTags.sumOf { it.qrCountTaken }
    val currency = tags.firstOrNull()?.currency ?: "₹"

    fun onHeaderClick(column: LedgerSortColumn) {
        if (sortColumn == column) {
            sortAscending = !sortAscending
        } else {
            sortColumn = column
            sortAscending = when (column) {
                LedgerSortColumn.MONEY_RECEIVED, LedgerSortColumn.QRS_TAKEN -> false
                else -> true
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .testTag("excel_ledger_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = SlateLightSurface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = EmeraldLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Shop Registry & Excel Ledger",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Sortable merchant database · Tap column headers to rank",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("close_ledger_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Metric Summary Cards Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$currency${"%.0f".format(totalRevenue)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EmeraldLight)
                            Text(text = "TOTAL REVENUE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                        }
                    }

                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$totalQrsTaken", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                            Text(text = "QRS TAKEN", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                        }
                    }

                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${linkedTags.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                            Text(text = "SHOPS ONBOARDED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar at Top of Excel Ledger
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Filter table by serial, shop name, or phone...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CyanAccent) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondaryLight)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = SlateLightBorder,
                        focusedTextColor = TextPrimaryLight,
                        unfocusedTextColor = TextPrimaryLight,
                        focusedContainerColor = SlateLightSurface,
                        unfocusedContainerColor = SlateLightSurface
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("ledger_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Interactive Sort Legend
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Showing ${filteredAndSortedList.size} of ${tags.size} records",
                        fontSize = 11.sp,
                        color = TextSecondaryLight
                    )
                    Text(
                        text = "Sorted by: ${sortColumn.name.replace('_', ' ')} (${if (sortAscending) "Asc ▲" else "Desc ▼"})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CyanAccent
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Tabular Ledger View with Clickable Sorting Headers
                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    val hScroll = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(hScroll)
                    ) {
                        // Clickable Table Headers
                        Row(
                            modifier = Modifier
                                .background(SlateLightSurfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SortableHeaderCell(
                                title = "SERIAL NUMBER",
                                column = LedgerSortColumn.SERIAL,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 135.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.SERIAL) }
                            )

                            SortableHeaderCell(
                                title = "SHOP NAME",
                                column = LedgerSortColumn.SHOP_NAME,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 190.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.SHOP_NAME) }
                            )

                            SortableHeaderCell(
                                title = "WHATSAPP",
                                column = LedgerSortColumn.WHATSAPP,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 140.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.WHATSAPP) }
                            )

                            SortableHeaderCell(
                                title = "QRS TAKEN",
                                column = LedgerSortColumn.QRS_TAKEN,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 105.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.QRS_TAKEN) }
                            )

                            SortableHeaderCell(
                                title = "MONEY REC'D",
                                column = LedgerSortColumn.MONEY_RECEIVED,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 120.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.MONEY_RECEIVED) }
                            )

                            SortableHeaderCell(
                                title = "STATUS",
                                column = LedgerSortColumn.STATUS,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 100.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.STATUS) }
                            )

                            SortableHeaderCell(
                                title = "DATE ASSIGNED",
                                column = LedgerSortColumn.DATE,
                                currentSort = sortColumn,
                                isAscending = sortAscending,
                                width = 120.dp,
                                onClick = { onHeaderClick(LedgerSortColumn.DATE) }
                            )

                            Text(
                                text = "GOOGLE REVIEWS LINK",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = TextTertiaryLight,
                                modifier = Modifier.width(220.dp)
                            )
                        }

                        HorizontalDivider(color = SlateLightBorder)

                        if (filteredAndSortedList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No records match your search filter", color = TextSecondaryLight, fontSize = 13.sp)
                            }
                        } else {
                            LazyColumn(modifier = Modifier.weight(1f)) {
                                items(filteredAndSortedList, key = { it.id }) { tag ->
                                    Row(
                                        modifier = Modifier
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = tag.serialNumber,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = TextPrimaryLight,
                                            modifier = Modifier.width(135.dp)
                                        )
                                        Text(
                                            text = tag.effectiveShopName,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp,
                                            color = TextPrimaryLight,
                                            modifier = Modifier.width(190.dp)
                                        )
                                        Text(
                                            text = tag.effectiveWhatsApp ?: "-",
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp,
                                            color = Color(0xFF16A34A),
                                            modifier = Modifier.width(140.dp)
                                        )
                                        Text(
                                            text = if (tag.isLinked) "${tag.qrCountTaken}" else "-",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = TextPrimaryLight,
                                            modifier = Modifier.width(105.dp)
                                        )
                                        Text(
                                            text = if (tag.isLinked) "${tag.currency}${"%.0f".format(tag.moneyReceived)}" else "-",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = EmeraldLight,
                                            modifier = Modifier.width(120.dp)
                                        )
                                        Text(
                                            text = if (tag.isLinked) "Linked" else "Unlinked",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp,
                                            color = if (tag.isLinked) EmeraldLight else AmberWarning,
                                            modifier = Modifier.width(100.dp)
                                        )
                                        Text(
                                            text = tag.linkedAt?.let { dateFormat.format(Date(it)) } ?: dateFormat.format(Date(tag.createdAt)),
                                            fontSize = 11.sp,
                                            color = TextSecondaryLight,
                                            modifier = Modifier.width(120.dp)
                                        )
                                        Text(
                                            text = tag.googleReviewUrl ?: tag.destinationUrl ?: "-",
                                            fontSize = 11.sp,
                                            color = TextSecondaryLight,
                                            modifier = Modifier.width(220.dp)
                                        )
                                    }
                                    HorizontalDivider(color = SlateLightBorder.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Export Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val csv = ExcelExportHelper.generateCsvString(tags)
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Excel CSV Data", csv))
                            Toast.makeText(context, "CSV copied to clipboard! Paste into Excel.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("copy_csv_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp), tint = TextPrimaryLight)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy CSV", color = TextPrimaryLight, fontSize = 12.sp)
                    }

                    Button(
                        onClick = onExportExcel,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldSuccess,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("export_excel_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export to Excel (.CSV)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SortableHeaderCell(
    title: String,
    column: LedgerSortColumn,
    currentSort: LedgerSortColumn,
    isAscending: Boolean,
    width: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit
) {
    val isSelected = currentSort == column
    Row(
        modifier = Modifier
            .width(width)
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = if (isSelected) CyanAccent else TextTertiaryLight
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            imageVector = when {
                !isSelected -> Icons.Default.UnfoldMore
                isAscending -> Icons.Default.ArrowDropUp
                else -> Icons.Default.ArrowDropDown
            },
            contentDescription = "Sort $title",
            tint = if (isSelected) CyanAccent else TextTertiaryLight.copy(alpha = 0.5f),
            modifier = Modifier.size(14.dp)
        )
    }
}
