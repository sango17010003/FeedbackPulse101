package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.util.QrCodeGenerator
import com.example.util.SerialGenerator
import com.example.util.WhatsAppHelper
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TagDetailsScreen(
    tag: QrTagEntity,
    onBack: () -> Unit,
    onEditLink: () -> Unit,
    onUnlink: () -> Unit,
    onDelete: () -> Unit,
    onSimulateReview: () -> Unit,
    onUpdateContact: (contactName: String?, contactPhone: String?) -> Unit,
    onNfcLinked: ((nfcUid: String) -> Unit)? = null
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy · HH:mm", Locale.getDefault()) }

    // Generate QR bitmap for display
    val qrImageBitmap = remember(tag.serialNumber) {
        val payload = SerialGenerator.buildQrPayload(tag.serialNumber)
        QrCodeGenerator.generateQrImageBitmap(payload, size = 400)
    }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showNfcDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (tag.isLinked) tag.effectiveShopName else "Dynamic QR Tag",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimaryLight,
                            maxLines = 1
                        )
                        Text(
                            text = tag.serialNumber,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = CyanAccent
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("details_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimaryLight
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onEditLink,
                        modifier = Modifier.testTag("details_edit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit shop details",
                            tint = CyanAccent
                        )
                    }
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.testTag("details_delete_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete tag",
                            tint = RoseError
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SlateLightSurface
                )
            )
        },
        containerColor = SlateLightBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // QR CODE HERO CARD
            Surface(
                color = SlateLightSurface,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, SlateLightBorder),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("details_qr_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Status Badge
                    Surface(
                        color = if (tag.isLinked) EmeraldLightContainer else AmberLightContainer,
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = if (tag.isLinked) "● Linked to Shop & Google Reviews" else "● Unlinked / Ready for Assignment",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (tag.isLinked) EmeraldLight else AmberWarning,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // QR Code Image
                    Surface(
                        color = Color.White,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier.size(220.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            if (qrImageBitmap != null) {
                                Image(
                                    bitmap = qrImageBitmap,
                                    contentDescription = "Dynamic QR Code for ${tag.serialNumber}",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = tag.serialNumber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimaryLight
                    )

                    val payloadUrl = SerialGenerator.buildQrPayload(tag.serialNumber)
                    Text(
                        text = payloadUrl,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondaryLight,
                        modifier = Modifier
                            .clickable {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("QR URL", payloadUrl))
                                Toast.makeText(context, "URL copied to clipboard", Toast.LENGTH_SHORT).show()
                            }
                            .padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action Buttons under QR
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val bitmap = QrCodeGenerator.generateStickerBitmap(tag.serialNumber, payloadUrl, tag.effectiveShopName)
                                shareBitmap(context, bitmap, tag.serialNumber)
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CyanAccent),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Sticker", color = CyanAccent, fontSize = 12.sp)
                        }

                        if (tag.isLinked) {
                            Button(
                                onClick = onSimulateReview,
                                colors = ButtonDefaults.buttonColors(containerColor = AmberWarning, contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1.3f)
                            ) {
                                Icon(Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test Review Gate", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        } else {
                            Button(
                                onClick = onEditLink,
                                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1.3f)
                            ) {
                                Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Link Shop Now", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SHOP & BUSINESS LEDGER CARD (If linked)
            if (tag.isLinked) {
                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Storefront, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Registered Shop Details", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimaryLight)
                            }

                            IconButton(onClick = onEditLink, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = CyanAccent, modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(text = tag.effectiveShopName, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                        if (!tag.address.isNullOrBlank()) {
                            Text(text = tag.address, fontSize = 12.sp, color = TextSecondaryLight, modifier = Modifier.padding(top = 2.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Excel Ledger Metrics: QRs Taken & Money Received
                        Surface(
                            color = SlateLightSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SlateLightBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "QRS TAKEN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                                    Text(text = "${tag.qrCountTaken}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                                }
                                Box(modifier = Modifier.width(1.dp).height(28.dp).background(SlateLightBorder))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "MONEY RECEIVED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                                    Text(text = "${tag.currency}${"%.0f".format(tag.moneyReceived)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = EmeraldLight)
                                }
                                Box(modifier = Modifier.width(1.dp).height(28.dp).background(SlateLightBorder))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "TOTAL SCANS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                                    Text(text = "${tag.scanCount}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                                }
                            }
                        }

                        // Owner WhatsApp Section
                        val phone = tag.effectiveWhatsApp
                        if (!phone.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(text = "OWNER WHATSAPP NUMBER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = phone, fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = Color(0xFF16A34A))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilledTonalButton(
                                        onClick = {
                                            val msg = WhatsAppHelper.buildShopWelcomeMessage(
                                                shopName = tag.effectiveShopName,
                                                serial = tag.serialNumber,
                                                qrCount = tag.qrCountTaken,
                                                moneyReceived = tag.moneyReceived,
                                                currency = tag.currency,
                                                googleReviewUrl = tag.googleReviewUrl
                                            )
                                            WhatsAppHelper.sendWhatsAppMessage(context, phone, msg)
                                        },
                                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFDCFCE7), contentColor = Color(0xFF16A34A)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { WhatsAppHelper.openDialer(context, phone) },
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, SlateLightBorder),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(14.dp), tint = TextPrimaryLight)
                                    }
                                }
                            }
                        }

                        // Shop Instagram Page Section
                        val instaUrl = tag.effectiveInstagramUrl
                        if (!instaUrl.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(text = "SHOP INSTAGRAM PAGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color(0xFFE1306C), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = tag.instagramHandle ?: "@shop",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimaryLight
                                    )
                                }

                                FilledTonalButton(
                                    onClick = {
                                        try {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(instaUrl)))
                                        } catch (_: Exception) {
                                            Toast.makeText(context, "Could not open Instagram", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFCE7F3), contentColor = Color(0xFFE1306C)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Instagram", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Assigned Link Destination Row (Google Reviews & Direct Write Review)
                        val reviewUrl = tag.effectiveGoogleReviewUrl
                        val writeReviewUrl = tag.effectiveDirectWriteReviewUrl
                        if (!reviewUrl.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "GOOGLE REVIEWS DESTINATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiaryLight)
                                Surface(color = AmberLightContainer, shape = RoundedCornerShape(4.dp)) {
                                    Text(
                                        text = "⚡ Direct Write Review Popup",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AmberWarning,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = SlateLightSurfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, SlateLightBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = writeReviewUrl,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = IndigoPrimary,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(writeReviewUrl))
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {
                                                    Toast.makeText(context, "Could not open URL", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Write Review Popup", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                try {
                                                    val uri = Uri.parse(reviewUrl)
                                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                                } catch (_: Exception) {
                                                    Toast.makeText(context, "Could not open Maps", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            border = BorderStroke(1.dp, SlateLightBorder),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(13.dp), tint = TextSecondaryLight)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Open on Maps", fontSize = 11.sp, color = TextSecondaryLight)
                                        }
                                    }
                                }
                            }
                        }

                        // NFC Tag Pairing & Standee Section
                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            color = SlateLightSurfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (tag.nfcLinked) EmeraldSuccess else SlateLightBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Nfc, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "NFC Tag (Opens same link)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimaryLight
                                        )
                                        Text(
                                            text = if (tag.nfcLinked) "✓ NFC Linked (UID: ${tag.nfcTagUid ?: "Active"})" else "Physical NFC tag ready to pair",
                                            fontSize = 10.sp,
                                            color = if (tag.nfcLinked) EmeraldLight else TextSecondaryLight
                                        )
                                    }
                                }

                                Button(
                                    onClick = { showNfcDialog = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (tag.nfcLinked) EmeraldSuccess else CyanAccent,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier
                                        .height(32.dp)
                                        .testTag("details_program_nfc_button")
                                ) {
                                    Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (tag.nfcLinked) "NFC Paired" else "Program NFC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // REPUTATION & FEEDBACK METRICS CARD
            Surface(
                color = SlateLightSurface,
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, SlateLightBorder),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Trust Review Gate Rules", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimaryLight)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. Customer scans QR code -> lands on TR Reviewers portal.\n2. Positive Rating: Review text is auto-copied to clipboard and user is redirected to Google Reviews.\n3. Constructive Rating: Feedback is saved privately and sent to owner's WhatsApp.",
                        fontSize = 12.sp,
                        color = TextSecondaryLight,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            color = EmeraldLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("HIGH PRAISE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = EmeraldLight)
                                Text("${tag.positiveReviewsCount} Redirects", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = EmeraldLight)
                            }
                        }

                        Surface(
                            color = AmberLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("PRIVATE FEEDBACK", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AmberWarning)
                                Text("${tag.privateFeedbacksCount} Captured", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AmberWarning)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // UNLINK / RESET BUTTON
            if (tag.isLinked) {
                OutlinedButton(
                    onClick = onUnlink,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, AmberWarning),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("unlink_tag_button")
                ) {
                    Icon(Icons.Default.LinkOff, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Unlink & Reset to Ready State", color = AmberWarning, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Dynamic QR Tag?") },
            text = { Text("Are you sure you want to delete ${tag.serialNumber}? This removes it from the database and Excel ledger.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseError)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = TextSecondaryLight)
                }
            },
            containerColor = SlateLightSurface,
            titleContentColor = TextPrimaryLight,
            textContentColor = TextSecondaryLight
        )
    }

    if (showNfcDialog) {
        NfcLinkerDialog(
            tag = tag,
            onDismiss = { showNfcDialog = false },
            onNfcLinked = { nfcUid ->
                showNfcDialog = false
                onNfcLinked?.invoke(nfcUid)
            }
        )
    }
}

private fun shareBitmap(context: Context, bitmap: android.graphics.Bitmap, serial: String) {
    try {
        val cachePath = File(context.cacheDir, "stickers").apply { mkdirs() }
        val file = File(cachePath, "sticker_$serial.png")
        FileOutputStream(file).use { stream ->
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, stream)
        }

        val contentUri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            putExtra(Intent.EXTRA_TEXT, "Dynamic QR Tag ($serial)")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Sticker"))
    } catch (_: Exception) {
        Toast.makeText(context, "Could not share sticker", Toast.LENGTH_SHORT).show()
    }
}
