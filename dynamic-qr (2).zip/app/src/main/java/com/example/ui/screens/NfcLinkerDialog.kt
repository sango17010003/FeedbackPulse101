package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.util.NfcLinkingHelper
import com.example.util.NfcTagInfo
import com.example.util.NfcWriteState
import com.example.util.SerialGenerator

@Composable
fun NfcLinkerDialog(
    tag: QrTagEntity,
    onDismiss: () -> Unit,
    onNfcLinked: (nfcUid: String) -> Unit
) {
    val context = LocalContext.current

    val targetUrl = remember(tag.serialNumber) {
        SerialGenerator.buildQrPayload(tag.serialNumber)
    }

    val isNfcSupported = remember { NfcLinkingHelper.isNfcSupported(context) }
    val isNfcEnabled = remember { NfcLinkingHelper.isNfcEnabled(context) }

    val writeState by NfcLinkingHelper.writeState.collectAsState()

    var nfcInfo by remember {
        mutableStateOf<NfcTagInfo?>(
            if (tag.nfcLinked) {
                NfcTagInfo(
                    uid = tag.nfcTagUid ?: "NFC-${tag.serialNumber.takeLast(6)}",
                    payloadUrl = targetUrl,
                    serialNumber = tag.serialNumber
                )
            } else null
        )
    }

    LaunchedEffect(writeState) {
        when (val state = writeState) {
            is NfcWriteState.Success -> {
                nfcInfo = state.info
                onNfcLinked(state.info.uid)
                Toast.makeText(context, "⚡ NFC Tag successfully written & linked!", Toast.LENGTH_SHORT).show()
            }
            is NfcWriteState.Error -> {
                Toast.makeText(context, "Write Error: ${state.message}", Toast.LENGTH_LONG).show()
            }
            else -> {}
        }
    }

    // Animation for pulsing radar during waiting state
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Dialog(
        onDismissRequest = {
            NfcLinkingHelper.cancelWaitingForTag()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.88f)
                .testTag("nfc_linker_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = SlateLightSurface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Top Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = CyanLightContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Nfc,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "NFC Tag Linker & Writer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Write dynamic URL to empty NFC tags by tapping against phone",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            NfcLinkingHelper.cancelWaitingForTag()
                            onDismiss()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("close_nfc_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Body
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Merchant & Serial Info Card
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "MERCHANT SHOP",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextTertiaryLight,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = tag.effectiveShopName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryLight
                                    )
                                }
                                Surface(
                                    color = if (nfcInfo != null) EmeraldLightContainer else AmberLightContainer,
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Text(
                                        text = if (nfcInfo != null) "● NFC Linked" else "● NFC Ready to Link",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (nfcInfo != null) EmeraldLight else AmberWarning,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "SERIAL: ${tag.serialNumber}",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Shared URL Card (Both QR & NFC open this exact same link)
                    Surface(
                        color = SlateLightSurface,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.5.dp, CyanAccent),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.SyncAlt, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "DYNAMIC URL TO WRITE TO NFC TAG",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyanAccent
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = SlateLightSurfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Shared NFC Link", targetUrl))
                                        Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = targetUrl,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "✓ A customer tapping the NFC counter standee OR scanning the QR code opens this exact same portal.",
                                fontSize = 11.sp,
                                color = EmeraldLight,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // INTERACTIVE NFC WRITER STATE CARD
                    when (writeState) {
                        is NfcWriteState.WaitingForTag -> {
                            Surface(
                                color = CyanLightContainer,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.5.dp, CyanAccent),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .scale(pulseScale)
                                            .background(CyanAccent.copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Nfc,
                                            contentDescription = null,
                                            tint = CyanAccent,
                                            modifier = Modifier.size(40.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    Text(
                                        text = "READY TO WRITE TO NFC TAG",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "Bring an empty NFC tag or counter standee near the phone's NFC reader (back of device)...",
                                        fontSize = 12.sp,
                                        color = TextSecondaryLight,
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { NfcLinkingHelper.cancelWaitingForTag() },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Cancel", fontSize = 11.sp, color = TextSecondaryLight)
                                        }

                                        Button(
                                            onClick = {
                                                val sim = NfcLinkingHelper.simulateTagWrite(tag.serialNumber, targetUrl)
                                                nfcInfo = sim
                                                onNfcLinked(sim.uid)
                                                Toast.makeText(context, "Simulated tag tap: Written successfully!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1.4f)
                                        ) {
                                            Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Simulate Tap", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        is NfcWriteState.Writing -> {
                            Surface(
                                color = SlateLightSurfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.5.dp, AmberWarning),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        color = AmberWarning,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("Writing to NFC Tag...", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimaryLight)
                                        Text("Keep tag still against the phone reader", fontSize = 11.sp, color = TextSecondaryLight)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        else -> {}
                    }

                    // Linked Tag Details (When programmed)
                    AnimatedVisibility(visible = nfcInfo != null) {
                        Column(modifier = Modifier.padding(bottom = 14.dp)) {
                            Surface(
                                color = EmeraldLightContainer,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.5.dp, EmeraldSuccess),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("NFC Chip Programmed & Active", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldLight)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Tag UID: ${nfcInfo?.uid}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                                    Text("Chip Type: ${nfcInfo?.type}", fontSize = 11.sp, color = TextSecondaryLight)
                                    Text("Payload: ${nfcInfo?.payloadUrl}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = IndigoPrimary)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "✓ Ready to place as an NFC table puck or counter standee.",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = EmeraldLight
                                    )
                                }
                            }
                        }
                    }

                    // Hardware Sensor Information
                    Surface(
                        color = if (isNfcSupported && isNfcEnabled) EmeraldLightContainer else SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isNfcSupported) Icons.Default.CheckCircle else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (isNfcSupported) EmeraldSuccess else CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isNfcSupported && isNfcEnabled) {
                                    "Physical NFC Sensor Active: Hold tag near back of phone to write"
                                } else if (isNfcSupported && !isNfcEnabled) {
                                    "NFC is turned OFF in device settings. Please enable NFC or use Simulator."
                                } else {
                                    "NFC Programmer & Simulator Ready (Supports all NTAG213/215 chips)"
                                },
                                fontSize = 11.sp,
                                color = TextPrimaryLight,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Test Button (opens destination)
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("test_nfc_link_button")
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp), tint = TextPrimaryLight)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Link", fontSize = 12.sp, color = TextPrimaryLight)
                    }

                    // Primary Button: "Write to NFC Tag (Bring Near Reader)"
                    val isWaiting = writeState is NfcWriteState.WaitingForTag
                    Button(
                        onClick = {
                            if (isWaiting) {
                                NfcLinkingHelper.cancelWaitingForTag()
                            } else {
                                NfcLinkingHelper.startWaitingForTag(tag.serialNumber, targetUrl)
                                Toast.makeText(context, "Bring empty NFC tag near phone reader...", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isWaiting) RoseError else CyanAccent,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1.6f)
                            .height(46.dp)
                            .testTag("program_nfc_tag_button")
                    ) {
                        Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isWaiting) "Cancel NFC Write" else if (nfcInfo != null) "Re-Write NFC Tag" else "Write to NFC Tag",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
