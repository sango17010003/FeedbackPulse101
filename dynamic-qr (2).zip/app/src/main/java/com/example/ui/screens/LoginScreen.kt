package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberLightContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldLightContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoLightContainer
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SlateLightBorder
import com.example.ui.theme.SlateLightBorderSubtle
import com.example.ui.theme.SlateLightSurface
import com.example.ui.theme.SlateLightSurfaceVariant
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.viewmodel.ReviewStandUiState

@Composable
fun LoginScreen(
    uiState: ReviewStandUiState,
    onOwnerNameChange: (String) -> Unit,
    onBelow18CheckedChange: (Boolean) -> Unit,
    onConfirmParentalConsentPrompt: (String) -> Unit,
    onDismissParentalConsentPrompt: () -> Unit,
    onOpenParentalConsentPrompt: () -> Unit,
    onParentGuardianNameChange: (String) -> Unit,
    onParentConsentChange: (Boolean) -> Unit,
    onEmailChange: (String) -> Unit,
    onOtpChange: (String) -> Unit,
    onSendOtp: () -> Unit,
    onVerifyOtp: () -> Unit,
    onResetOtp: () -> Unit,
    onDemoOwnerPrefill: () -> Unit,
    onDemoSuperAdminPrefill: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, SlateLightBorderSubtle),
            shadowElevation = 2.dp,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_card")
        ) {
            Column(modifier = Modifier.padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = IndigoLightContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = "Merchant & Admin Login",
                            tint = IndigoPrimary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Merchant & Admin Login",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "Sign in with email OTP to open your Shop Owner Dashboard or Super Admin Registry",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                OutlinedTextField(
                    value = uiState.ownerNameInput,
                    onValueChange = onOwnerNameChange,
                    label = { Text("Shop Owner Name (displayed on review page)") },
                    placeholder = { Text("e.g. Rahul Sharma") },
                    enabled = !uiState.otpSent && !uiState.busy,
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = SlateLightBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_owner_name_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Checkbox field asking whether the shop owner is below 18
                Surface(
                    color = if (uiState.isBelow18Checked) AmberLightContainer else SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (uiState.isBelow18Checked) AmberWarning.copy(alpha = 0.6f) else SlateLightBorderSubtle
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !uiState.busy) {
                            onBelow18CheckedChange(!uiState.isBelow18Checked)
                        }
                        .testTag("below_18_checkbox_row")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Checkbox(
                            checked = uiState.isBelow18Checked,
                            onCheckedChange = onBelow18CheckedChange,
                            enabled = !uiState.busy,
                            colors = CheckboxDefaults.colors(
                                checkedColor = AmberWarning,
                                checkmarkColor = Color.White
                            ),
                            modifier = Modifier.testTag("below_18_checkbox")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Shop owner is below 18 years of age",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = if (uiState.isBelow18Checked) {
                                    "Checked: parental or legal guardian consent is required."
                                } else {
                                    "Leave unchecked if you are 18 or older."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = uiState.isBelow18Checked) {
                    Column {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = if (uiState.parentConsentChecked && uiState.parentGuardianNameInput.isNotBlank()) {
                                EmeraldLightContainer
                            } else {
                                AmberLightContainer
                            },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(
                                1.dp,
                                if (uiState.parentConsentChecked && uiState.parentGuardianNameInput.isNotBlank()) {
                                    EmeraldSuccess.copy(alpha = 0.5f)
                                } else {
                                    AmberWarning.copy(alpha = 0.5f)
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("parent_consent_card")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VerifiedUser,
                                            contentDescription = "Parental Consent",
                                            tint = if (uiState.parentConsentChecked && uiState.parentGuardianNameInput.isNotBlank()) {
                                                EmeraldSuccess
                                            } else {
                                                AmberWarning
                                            },
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (uiState.parentConsentChecked && uiState.parentGuardianNameInput.isNotBlank()) {
                                                "Parental Consent Recorded"
                                            } else {
                                                "Parental Consent Required"
                                            },
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimaryLight
                                        )
                                    }

                                    TextButton(
                                        onClick = onOpenParentalConsentPrompt,
                                        modifier = Modifier.testTag("reopen_parental_prompt_button")
                                    ) {
                                        Text("Open Prompt", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = uiState.parentGuardianNameInput,
                                    onValueChange = onParentGuardianNameChange,
                                    label = { Text("Parent / Guardian Full Name") },
                                    placeholder = { Text("e.g. Rajesh Sharma") },
                                    enabled = !uiState.busy,
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AmberWarning,
                                        unfocusedBorderColor = SlateLightBorder,
                                        focusedContainerColor = SlateLightSurface,
                                        unfocusedContainerColor = SlateLightSurface
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("parent_guardian_name_input")
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .clickable(enabled = !uiState.busy) {
                                            onParentConsentChange(!uiState.parentConsentChecked)
                                        }
                                        .testTag("parent_consent_checkbox_row")
                                ) {
                                    Checkbox(
                                        checked = uiState.parentConsentChecked,
                                        onCheckedChange = onParentConsentChange,
                                        enabled = !uiState.busy,
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = EmeraldSuccess,
                                            checkmarkColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("parent_consent_checkbox")
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "I confirm parent or legal guardian consent for this under-18 shop owner account.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimaryLight
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = uiState.emailInput,
                    onValueChange = onEmailChange,
                    label = { Text("Email") },
                    placeholder = { Text("owner@yourshop.com") },
                    enabled = !uiState.otpSent && !uiState.busy,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = SlateLightBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_email_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                if (!uiState.otpSent) {
                    Button(
                        onClick = onSendOtp,
                        enabled = !uiState.busy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("send_otp_button")
                    ) {
                        if (uiState.busy) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(
                            text = if (uiState.busy) "Sending OTP..." else "Send Login OTP",
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = uiState.otpInput,
                        onValueChange = onOtpChange,
                        label = { Text("6-digit OTP") },
                        placeholder = { Text("Enter 6-digit OTP") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldSuccess,
                            unfocusedBorderColor = SlateLightBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_otp_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onVerifyOtp,
                        enabled = !uiState.busy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldSuccess,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("verify_otp_button")
                    ) {
                        if (uiState.busy) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(
                            text = if (uiState.busy) "Verifying..." else "Verify & Login",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TextButton(
                        onClick = onResetOtp,
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .testTag("change_email_button")
                    ) {
                        Text(
                            text = "Use different email",
                            color = TextSecondaryLight,
                            fontSize = 13.sp
                        )
                    }
                }

                if (!uiState.authMsg.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = IndigoLightContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_message_banner")
                    ) {
                        Text(
                            text = uiState.authMsg,
                            style = MaterialTheme.typography.bodySmall,
                            color = IndigoPrimary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }

        if (!uiState.isSupabaseConfigured) {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                color = SlateLightSurfaceVariant,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SlateLightBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Preview Mode Roles",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Configure SUPABASE_URL & SUPABASE_ANON_KEY in AI Studio Secrets for live OTP emails, or preview the split views below:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onDemoOwnerPrefill,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("demo_shop_owner_button")
                    ) {
                        Text("Preview Shop Owner Dashboard", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onDemoSuperAdminPrefill,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("demo_super_admin_button")
                    ) {
                        Text("Preview Super Admin Registry", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    // Prompt shown immediately whenever user checks "Shop owner is below 18 years of age"
    if (uiState.showParentalConsentPrompt) {
        ParentalConsentPromptDialog(
            initialGuardianName = uiState.parentGuardianNameInput,
            initialConsentChecked = uiState.parentConsentChecked,
            onConfirm = { guardian ->
                onConfirmParentalConsentPrompt(guardian)
            },
            onCancelNotMinor = {
                onBelow18CheckedChange(false)
            },
            onDismiss = onDismissParentalConsentPrompt
        )
    }
}

@Composable
private fun ParentalConsentPromptDialog(
    initialGuardianName: String,
    initialConsentChecked: Boolean,
    onConfirm: (String) -> Unit,
    onCancelNotMinor: () -> Unit,
    onDismiss: () -> Unit
) {
    var guardianName by remember(initialGuardianName) { mutableStateOf(initialGuardianName) }
    var consentChecked by remember(initialConsentChecked) { mutableStateOf(initialConsentChecked) }
    var localError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SlateLightSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "Parental Consent",
                    tint = AmberWarning,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Parental Consent Prompt",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "Because you selected that the shop owner is below 18, a parent or legal guardian must authorize this registration.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = guardianName,
                    onValueChange = {
                        guardianName = it
                        localError = null
                    },
                    label = { Text("Parent / Guardian Full Name") },
                    placeholder = { Text("e.g. Rajesh Sharma") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("prompt_guardian_name_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clickable {
                            consentChecked = !consentChecked
                            localError = null
                        }
                        .testTag("prompt_consent_checkbox_row")
                ) {
                    Checkbox(
                        checked = consentChecked,
                        onCheckedChange = {
                            consentChecked = it
                            localError = null
                        },
                        colors = CheckboxDefaults.colors(
                            checkedColor = EmeraldSuccess,
                            checkmarkColor = Color.White
                        ),
                        modifier = Modifier.testTag("prompt_consent_checkbox")
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "I am the parent or legal guardian and give consent for this shop owner account.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimaryLight
                    )
                }
                if (!localError.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = localError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberWarning,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when {
                        guardianName.trim().isBlank() -> {
                            localError = "Please enter Parent / Guardian Full Name."
                        }
                        !consentChecked -> {
                            localError = "Please check the parental consent box to confirm."
                        }
                        else -> onConfirm(guardianName.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldSuccess,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_parental_consent_button")
            ) {
                Text("Confirm Consent", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onCancelNotMinor,
                modifier = Modifier.testTag("cancel_under18_button")
            ) {
                Text("I'm 18 or older", color = TextSecondaryLight)
            }
        },
        modifier = Modifier.testTag("parental_consent_dialog")
    )
}
