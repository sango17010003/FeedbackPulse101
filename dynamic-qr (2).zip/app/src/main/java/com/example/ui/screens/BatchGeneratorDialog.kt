package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.util.SoundHapticHelper

@Composable
fun BatchGeneratorDialog(
    unlinkedTags: List<QrTagEntity>,
    onDismiss: () -> Unit,
    onGenerateBatch: (count: Int, prefix: String, batchName: String, notes: String?) -> Unit,
    onLinkTag: (QrTagEntity) -> Unit
) {
    val context = LocalContext.current

    var quantityInput by remember { mutableStateOf("10") }
    var prefixInput by remember { mutableStateOf("TR-") }
    var batchNameInput by remember { mutableStateOf("Sticker Roll #1") }
    var batchNotesInput by remember { mutableStateOf("Pre-printed dynamic QRs for merchant rollout") }

    var sessionGeneratedSerials by remember { mutableStateOf<List<String>>(emptyList()) }

    val displayList = remember(unlinkedTags, sessionGeneratedSerials) {
        if (sessionGeneratedSerials.isNotEmpty()) {
            unlinkedTags.filter { it.serialNumber in sessionGeneratedSerials }
                .ifEmpty { unlinkedTags.take(sessionGeneratedSerials.size) }
        } else {
            unlinkedTags
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .testTag("batch_generator_modal"),
            shape = RoundedCornerShape(24.dp),
            color = SlateLightSurface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = CyanLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.QrCode2,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Generate Batch Serials",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Creates 'unlinked' status codes with unique IDs",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("close_batch_modal_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quantity Input & Quick Chips
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "QUANTITY OF SERIAL NUMBERS REQUIRED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextTertiaryLight,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick Selector Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("5", "10", "25", "50", "100").forEach { preset ->
                                val isSelected = quantityInput == preset
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) CyanAccent else SlateLightSurface,
                                    border = BorderStroke(1.dp, if (isSelected) CyanAccent else SlateLightBorder),
                                    onClick = { quantityInput = preset }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = preset,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isSelected) Color.White else TextPrimaryLight
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Custom Numeric Input
                        OutlinedTextField(
                            value = quantityInput,
                            onValueChange = { quantityInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Exact Quantity (1 to 200)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = {
                                Icon(Icons.Default.Numbers, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = SlateLightBorder,
                                focusedTextColor = TextPrimaryLight,
                                unfocusedTextColor = TextPrimaryLight,
                                focusedContainerColor = SlateLightSurface,
                                unfocusedContainerColor = SlateLightSurface
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("batch_quantity_input")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Prefix & Name in row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = prefixInput,
                                onValueChange = { prefixInput = it.uppercase() },
                                label = { Text("Prefix") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanAccent,
                                    unfocusedBorderColor = SlateLightBorder,
                                    focusedTextColor = TextPrimaryLight,
                                    unfocusedTextColor = TextPrimaryLight,
                                    focusedContainerColor = SlateLightSurface,
                                    unfocusedContainerColor = SlateLightSurface
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                            )
                            OutlinedTextField(
                                value = batchNameInput,
                                onValueChange = { batchNameInput = it },
                                label = { Text("Batch Lot") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanAccent,
                                    unfocusedBorderColor = SlateLightBorder,
                                    focusedTextColor = TextPrimaryLight,
                                    unfocusedTextColor = TextPrimaryLight,
                                    focusedContainerColor = SlateLightSurface,
                                    unfocusedContainerColor = SlateLightSurface
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1.8f)
                                    .height(52.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Generate Button
                        Button(
                            onClick = {
                                val count = (quantityInput.toIntOrNull() ?: 10).coerceIn(1, 200)
                                onGenerateBatch(
                                    count,
                                    prefixInput.ifBlank { "TR-" },
                                    batchNameInput.ifBlank { "Batch Lot" },
                                    batchNotesInput.ifBlank { null }
                                )
                                SoundHapticHelper.playSuccessFeedback(context)
                                Toast.makeText(context, "Generated $count unlinked serial numbers!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("generate_unlinked_batch_button")
                        ) {
                            Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Generate ${quantityInput.ifBlank { "10" }} 'Unlinked' Serials",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Serials List Header with Copy All Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Unlinked Serials (${displayList.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )

                    if (displayList.isNotEmpty()) {
                        Button(
                            onClick = {
                                val allSerialsText = displayList.joinToString(separator = "\n") { it.serialNumber }
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("All Unlinked Serials", allSerialsText))
                                Toast.makeText(context, "Copied all ${displayList.size} serials to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldLightContainer,
                                contentColor = EmeraldLight
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("copy_all_serials_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy All (${displayList.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable List of Serials with individual Copy buttons
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (displayList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No unlinked serial numbers yet.\nClick generate above to create your first batch!",
                                color = TextSecondaryLight,
                                fontSize = 12.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(displayList, key = { it.id }) { tag ->
                                Surface(
                                    color = SlateLightSurface,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, SlateLightBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("batch_item_${tag.serialNumber}")
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = AmberLightContainer,
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text(
                                                    text = "Unlinked",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = AmberWarning,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = tag.serialNumber,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = TextPrimaryLight
                                                )
                                                Text(
                                                    text = tag.batchName,
                                                    fontSize = 11.sp,
                                                    color = TextSecondaryLight
                                                )
                                            }
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            // Copy to clipboard button
                                            IconButton(
                                                onClick = {
                                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                    clipboard.setPrimaryClip(ClipData.newPlainText("Serial", tag.serialNumber))
                                                    Toast.makeText(context, "${tag.serialNumber} copied!", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .background(SlateLightSurfaceVariant, RoundedCornerShape(8.dp))
                                                    .testTag("copy_serial_${tag.serialNumber}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.ContentCopy,
                                                    contentDescription = "Copy serial",
                                                    tint = CyanAccent,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }

                                            // Quick Link button
                                            Button(
                                                onClick = {
                                                    onDismiss()
                                                    onLinkTag(tag)
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = CyanAccent,
                                                    contentColor = Color.White
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                modifier = Modifier.height(34.dp)
                                            ) {
                                                Text("Link", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Close Button
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done / Close", color = TextPrimaryLight)
                }
            }
        }
    }
}
