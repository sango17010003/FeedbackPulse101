package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanLightContainer
import com.example.ui.theme.IndigoLightContainer
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SlateLightBorder
import com.example.ui.theme.SlateLightBorderSubtle
import com.example.ui.theme.SlateLightSurface
import com.example.ui.theme.SlateLightSurfaceVariant
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.util.QrCodeGenerator
import com.example.util.SerialGenerator
import java.io.File
import java.io.FileOutputStream

/**
 * Modal dialog displaying a dynamically generated ZXing QR code image for the current
 * shop serial number / stand ID, with copy, printable sticker download, and optional NFC linking.
 */
@Composable
fun ShopQrCodeModal(
    serialNumber: String,
    shopName: String? = null,
    qrPayloadUrl: String = SerialGenerator.buildQrPayload(serialNumber),
    destinationReviewUrl: String? = null,
    onDismiss: () -> Unit,
    onWriteNfc: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val cleanSerial = serialNumber.trim().ifBlank { "stand1" }
    val cleanPayload = qrPayloadUrl.trim().ifBlank { SerialGenerator.buildQrPayload(cleanSerial) }

    val qrImageBitmap = remember(cleanPayload) {
        QrCodeGenerator.generateQrImageBitmap(
            content = cleanPayload,
            size = 640
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SlateLightBorder),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.90f)
                .widthIn(max = 360.dp)
                .testTag("shop_qr_code_modal")
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = IndigoLightContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.QrCode2,
                                    contentDescription = null,
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = shopName?.takeIf { it.isNotBlank() } ?: "Shop Dynamic QR",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Generated dynamically via ZXing",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_qr_modal_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close QR Modal",
                            tint = TextSecondaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Active Shop Serial Number Badge
                Surface(
                    color = IndigoLightContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("qr_modal_serial_badge")
                ) {
                    Text(
                        text = "SERIAL: $cleanSerial",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = IndigoPrimary,
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("qr_modal_serial_text")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Crisp High-Contrast QR Code Frame
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.5.dp, SlateLightBorderSubtle),
                    shadowElevation = 2.dp
                ) {
                    Image(
                        bitmap = qrImageBitmap,
                        contentDescription = "QR code for shop serial $cleanSerial",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .padding(14.dp)
                            .size(196.dp)
                            .testTag("qr_modal_image")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Encoded Dynamic URL Card
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SlateLightBorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            copyQrUrlToClipboard(context, cleanPayload)
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = cleanPayload,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = IndigoPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("qr_modal_payload_text")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy QR URL",
                            tint = IndigoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                if (!destinationReviewUrl.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Destination: $destinationReviewUrl",
                        fontSize = 11.sp,
                        color = TextTertiaryLight,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Modal Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { copyQrUrlToClipboard(context, cleanPayload) },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("qr_modal_copy_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Link", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            saveShopQrStickerPng(
                                context = context,
                                serialNumber = cleanSerial,
                                qrUrl = cleanPayload,
                                shopName = shopName ?: "Scan to Share Feedback"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1.1f)
                            .height(48.dp)
                            .testTag("qr_modal_save_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save QR", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    if (onWriteNfc != null) {
                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onWriteNfc()
                            },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CyanAccent),
                            contentPadding = PaddingValues(horizontal = 10.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("qr_modal_nfc_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Nfc,
                                contentDescription = "Write to NFC tag",
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun copyQrUrlToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("Shop QR URL", text))
    Toast.makeText(context, "QR link copied to clipboard", Toast.LENGTH_SHORT).show()
}

fun saveShopQrStickerPng(
    context: Context,
    serialNumber: String,
    qrUrl: String,
    shopName: String = "Scan to Share Feedback"
) {
    try {
        val sticker = QrCodeGenerator.generateStickerBitmap(
            serialNumber = serialNumber,
            qrContent = qrUrl,
            batchName = shopName
        )
        val fileName = "${serialNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")}-qr.png"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "image/png")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DynamicQR")
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    sticker.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                Toast.makeText(context, "Saved to Downloads/DynamicQR/$fileName", Toast.LENGTH_LONG).show()
                return
            }
        }
        val cacheDir = File(context.cacheDir, "qr_exports").apply { mkdirs() }
        val file = File(cacheDir, fileName)
        FileOutputStream(file).use { out ->
            sticker.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Save or Share QR Sticker"))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not save QR: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
