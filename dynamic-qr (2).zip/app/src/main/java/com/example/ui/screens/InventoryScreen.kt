package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.StatsState
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    tags: List<QrTagEntity>,
    stats: StatsState,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    onSelectTag: (QrTagEntity) -> Unit,
    onLinkTag: (QrTagEntity) -> Unit,
    onSimulateReview: (QrTagEntity) -> Unit,
    onOpenExcelLedger: () -> Unit,
    onExportExcel: () -> Unit,
    onNewBatchClick: () -> Unit,
    onDomainSettingsClick: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateLightBackground)
            .padding(16.dp)
            .testTag("inventory_screen")
    ) {
        // App Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "TR Reviewers",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Dynamic QR Codes & Merchant Reputation Platform",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Excel Ledger Button
                IconButton(
                    onClick = onOpenExcelLedger,
                    modifier = Modifier
                        .background(EmeraldLightContainer, RoundedCornerShape(12.dp))
                        .size(42.dp)
                        .testTag("header_excel_ledger_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.TableChart,
                        contentDescription = "Excel Ledger",
                        tint = EmeraldSuccess
                    )
                }

                // Domain Settings Button
                IconButton(
                    onClick = onDomainSettingsClick,
                    modifier = Modifier
                        .background(SlateLightSurface, RoundedCornerShape(12.dp))
                        .size(42.dp)
                        .testTag("header_domain_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Domain Settings",
                        tint = CyanAccent
                    )
                }

                // New Batch Button
                IconButton(
                    onClick = onNewBatchClick,
                    modifier = Modifier
                        .background(CyanAccent, RoundedCornerShape(12.dp))
                        .size(42.dp)
                        .testTag("header_add_batch_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Batch",
                        tint = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // STATS SUMMARY ROW
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatMetricCard(
                label = "TOTAL QRS",
                value = "${stats.totalCount}",
                color = CyanAccent,
                containerColor = CyanLightContainer,
                modifier = Modifier.weight(1f)
            )
            StatMetricCard(
                label = "LINKED SHOPS",
                value = "${stats.linkedCount}",
                color = EmeraldLight,
                containerColor = EmeraldLightContainer,
                modifier = Modifier.weight(1f)
            )
            StatMetricCard(
                label = "UNLINKED",
                value = "${stats.unlinkedCount}",
                color = AmberWarning,
                containerColor = AmberLightContainer,
                modifier = Modifier.weight(1f)
            )
            StatMetricCard(
                label = "REVENUE",
                value = "${stats.currency}${"%.0f".format(stats.totalMoneyReceived)}",
                color = IndigoPrimary,
                containerColor = IndigoLightContainer,
                modifier = Modifier.weight(1.2f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // SEARCH INPUT
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search by serial, shop name, or phone...") },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = CyanAccent)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondaryLight)
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyanAccent,
                unfocusedBorderColor = SlateLightBorder,
                focusedTextColor = TextPrimaryLight,
                unfocusedTextColor = TextPrimaryLight,
                focusedContainerColor = SlateLightSurface,
                unfocusedContainerColor = SlateLightSurface
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("inventory_search_bar")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // FILTER CHIPS ROW (Prominently showing Linked and Unlinked)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                "ALL" to "All Codes (${stats.totalCount})",
                "LINKED" to "Linked Shops (${stats.linkedCount})",
                "UNLINKED" to "Unlinked (${stats.unlinkedCount})"
            )

            filters.forEach { (key, label) ->
                val isSelected = selectedFilter == key
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isSelected) {
                        when (key) {
                            "LINKED" -> EmeraldSuccess
                            "UNLINKED" -> AmberWarning
                            else -> CyanAccent
                        }
                    } else SlateLightSurface,
                    border = BorderStroke(1.dp, if (isSelected) Color.Transparent else SlateLightBorder),
                    modifier = Modifier
                        .clickable { onFilterChange(key) }
                        .testTag("filter_chip_$key")
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.White else TextSecondaryLight,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // TAGS LIST OR EMPTY STATE
        if (tags.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.QrCode2,
                        contentDescription = null,
                        tint = TextTertiaryLight,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotEmpty()) "No tags match '$searchQuery'" else "No dynamic QR tags in this view",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Generate new QR codes or switch filter tab.",
                        fontSize = 13.sp,
                        color = TextSecondaryLight
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("inventory_tags_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(tags, key = { it.id }) { tag ->
                    TagCardItem(
                        tag = tag,
                        onSelect = { onSelectTag(tag) },
                        onLink = { onLinkTag(tag) },
                        onSimulateReview = { onSimulateReview(tag) }
                    )
                }
            }
        }
    }
}

@Composable
private fun StatMetricCard(
    label: String,
    value: String,
    color: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SlateLightBorder),
        shadowElevation = 1.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextTertiaryLight,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
private fun TagCardItem(
    tag: QrTagEntity,
    onSelect: () -> Unit,
    onLink: () -> Unit,
    onSimulateReview: () -> Unit
) {
    val context = LocalContext.current

    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (tag.isLinked) EmeraldLightContainer else SlateLightBorder),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("tag_item_${tag.serialNumber}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Top Row: Serial Number + Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tag.serialNumber,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 15.sp,
                        color = TextPrimaryLight
                    )
                }

                Surface(
                    color = if (tag.isLinked) EmeraldLightContainer else AmberLightContainer,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = if (tag.isLinked) "● Linked" else "● Unlinked (Ready)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (tag.isLinked) EmeraldLight else AmberWarning,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Middle: Shop Name or Unlinked Prompt
            if (tag.isLinked) {
                Text(
                    text = tag.effectiveShopName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Owner WhatsApp & Business Fields
                val phone = tag.effectiveWhatsApp
                if (!phone.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "WhatsApp: $phone",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF16A34A)
                        )
                    }
                }

                // Destination Link Preview
                val dest = tag.effectiveGoogleReviewUrl
                if (!dest.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = null,
                            tint = TextTertiaryLight,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = dest,
                            fontSize = 11.sp,
                            color = TextSecondaryLight,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                // Ledger Data Badge: QRs Taken & Money Received
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "📦 QRs Taken: ${tag.qrCountTaken}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondaryLight
                    )
                    Text(
                        text = "💰 Paid: ${tag.currency}${"%.0f".format(tag.moneyReceived)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldLight
                    )
                }

                if (tag.positiveReviewsCount > 0 || tag.privateFeedbacksCount > 0) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "⭐ ${tag.positiveReviewsCount} Google Redirects · 💬 ${tag.privateFeedbacksCount} Private",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = AmberWarning
                    )
                }
            } else {
                Text(
                    text = "Dynamic QR Code (Unassigned)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Ready for one-time shop linking & Google Review destination assignment",
                    fontSize = 12.sp,
                    color = AmberWarning
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Bottom Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${tag.batchName} · ${tag.scanCount} scans",
                    fontSize = 10.sp,
                    color = TextTertiaryLight
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (tag.isLinked) {
                        // Quick 1-tap WhatsApp to Owner
                        if (!tag.effectiveWhatsApp.isNullOrBlank()) {
                            IconButton(
                                onClick = {
                                    val msg = WhatsAppHelper.buildShopWelcomeMessage(
                                        shopName = tag.effectiveShopName,
                                        serial = tag.serialNumber,
                                        qrCount = tag.qrCountTaken,
                                        moneyReceived = tag.moneyReceived,
                                        currency = tag.currency,
                                        googleReviewUrl = tag.googleReviewUrl
                                    )
                                    WhatsAppHelper.sendWhatsAppMessage(
                                        context = context,
                                        rawPhone = tag.effectiveWhatsApp!!,
                                        message = msg
                                    )
                                },
                                modifier = Modifier
                                    .background(Color(0xFFDCFCE7), RoundedCornerShape(8.dp))
                                    .size(32.dp)
                                    .testTag("quick_whatsapp_${tag.serialNumber}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Chat,
                                    contentDescription = "WhatsApp Owner",
                                    tint = Color(0xFF16A34A),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Test Review Experience Simulation Button
                        FilledTonalButton(
                            onClick = onSimulateReview,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = AmberLightContainer, contentColor = AmberWarning),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("simulate_review_${tag.serialNumber}")
                        ) {
                            Icon(imageVector = Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Review", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Primary Action: Link Shop or View Details
                    Button(
                        onClick = if (tag.isLinked) onSelect else onLink,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (tag.isLinked) SlateLightSurfaceVariant else CyanAccent,
                            contentColor = if (tag.isLinked) TextPrimaryLight else Color.White
                        ),
                        border = if (tag.isLinked) BorderStroke(1.dp, SlateLightBorder) else null,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("action_button_${tag.serialNumber}")
                    ) {
                        Text(
                            text = if (tag.isLinked) "Details & Edit" else "Link Shop",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
