package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ReviewStandRepository
import com.example.ui.theme.AmberLightContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanLightContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldLightContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoLightContainer
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.RoseError
import com.example.ui.theme.RoseLightContainer
import com.example.ui.theme.SlateLightBorder
import com.example.ui.theme.SlateLightBorderSubtle
import com.example.ui.theme.SlateLightSurface
import com.example.ui.theme.SlateLightSurfaceVariant
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.util.NfcLinkingHelper
import com.example.util.NfcTagInfo
import com.example.util.NfcWriteState
import com.example.util.SoundHapticHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Dedicated modal for detecting & reading an NFC tag, writing the current shop's
 * dynamic feedback URL (`NDEF URI` record), and showing visual status indicators for
 * 'Reading', 'Writing', and 'Success' states.
 */
@Composable
fun WriteNfcTagModal(
    standSlug: String,
    shopName: String?,
    dynamicFeedbackUrl: String = ReviewStandRepository.buildStandQrUrl(standSlug),
    onDismiss: () -> Unit,
    onWriteSuccess: (NfcTagInfo) -> Unit = {}
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    val cleanSlug = standSlug.trim().ifBlank { ReviewStandRepository.DEFAULT_STAND_SLUG }
    val targetUrl = dynamicFeedbackUrl.trim().ifBlank { ReviewStandRepository.buildStandQrUrl(cleanSlug) }
    val displayShop = shopName?.trim()?.takeIf { it.isNotBlank() } ?: "Shop Stand #$cleanSlug"

    val isNfcSupported = remember { NfcLinkingHelper.isNfcSupported(context) }
    val isNfcEnabled = remember { NfcLinkingHelper.isNfcEnabled(context) }
    val writeState by NfcLinkingHelper.writeState.collectAsState()

    val startScanning: () -> Unit = {
        if (activity != null) {
            NfcLinkingHelper.enableReaderModeForWriting(activity, cleanSlug, targetUrl)
        } else {
            NfcLinkingHelper.startWaitingForTag(cleanSlug, targetUrl)
        }
    }

    val stopScanning: () -> Unit = {
        activity?.let { NfcLinkingHelper.disableReaderMode(it) }
        NfcLinkingHelper.cancelWaitingForTag()
    }

    LaunchedEffect(writeState) {
        if (writeState is NfcWriteState.Success) {
            val info = (writeState as NfcWriteState.Success).info
            SoundHapticHelper.playSuccessFeedback(context)
            onWriteSuccess(info)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            activity?.let { NfcLinkingHelper.disableReaderMode(it) }
            NfcLinkingHelper.resetWriteState()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "write_nfc_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(820, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "write_nfc_scale"
    )

    Dialog(
        onDismissRequest = {
            stopScanning()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SlateLightBorder),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 400.dp)
                .testTag("write_nfc_tag_modal")
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = CyanLightContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Nfc,
                                    contentDescription = "Write to NFC Tag",
                                    tint = CyanAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Write to NFC Tag",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = displayShop,
                                fontSize = 12.sp,
                                color = TextSecondaryLight,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            stopScanning()
                            onDismiss()
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_write_nfc_modal_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close NFC Writer",
                            tint = TextSecondaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Current Shop Dynamic Feedback URL Preview
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SlateLightBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "DYNAMIC FEEDBACK URL",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextTertiaryLight,
                                letterSpacing = 0.8.sp
                            )
                            Surface(
                                color = IndigoLightContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "NDEF URI · #$cleanSlug",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            color = SlateLightSurface,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, SlateLightBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Feedback URL", targetUrl))
                                    Toast.makeText(context, "Dynamic feedback URL copied", Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = targetUrl,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = IndigoPrimary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("write_nfc_target_url_text")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy dynamic feedback URL",
                                    tint = IndigoPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 3-Stage Visual Status Stepper: Reading -> Writing -> Success
                NfcThreeStageStepper(writeState = writeState)

                Spacer(modifier = Modifier.height(12.dp))

                // Detailed Visual Status Card
                AnimatedContent(
                    targetState = writeState,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "nfc_write_status_animation"
                ) { state ->
                    when (state) {
                        is NfcWriteState.Idle -> {
                            Surface(
                                color = SlateLightSurfaceVariant,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, SlateLightBorderSubtle),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("nfc_write_status_banner")
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .background(IndigoLightContainer, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Sensors,
                                            contentDescription = "Ready to detect tag",
                                            tint = IndigoPrimary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "Ready to Detect NFC Tag",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryLight
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Tap 'Write to NFC Tag' below to start Reading, then hold a blank or rewritable NFC tag against the back of your device.",
                                        fontSize = 12.sp,
                                        color = TextSecondaryLight,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        is NfcWriteState.WaitingForTag,
                        is NfcWriteState.Reading -> {
                            val existingUrl = (state as? NfcWriteState.Reading)?.existingUrl
                            Surface(
                                color = CyanLightContainer,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.5.dp, CyanAccent),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("nfc_write_status_banner")
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .scale(pulseScale)
                                            .background(CyanAccent.copy(alpha = 0.22f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Sensors,
                                            contentDescription = "Reading NFC Tag",
                                            tint = CyanAccent,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "Reading NFC Tag...",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (!existingUrl.isNullOrBlank()) {
                                            "Tag detected (existing: $existingUrl). Preparing to write..."
                                        } else {
                                            "Hold an NFC tag or standee near your device antenna to read UID and NDEF capacity."
                                        },
                                        fontSize = 12.sp,
                                        color = TextSecondaryLight,
                                        textAlign = TextAlign.Center
                                    )
                                    if (state is NfcWriteState.WaitingForTag) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        OutlinedButton(
                                            onClick = {
                                                coroutineScope.launch {
                                                    NfcLinkingHelper.markReadingState(cleanSlug, targetUrl)
                                                    delay(450)
                                                    NfcLinkingHelper.markWritingState()
                                                    delay(550)
                                                    NfcLinkingHelper.simulateTagWrite(cleanSlug, targetUrl)
                                                }
                                            },
                                            border = BorderStroke(1.dp, CyanAccent),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier
                                                .height(44.dp)
                                                .testTag("simulate_nfc_tap_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.TouchApp,
                                                contentDescription = null,
                                                tint = CyanAccent,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Simulate NFC Tap",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = CyanAccent
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        is NfcWriteState.Writing -> {
                            Surface(
                                color = AmberLightContainer,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.5.dp, AmberWarning),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("nfc_write_status_banner")
                            ) {
                                Row(
                                    modifier = Modifier.padding(18.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        color = AmberWarning,
                                        strokeWidth = 2.5.dp,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column {
                                        Text(
                                            text = "Writing Dynamic URL...",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimaryLight
                                        )
                                        Text(
                                            text = "Encoding NDEF URI record to physical NFC tag. Keep tag steady.",
                                            fontSize = 12.sp,
                                            color = TextSecondaryLight
                                        )
                                    }
                                }
                            }
                        }

                        is NfcWriteState.Success -> {
                            Surface(
                                color = EmeraldLightContainer,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.5.dp, EmeraldSuccess),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("nfc_write_status_banner")
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "NFC Write Success",
                                            tint = EmeraldSuccess,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Success — NFC Tag Written!",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldLight
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Tag UID: ${state.info.uid}",
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryLight
                                    )
                                    Text(
                                        text = "Chip: ${state.info.type}",
                                        fontSize = 11.sp,
                                        color = TextSecondaryLight
                                    )
                                    Text(
                                        text = "Written URL: ${state.info.payloadUrl}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = IndigoPrimary
                                    )
                                }
                            }
                        }

                        is NfcWriteState.Error -> {
                            Surface(
                                color = RoseLightContainer,
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.5.dp, RoseError),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("nfc_write_status_banner")
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ErrorOutline,
                                        contentDescription = "NFC Write Error",
                                        tint = RoseError,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "NFC Write Failed",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = RoseError
                                        )
                                        Text(
                                            text = state.message,
                                            fontSize = 12.sp,
                                            color = TextPrimaryLight
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when {
                        isNfcSupported && isNfcEnabled -> "Hardware NFC reader is active (NDEF URI Writer)."
                        isNfcSupported && !isNfcEnabled -> "NFC is disabled in device settings — enable NFC or use Simulate NFC Tap."
                        else -> "No physical NFC adapter detected on this device — use Simulate NFC Tap to preview Reading → Writing → Success."
                    },
                    fontSize = 11.sp,
                    color = TextTertiaryLight,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            stopScanning()
                            onDismiss()
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("nfc_modal_cancel_button")
                    ) {
                        Text("Close", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }

                    val isReading = writeState is NfcWriteState.WaitingForTag || writeState is NfcWriteState.Reading
                    val isWriting = writeState is NfcWriteState.Writing
                    Button(
                        onClick = {
                            if (isReading) {
                                stopScanning()
                            } else {
                                startScanning()
                            }
                        },
                        enabled = !isWriting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when {
                                isReading -> RoseError
                                writeState is NfcWriteState.Success -> EmeraldSuccess
                                else -> CyanAccent
                            },
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier
                            .weight(1.7f)
                            .height(48.dp)
                            .testTag("write_nfc_tag_action_button")
                    ) {
                        Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when {
                                isReading -> "Stop Reading"
                                isWriting -> "Writing..."
                                writeState is NfcWriteState.Success -> "Write Another Tag"
                                writeState is NfcWriteState.Error -> "Retry NFC Write"
                                else -> "Write to NFC Tag"
                            },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NfcThreeStageStepper(writeState: NfcWriteState) {
    val isReadingActive = writeState is NfcWriteState.WaitingForTag || writeState is NfcWriteState.Reading
    val isReadingDone = writeState is NfcWriteState.Writing || writeState is NfcWriteState.Success
    val isWritingActive = writeState is NfcWriteState.Writing
    val isWritingDone = writeState is NfcWriteState.Success
    val isSuccessActive = writeState is NfcWriteState.Success

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("nfc_status_stepper"),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusStagePill(
            label = "Reading",
            isActive = isReadingActive,
            isDone = isReadingDone,
            activeColor = CyanAccent,
            activeBg = CyanLightContainer,
            icon = Icons.Default.Sensors,
            modifier = Modifier
                .weight(1f)
                .testTag("nfc_stage_reading")
        )
        StatusStagePill(
            label = "Writing",
            isActive = isWritingActive,
            isDone = isWritingDone,
            activeColor = AmberWarning,
            activeBg = AmberLightContainer,
            icon = Icons.Default.Edit,
            modifier = Modifier
                .weight(1f)
                .testTag("nfc_stage_writing")
        )
        StatusStagePill(
            label = "Success",
            isActive = isSuccessActive,
            isDone = isSuccessActive,
            activeColor = EmeraldLight,
            activeBg = EmeraldLightContainer,
            icon = Icons.Default.CheckCircle,
            modifier = Modifier
                .weight(1f)
                .testTag("nfc_stage_success")
        )
    }
}

@Composable
private fun StatusStagePill(
    label: String,
    isActive: Boolean,
    isDone: Boolean,
    activeColor: Color,
    activeBg: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    val containerColor = when {
        isDone -> EmeraldLightContainer
        isActive -> activeBg
        else -> SlateLightSurfaceVariant
    }
    val borderColor = when {
        isDone -> EmeraldSuccess
        isActive -> activeColor
        else -> SlateLightBorderSubtle
    }
    val contentColor = when {
        isDone -> EmeraldLight
        isActive -> activeColor
        else -> TextTertiaryLight
    }

    Surface(
        color = containerColor,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(if (isActive || isDone) 1.5.dp else 1.dp, borderColor),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isDone) Icons.Default.CheckCircle else icon,
                contentDescription = "$label state",
                tint = contentColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isActive || isDone) FontWeight.Bold else FontWeight.Medium,
                color = contentColor,
                maxLines = 1
            )
        }
    }
}
