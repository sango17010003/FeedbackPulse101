package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ReviewStandRepository
import com.example.data.local.QrStandEntity
import com.example.ui.theme.AmberLightContainer
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanLightContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldLightContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoLightContainer
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SlateLightBorder
import com.example.ui.theme.SlateLightBorderSubtle
import com.example.ui.theme.SlateLightSurface
import com.example.ui.theme.SlateLightSurfaceVariant
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.viewmodel.ReviewStandUiState
import com.example.ui.viewmodel.SurveyStep
import com.example.util.PositivePresetTone

@Composable
fun SurveyScreen(
    uiState: ReviewStandUiState,
    onQ1Change: (Int) -> Unit,
    onQ2Change: (Int) -> Unit,
    onQ3Change: (Int) -> Unit,
    onPositivePresetChange: (String) -> Unit,
    onPresetToneSelect: (PositivePresetTone) -> Unit,
    onSubmitRating: () -> Unit,
    onCommentChange: (String) -> Unit,
    onPhoneChange: (String) -> Unit,
    onSubmitComplaint: () -> Unit,
    onResetSurvey: () -> Unit,
    onSwitchStandSlug: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showStandPicker by remember { mutableStateOf(false) }
    var showQrModal by remember { mutableStateOf(false) }
    var showWriteNfcModal by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Subtle Stand ID Switcher + QR + Write to NFC Tag Modal triggers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
            ) {
                Surface(
                    color = IndigoLightContainer,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable { showStandPicker = true }
                        .testTag("stand_switcher_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Active QR Stand",
                            tint = IndigoPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = uiState.standSlug,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IndigoPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, SlateLightBorderSubtle),
                    modifier = Modifier
                        .clickable { showQrModal = true }
                        .testTag("survey_show_qr_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Show Shop QR Code",
                            tint = TextPrimaryLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Show QR",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimaryLight
                        )
                    }
                }

                Surface(
                    color = CyanLightContainer,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .clickable { showWriteNfcModal = true }
                        .testTag("survey_write_nfc_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Nfc,
                            contentDescription = "Write to NFC Tag",
                            tint = CyanAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Write to NFC Tag",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyanAccent
                        )
                    }
                }
            }

            if (uiState.surveyStep != SurveyStep.RATE && uiState.shop != null) {
                TextButton(
                    onClick = onResetSurvey,
                    modifier = Modifier.testTag("survey_start_over_button")
                ) {
                    Text("Start Over", color = TextSecondaryLight, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when {
            uiState.loadingShop -> {
                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, SlateLightBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = IndigoPrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Loading store...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight
                        )
                    }
                }
            }

            uiState.shop == null -> {
                StandNotActivatedCard(
                    standSlug = uiState.standSlug,
                    onTryDefaultStand = { onSwitchStandSlug("stand1") }
                )
            }

            else -> {
                AnimatedContent(
                    targetState = uiState.surveyStep,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "survey_step_transition"
                ) { step ->
                    when (step) {
                        SurveyStep.RATE -> RatingStepCard(
                            shop = uiState.shop,
                            q1 = uiState.q1,
                            q2 = uiState.q2,
                            q3 = uiState.q3,
                            positivePreset = uiState.positiveReviewPreset,
                            selectedTone = uiState.selectedPresetTone,
                            onQ1Change = onQ1Change,
                            onQ2Change = onQ2Change,
                            onQ3Change = onQ3Change,
                            onPositivePresetChange = onPositivePresetChange,
                            onPresetToneSelect = onPresetToneSelect,
                            onSubmit = onSubmitRating
                        )

                        SurveyStep.COMPLAINT -> ComplaintStepCard(
                            comment = uiState.comment,
                            phone = uiState.phone,
                            busy = uiState.busy,
                            onCommentChange = onCommentChange,
                            onPhoneChange = onPhoneChange,
                            onSendToOwner = onSubmitComplaint
                        )

                        SurveyStep.DONE -> ThankYouStepCard(
                            shopName = uiState.shop.shopName,
                            onSubmitAnother = onResetSurvey
                        )
                    }
                }
            }
        }
    }

    if (showStandPicker) {
        StandSwitcherDialog(
            currentSlug = uiState.standSlug,
            knownStands = uiState.stands,
            onSelectSlug = { slug ->
                showStandPicker = false
                onSwitchStandSlug(slug)
            },
            onDismiss = { showStandPicker = false }
        )
    }

    if (showQrModal) {
        val currentSerial = uiState.standSlug
        val currentQrPayload = ReviewStandRepository.buildStandQrUrl(currentSerial)
        ShopQrCodeModal(
            serialNumber = currentSerial,
            shopName = uiState.shop?.shopName,
            qrPayloadUrl = currentQrPayload,
            destinationReviewUrl = uiState.shop?.googleReviewUrl,
            onDismiss = { showQrModal = false },
            onWriteNfc = { showWriteNfcModal = true }
        )
    }

    if (showWriteNfcModal) {
        val currentSerial = uiState.standSlug
        val currentDynamicUrl = ReviewStandRepository.buildStandQrUrl(currentSerial)
        WriteNfcTagModal(
            standSlug = currentSerial,
            shopName = uiState.shop?.shopName,
            dynamicFeedbackUrl = currentDynamicUrl,
            onDismiss = { showWriteNfcModal = false }
        )
    }
}

@Composable
private fun StandNotActivatedCard(
    standSlug: String,
    onTryDefaultStand: () -> Unit
) {
    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stand_not_activated_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(SlateLightSurfaceVariant, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Storefront,
                    contentDescription = null,
                    tint = TextTertiaryLight,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "QR Stand Not Activated Yet",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Stand ID: $standSlug",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = TextTertiaryLight
            )
            if (!standSlug.equals("stand1", ignoreCase = true)) {
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedButton(
                    onClick = onTryDefaultStand,
                    modifier = Modifier.testTag("switch_to_stand1_button")
                ) {
                    Text("Preview Sample Stand (stand1)")
                }
            }
        }
    }
}

@Composable
private fun RatingStepCard(
    shop: QrStandEntity,
    q1: Int,
    q2: Int,
    q3: Int,
    positivePreset: String,
    selectedTone: PositivePresetTone,
    onQ1Change: (Int) -> Unit,
    onQ2Change: (Int) -> Unit,
    onQ3Change: (Int) -> Unit,
    onPositivePresetChange: (String) -> Unit,
    onPresetToneSelect: (PositivePresetTone) -> Unit,
    onSubmit: () -> Unit
) {
    val context = LocalContext.current
    val ownerDisplay = shop.displayOwnerName

    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("rating_step_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Rate ${shop.shopName}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight,
                modifier = Modifier.testTag("review_page_shop_name")
            )

            if (ownerDisplay.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = IndigoLightContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("review_page_owner_name")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Shop Owner",
                            tint = IndigoPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Owner: $ownerDisplay",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IndigoPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Your feedback helps us serve you better",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryLight
            )

            Spacer(modifier = Modifier.height(16.dp))

            StarGroupCard(
                label = "1. Quality & Taste",
                value = q1,
                onChange = onQ1Change,
                testTagPrefix = "q1_star"
            )

            Spacer(modifier = Modifier.height(12.dp))

            StarGroupCard(
                label = "2. Staff Service",
                value = q2,
                onChange = onQ2Change,
                testTagPrefix = "q2_star"
            )

            Spacer(modifier = Modifier.height(12.dp))

            StarGroupCard(
                label = "3. Cleanliness",
                value = q3,
                onChange = onQ3Change,
                testTagPrefix = "q3_star"
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Pre-set AI positive review box (neutral copy without exposing any star threshold)
            Surface(
                color = SlateLightSurfaceVariant,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SlateLightBorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("preset_ai_message_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Review Assistant",
                                tint = IndigoPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Pre-set AI Review",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                        }

                        IconButton(
                            onClick = {
                                val textToCopy = positivePreset.trim()
                                if (textToCopy.isNotBlank()) {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Positive Google Review", textToCopy))
                                    Toast.makeText(context, "Review text copied!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("copy_preset_ai_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy pre-set review",
                                tint = IndigoPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                    ) {
                        PositivePresetTone.entries.forEach { tone ->
                            FilterChip(
                                selected = selectedTone == tone,
                                onClick = { onPresetToneSelect(tone) },
                                label = { Text(tone.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IndigoLightContainer,
                                    selectedLabelColor = IndigoPrimary
                                ),
                                modifier = Modifier.testTag("preset_tone_${tone.name.lowercase()}")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = positivePreset,
                        onValueChange = onPositivePresetChange,
                        placeholder = { Text("Pre-written positive message...") },
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IndigoPrimary,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("preset_ai_message_input")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Pre-written positive message — customize or copy anytime, ready to paste if you post a Google review.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight,
                        modifier = Modifier.testTag("preset_ai_status_text")
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = onSubmit,
                colors = ButtonDefaults.buttonColors(
                    containerColor = IndigoPrimary,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_rating_button")
            ) {
                Text(
                    text = "Submit Rating",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StarGroupCard(
    label: String,
    value: Int,
    onChange: (Int) -> Unit,
    testTagPrefix: String
) {
    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                (1..5).forEach { star ->
                    val selected = star <= value
                    val scale by animateFloatAsState(
                        targetValue = if (selected) 1.08f else 1.0f,
                        animationSpec = spring(stiffness = Spring.StiffnessMedium),
                        label = "star_scale_$star"
                    )
                    IconButton(
                        onClick = { onChange(star) },
                        modifier = Modifier
                            .size(48.dp)
                            .scale(scale)
                            .testTag("${testTagPrefix}_$star")
                    ) {
                        Icon(
                            imageVector = if (selected) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "$label $star stars",
                            tint = if (selected) AmberWarning else SlateLightBorder,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ComplaintStepCard(
    comment: String,
    phone: String,
    busy: Boolean,
    onCommentChange: (String) -> Unit,
    onPhoneChange: (String) -> Unit,
    onSendToOwner: () -> Unit
) {
    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("complaint_step_card")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Surface(
                color = AmberLightContainer,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Tell us what went wrong",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = AmberWarning
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Your message goes directly to the shop owner.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimaryLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = comment,
                onValueChange = onCommentChange,
                placeholder = { Text("Write your issue here...") },
                minLines = 4,
                maxLines = 6,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = SlateLightBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("complaint_comment_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = onPhoneChange,
                placeholder = { Text("Mobile Number (Optional)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IndigoPrimary,
                    unfocusedBorderColor = SlateLightBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("complaint_phone_input")
            )

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = onSendToOwner,
                enabled = !busy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldSuccess,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("send_to_owner_button")
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        color = Color.White,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sending...", fontWeight = FontWeight.Bold)
                } else {
                    Text("Send to Owner", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ThankYouStepCard(
    shopName: String,
    onSubmitAnother: () -> Unit
) {
    Surface(
        color = SlateLightSurface,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, SlateLightBorderSubtle),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("thank_you_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(EmeraldLightContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Feedback Sent",
                    tint = EmeraldLight,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Thank You!",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "The owner of $shopName has received your feedback.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(18.dp))
            OutlinedButton(
                onClick = onSubmitAnother,
                modifier = Modifier.testTag("submit_another_button")
            ) {
                Text("Rate Again")
            }
        }
    }
}

@Composable
private fun StandSwitcherDialog(
    currentSlug: String,
    knownStands: List<QrStandEntity>,
    onSelectSlug: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var manualSlug by remember { mutableStateOf(currentSlug) }
    val presets = remember(knownStands) {
        val defaults = listOf("stand1", "stand2")
        (knownStands.map { it.standSlug } + defaults).distinct()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SlateLightSurface,
        title = {
            Text(
                text = "Open Stand Survey",
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Enter a Stand ID (?s=...) or pick a quick preset:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight
                )
                OutlinedTextField(
                    value = manualSlug,
                    onValueChange = { manualSlug = it },
                    label = { Text("Stand ID (e.g. stand1)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stand_slug_manual_input")
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.take(3).forEach { slug ->
                        OutlinedButton(
                            onClick = { onSelectSlug(slug) },
                            modifier = Modifier.testTag("preset_stand_$slug")
                        ) {
                            Text(slug, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSelectSlug(manualSlug.trim().ifBlank { "stand1" }) },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                modifier = Modifier.testTag("load_stand_confirm_button")
            ) {
                Text("Load Stand")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
