package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*

@Composable
fun TrustReviewSimulatorDialog(
    tag: QrTagEntity,
    onDismiss: () -> Unit,
    onSubmitReview: (totalStars: Int, reviewText: String) -> Unit
) {
    val context = LocalContext.current

    var q1Stars by remember { mutableIntStateOf(5) }
    var q2Stars by remember { mutableIntStateOf(5) }
    var q3Stars by remember { mutableIntStateOf(4) }

    val totalStars = q1Stars + q2Stars + q3Stars
    val isHighPraise = totalStars >= 9 // Internal business logic: >= 9/15 stars

    var reviewText by remember {
        mutableStateOf("Outstanding experience at ${tag.effectiveShopName}! The service was prompt, staff was very welcoming, and the quality exceeded expectations.")
    }

    var isSubmitted by remember { mutableStateOf(false) }

    val aiSuggestions = listOf(
        "Outstanding experience! Prompt service, welcoming staff, and wonderful quality.",
        "Highly recommend this shop. Loved the ambience, attention to detail, and great value.",
        "Delicious products and super clean environment. Enjoyed my visit!",
        "Good experience overall, friendly staff and pleasant atmosphere."
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .testTag("trust_review_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = SlateLightSurface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header: TR Reviewers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = AmberLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = AmberWarning,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "TR Reviewers",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Customer Feedback Portal",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("close_review_dialog_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (!isSubmitted) {
                    // Review Form View - Clean, zero exposure of gate rules or score thresholds
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Shop Name Callout
                        Surface(
                            color = SlateLightSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SlateLightBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "SHOP UNDER REVIEW",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextTertiaryLight,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = tag.effectiveShopName,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryLight
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Serial: ${tag.serialNumber} · Verified Merchant",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextSecondaryLight
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // QUESTION 1: Quality of Service / Products
                        CustomerQuestionCard(
                            questionNumber = 1,
                            questionText = "How was the Product / Food Quality?",
                            currentRating = q1Stars,
                            onRatingSelected = { q1Stars = it }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // QUESTION 2: Staff Courtesy & Ambience
                        CustomerQuestionCard(
                            questionNumber = 2,
                            questionText = "How was the Staff Behavior & Ambience?",
                            currentRating = q2Stars,
                            onRatingSelected = { q2Stars = it }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // QUESTION 3: Overall Recommendation & Value
                        CustomerQuestionCard(
                            questionNumber = 3,
                            questionText = "Overall Value & Would you Recommend?",
                            currentRating = q3Stars,
                            onRatingSelected = { q3Stars = it }
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // AI AUTO-GENERATED REVIEW SUGGESTIONS
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AI Review Suggestions",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap any suggestion to auto-fill your review:",
                            fontSize = 11.sp,
                            color = TextSecondaryLight
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            aiSuggestions.forEach { suggestion ->
                                Surface(
                                    color = SlateLightSurfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, SlateLightBorder),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { reviewText = suggestion }
                                ) {
                                    Text(
                                        text = "⭐ $suggestion",
                                        fontSize = 11.sp,
                                        color = TextPrimaryLight,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // REVIEW TEXTBOX
                        OutlinedTextField(
                            value = reviewText,
                            onValueChange = { reviewText = it },
                            label = { Text("Your Written Review") },
                            placeholder = { Text("Write your review or experience here...") },
                            minLines = 3,
                            maxLines = 6,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AmberWarning,
                                unfocusedBorderColor = SlateLightBorder,
                                focusedTextColor = TextPrimaryLight,
                                unfocusedTextColor = TextPrimaryLight,
                                focusedLabelColor = AmberWarning,
                                focusedContainerColor = SlateLightSurface,
                                unfocusedContainerColor = SlateLightSurface
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_review_textbox")
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Clean Submit Review Button (NO score, NO criteria, NO gate rule exposed)
                    Button(
                        onClick = {
                            isSubmitted = true
                            onSubmitReview(totalStars, reviewText)

                            if (isHighPraise) {
                                // Auto copy to clipboard for customer convenience
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Google Review", reviewText))
                                Toast.makeText(context, "Review copied to clipboard!", Toast.LENGTH_SHORT).show()

                                // Open Direct Write Review Link directly
                                val targetUrl = tag.effectiveDirectWriteReviewUrl.ifBlank { tag.effectiveGoogleReviewUrl }
                                if (!targetUrl.isNullOrBlank()) {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
                                        context.startActivity(intent)
                                    } catch (_: Exception) {}
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AmberWarning,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_trust_review_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Submit Review",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    // SUBMITTED STATE VIEW (NO score words, NO gate rules, NO WhatsApp buttons to customer)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (isHighPraise) {
                            // High Rating View
                            Surface(
                                color = AmberLightContainer,
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.size(68.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(38.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Thank You for Your Feedback!",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                repeat(5) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(24.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Surface(
                                color = SlateLightSurfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, SlateLightBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldLight, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Copied to your clipboard:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldLight)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("\"$reviewText\"", fontSize = 13.sp, color = TextPrimaryLight, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Your review is copied to your clipboard so you can easily paste and share it on Google Reviews.",
                                fontSize = 12.sp,
                                color = TextSecondaryLight,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )

                            val googleLink = tag.effectiveDirectWriteReviewUrl.ifBlank { tag.effectiveGoogleReviewUrl }
                            if (!googleLink.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(googleLink))
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AmberWarning, contentColor = Color.White),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth(0.85f)
                                ) {
                                    Icon(Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open Google Write Review to Paste", fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            // Low / Constructive View - Pure customer reassurance without score or gate mentions
                            Surface(
                                color = CyanLightContainer,
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier.size(68.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.SentimentSatisfied, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(38.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Thank You for Your Feedback!",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Surface(
                                color = SlateLightSurfaceVariant,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, SlateLightBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "We assure you of our complete commitment to betterment next time! Please visit us again soon.",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = EmeraldLight,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, SlateLightBorder),
                            modifier = Modifier.fillMaxWidth(0.5f)
                        ) {
                            Text("Done", color = TextPrimaryLight)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerQuestionCard(
    questionNumber: Int,
    questionText: String,
    currentRating: Int,
    onRatingSelected: (Int) -> Unit
) {
    Surface(
        color = SlateLightSurfaceVariant,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, SlateLightBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "QUESTION $questionNumber OF 3",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextTertiaryLight,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = questionText,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimaryLight
            )
            Spacer(modifier = Modifier.height(8.dp))

            // 5 Clickable Stars Row - Clean, without score text
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (star in 1..5) {
                    val isFilled = star <= currentRating
                    IconButton(
                        onClick = { onRatingSelected(star) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (isFilled) Icons.Default.Star else Icons.Outlined.Star,
                            contentDescription = "$star stars",
                            tint = if (isFilled) AmberWarning else TextTertiaryLight,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
        }
    }
}
