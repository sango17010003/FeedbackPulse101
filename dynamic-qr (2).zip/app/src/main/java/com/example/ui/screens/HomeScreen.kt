package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.QrAppViewModel
import kotlinx.coroutines.launch

enum class NavTab {
    INVENTORY,
    GENERATOR,
    LINK_GENERATOR
}

@Composable
fun HomeScreen(viewModel: QrAppViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val allTags by viewModel.allTags.collectAsStateWithLifecycle()
    val filteredTags by viewModel.filteredTags.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val statusFilter by viewModel.statusFilter.collectAsStateWithLifecycle()
    val selectedTag by viewModel.selectedTag.collectAsStateWithLifecycle()
    val linkingTag by viewModel.linkingTag.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val customDomain by viewModel.customDomain.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(NavTab.INVENTORY) }
    var showDomainDialog by remember { mutableStateOf(false) }
    var showExcelLedger by remember { mutableStateOf(false) }
    var showBatchGeneratorModal by remember { mutableStateOf(false) }
    var simulatingReviewTag by remember { mutableStateOf<QrTagEntity?>(null) }

    // Pre-filled URL / shop name from Link Generator to linker dialog
    var initialAssignedUrl by remember { mutableStateOf<String?>(null) }
    var initialShopName by remember { mutableStateOf<String?>(null) }

    // Toast notifications for user actions
    LaunchedEffect(userMessage) {
        userMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearUserMessage()
        }
    }

    // Intercept back button when inspecting tag details
    if (selectedTag != null) {
        BackHandler {
            viewModel.selectTag(null)
        }
        TagDetailsScreen(
            tag = selectedTag!!,
            onBack = { viewModel.selectTag(null) },
            onEditLink = {
                initialAssignedUrl = null
                initialShopName = null
                viewModel.openExecutionLinker(selectedTag!!)
            },
            onUnlink = { viewModel.unlinkTag(selectedTag!!.serialNumber) },
            onDelete = { viewModel.deleteTag(selectedTag!!) },
            onSimulateReview = { simulatingReviewTag = selectedTag },
            onUpdateContact = { name, phone ->
                viewModel.updateTagContact(selectedTag!!.serialNumber, name, phone)
            },
            onNfcLinked = { nfcUid ->
                viewModel.updateNfcLinkedStatus(selectedTag!!.serialNumber, nfcUid)
            }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = SlateLightBackground,
            bottomBar = {
                NavigationBar(
                    containerColor = SlateLightSurface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("main_navigation_bar")
                ) {
                    NavigationBarItem(
                        selected = currentTab == NavTab.INVENTORY,
                        onClick = { currentTab = NavTab.INVENTORY },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == NavTab.INVENTORY) Icons.Default.FolderSpecial else Icons.Default.Folder,
                                contentDescription = "Tags & Shops"
                            )
                        },
                        label = { Text("Tags & Shops") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = CyanAccent,
                            indicatorColor = CyanAccent,
                            unselectedIconColor = TextSecondaryLight,
                            unselectedTextColor = TextSecondaryLight
                        ),
                        modifier = Modifier.testTag("nav_tab_inventory")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavTab.GENERATOR,
                        onClick = { currentTab = NavTab.GENERATOR },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == NavTab.GENERATOR) Icons.Default.AddBox else Icons.Default.AddCircleOutline,
                                contentDescription = "QR Generator"
                            )
                        },
                        label = { Text("QR Generator") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = CyanAccent,
                            indicatorColor = CyanAccent,
                            unselectedIconColor = TextSecondaryLight,
                            unselectedTextColor = TextSecondaryLight
                        ),
                        modifier = Modifier.testTag("nav_tab_generator")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavTab.LINK_GENERATOR,
                        onClick = { currentTab = NavTab.LINK_GENERATOR },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == NavTab.LINK_GENERATOR) Icons.Default.RateReview else Icons.Default.Link,
                                contentDescription = "Review Link"
                            )
                        },
                        label = { Text("Review Link") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = CyanAccent,
                            indicatorColor = CyanAccent,
                            unselectedIconColor = TextSecondaryLight,
                            unselectedTextColor = TextSecondaryLight
                        ),
                        modifier = Modifier.testTag("nav_tab_link_generator")
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    NavTab.INVENTORY -> {
                        InventoryScreen(
                            tags = filteredTags,
                            stats = stats,
                            searchQuery = searchQuery,
                            onSearchQueryChange = { viewModel.searchQuery.value = it },
                            selectedFilter = statusFilter,
                            onFilterChange = { viewModel.statusFilter.value = it },
                            onSelectTag = { tag -> viewModel.selectTag(tag) },
                            onLinkTag = { tag ->
                                initialAssignedUrl = null
                                initialShopName = null
                                viewModel.openExecutionLinker(tag)
                            },
                            onSimulateReview = { tag -> simulatingReviewTag = tag },
                            onOpenExcelLedger = { showExcelLedger = true },
                            onExportExcel = { viewModel.exportExcelLedger(context) },
                            onNewBatchClick = { showBatchGeneratorModal = true },
                            onDomainSettingsClick = { showDomainDialog = true }
                        )
                    }
                    NavTab.GENERATOR -> {
                        GeneratorScreen(
                            unlinkedTags = allTags.filter { !it.isLinked },
                            onGenerateBatch = { count, prefix, batchName, notes ->
                                viewModel.generateBatchTags(count, prefix, batchName, notes)
                            },
                            onSelectTag = { tag -> viewModel.selectTag(tag) },
                            onLinkTag = { tag ->
                                initialAssignedUrl = null
                                initialShopName = null
                                viewModel.openExecutionLinker(tag)
                            },
                            onOpenBatchModal = { showBatchGeneratorModal = true }
                        )
                    }
                    NavTab.LINK_GENERATOR -> {
                        LinkGeneratorScreen(
                            onAssignToQr = { generatedUrl, shopName ->
                                initialAssignedUrl = generatedUrl
                                initialShopName = shopName

                                // Find existing unlinked tag or generate a fresh one
                                val unlinked = allTags.firstOrNull { !it.isLinked }
                                if (unlinked != null) {
                                    viewModel.openExecutionLinker(unlinked)
                                } else {
                                    // Generate a single unlinked dynamic tag and open linker
                                    viewModel.generateBatchTags(1, "TR-", "Direct Review Deployment", "Assigned from Review Link Generator")
                                    coroutineScope.launch {
                                        kotlinx.coroutines.delay(200)
                                        val newTag = viewModel.allTags.value.firstOrNull { !it.isLinked }
                                        if (newTag != null) {
                                            viewModel.openExecutionLinker(newTag)
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Batch Serial Generator Modal
    if (showBatchGeneratorModal) {
        BatchGeneratorDialog(
            unlinkedTags = allTags.filter { !it.isLinked },
            onDismiss = { showBatchGeneratorModal = false },
            onGenerateBatch = { count, prefix, batchName, notes ->
                viewModel.generateBatchTags(count, prefix, batchName, notes)
            },
            onLinkTag = { tag ->
                showBatchGeneratorModal = false
                initialAssignedUrl = null
                initialShopName = null
                viewModel.openExecutionLinker(tag)
            }
        )
    }

    // One-Time / Editable Shop QR Linking Dialog Modal
    if (linkingTag != null) {
        ExecutionLinkerDialog(
            tag = linkingTag!!,
            initialReviewUrl = initialAssignedUrl,
            initialShopName = initialShopName,
            onDismiss = {
                initialAssignedUrl = null
                initialShopName = null
                viewModel.closeExecutionLinker()
            },
            onLinkShop = { shopName, whatsappNumber, googleReviewUrl, qrCount, money, currency, notes, address, instagramHandle ->
                viewModel.linkShopQr(
                    serial = linkingTag!!.serialNumber,
                    shopName = shopName,
                    whatsappNumber = whatsappNumber,
                    googleReviewUrl = googleReviewUrl,
                    qrCountTaken = qrCount,
                    moneyReceived = money,
                    currency = currency,
                    notes = notes,
                    address = address,
                    instagramHandle = instagramHandle
                )
                initialAssignedUrl = null
                initialShopName = null
            },
            onNfcLinked = { nfcUid ->
                viewModel.updateNfcLinkedStatus(linkingTag!!.serialNumber, nfcUid)
            }
        )
    }

    // Customer TR Reviewers Feedback Simulator Modal (Clean, no customer-facing score/gate text)
    if (simulatingReviewTag != null) {
        TrustReviewSimulatorDialog(
            tag = simulatingReviewTag!!,
            onDismiss = { simulatingReviewTag = null },
            onSubmitReview = { totalStars, reviewText ->
                viewModel.recordReviewSubmission(simulatingReviewTag!!.serialNumber, totalStars, reviewText)
            }
        )
    }

    // Excel Ledger & Export Modal (Clickable sorting & Search)
    if (showExcelLedger) {
        ExcelLedgerDialog(
            tags = allTags,
            onDismiss = { showExcelLedger = false },
            onExportExcel = { viewModel.exportExcelLedger(context) }
        )
    }

    // Personal Domain Settings Dialog Modal
    if (showDomainDialog) {
        DomainSettingsDialog(
            currentDomain = customDomain,
            onDismiss = { showDomainDialog = false },
            onSaveDomain = { newDomain -> viewModel.setCustomDomain(newDomain) },
            onExportJson = { viewModel.exportTagsJson() }
        )
    }
}
