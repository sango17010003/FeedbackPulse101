package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.QrTagEntity
import com.example.data.local.QrTagRepository
import com.example.util.ExcelExportHelper
import com.example.util.LocationHelper
import com.example.util.SerialGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class StatsState(
    val totalCount: Int = 0,
    val linkedCount: Int = 0,
    val unlinkedCount: Int = 0,
    val totalScans: Int = 0,
    val totalQrCountTaken: Int = 0,
    val totalMoneyReceived: Double = 0.0,
    val currency: String = "₹",
    val totalPositiveReviews: Int = 0,
    val totalPrivateFeedbacks: Int = 0
)

class QrAppViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: QrTagRepository
    private val prefs = application.getSharedPreferences("dynamic_qr_settings", Context.MODE_PRIVATE)

    private val _customDomain = MutableStateFlow(
        prefs.getString("custom_domain", SerialGenerator.DEFAULT_DOMAIN) ?: SerialGenerator.DEFAULT_DOMAIN
    )
    val customDomain: StateFlow<String> = _customDomain.asStateFlow()

    init {
        val database = AppDatabase.getInstance(application)
        repository = QrTagRepository(database.qrTagDao())
        SerialGenerator.customDomain = _customDomain.value
    }

    fun setCustomDomain(domain: String) {
        val normalized = SerialGenerator.normalizeDomain(domain)
        prefs.edit().putString("custom_domain", normalized).apply()
        SerialGenerator.customDomain = normalized
        _customDomain.value = normalized
        _userMessage.value = "Personal domain set to $normalized"
    }

    fun exportTagsJson(): String {
        val currentTags = allTags.value
        val sb = StringBuilder("[\n")
        currentTags.forEachIndexed { i, t ->
            val safeShop = t.effectiveShopName.replace("\"", "\\\"")
            val safePhone = (t.effectiveWhatsApp ?: "").replace("\"", "\\\"")
            val safeGoogle = (t.effectiveGoogleReviewUrl ?: "").replace("\"", "\\\"")
            val safeNotes = (t.notes ?: "").replace("\"", "\\\"")

            sb.append("  {\n")
            sb.append("    \"serial\": \"${t.serialNumber}\",\n")
            sb.append("    \"status\": \"${t.status}\",\n")
            sb.append("    \"shopName\": \"$safeShop\",\n")
            sb.append("    \"whatsappNumber\": \"$safePhone\",\n")
            sb.append("    \"googleReviewUrl\": \"$safeGoogle\",\n")
            sb.append("    \"qrCountTaken\": ${t.qrCountTaken},\n")
            sb.append("    \"moneyReceived\": ${t.moneyReceived},\n")
            sb.append("    \"currency\": \"${t.currency}\",\n")
            sb.append("    \"scanCount\": ${t.scanCount},\n")
            sb.append("    \"positiveReviewsCount\": ${t.positiveReviewsCount},\n")
            sb.append("    \"privateFeedbacksCount\": ${t.privateFeedbacksCount},\n")
            sb.append("    \"notes\": \"$safeNotes\"\n")
            sb.append("  }${if (i < currentTags.size - 1) "," else ""}\n")
        }
        sb.append("]")
        return sb.toString()
    }

    val allTags: StateFlow<List<QrTagEntity>> = repository.allTags
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val searchQuery = MutableStateFlow("")
    val statusFilter = MutableStateFlow("ALL") // "ALL", "UNLINKED", "LINKED"

    val filteredTags: StateFlow<List<QrTagEntity>> = combine(
        allTags,
        searchQuery,
        statusFilter
    ) { tags, query, filter ->
        tags.filter { tag ->
            val matchesQuery = if (query.isBlank()) true else {
                tag.serialNumber.contains(query, ignoreCase = true) ||
                (tag.shopName?.contains(query, ignoreCase = true) == true) ||
                (tag.whatsappNumber?.contains(query, ignoreCase = true) == true) ||
                (tag.title?.contains(query, ignoreCase = true) == true) ||
                (tag.address?.contains(query, ignoreCase = true) == true) ||
                tag.batchName.contains(query, ignoreCase = true) ||
                (tag.notes?.contains(query, ignoreCase = true) == true)
            }

            val matchesFilter = when (filter) {
                "UNLINKED" -> !tag.isLinked
                "LINKED" -> tag.isLinked
                "LINKED_LOCATION" -> tag.isLinked
                "LINKED_WEBLINK" -> tag.isLinked
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val stats: StateFlow<StatsState> = allTags.map { tags ->
        val total = tags.size
        val linked = tags.count { it.isLinked }
        val unlinked = tags.count { !it.isLinked }
        val scans = tags.sumOf { it.scanCount }
        val totalQrs = tags.filter { it.isLinked }.sumOf { it.qrCountTaken }
        val totalMoney = tags.filter { it.isLinked }.sumOf { it.moneyReceived }
        val positives = tags.sumOf { it.positiveReviewsCount }
        val privates = tags.sumOf { it.privateFeedbacksCount }
        val curr = tags.firstOrNull()?.currency ?: "₹"
        StatsState(
            totalCount = total,
            linkedCount = linked,
            unlinkedCount = unlinked,
            totalScans = scans,
            totalQrCountTaken = totalQrs,
            totalMoneyReceived = totalMoney,
            currency = curr,
            totalPositiveReviews = positives,
            totalPrivateFeedbacks = privates
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StatsState()
    )

    private val _selectedTag = MutableStateFlow<QrTagEntity?>(null)
    val selectedTag: StateFlow<QrTagEntity?> = _selectedTag.asStateFlow()

    private val _linkingTag = MutableStateFlow<QrTagEntity?>(null)
    val linkingTag: StateFlow<QrTagEntity?> = _linkingTag.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun selectTag(tag: QrTagEntity?) {
        _selectedTag.value = tag
    }

    fun selectTagBySerial(serial: String) {
        viewModelScope.launch {
            val tag = repository.findTagBySerial(serial)
            _selectedTag.value = tag
        }
    }

    fun openExecutionLinker(tag: QrTagEntity) {
        _linkingTag.value = tag
    }

    fun closeExecutionLinker() {
        _linkingTag.value = null
    }

    /**
     * Pre-generates batch of dynamic QR codes beforehand with collision-proof serials
     */
    fun generateBatchTags(
        count: Int,
        prefix: String = "TR-",
        batchName: String = "Trust Review Deployment",
        initialNotes: String? = null
    ) {
        viewModelScope.launch {
            val tagsToInsert = mutableListOf<QrTagEntity>()
            val now = System.currentTimeMillis()

            for (i in 0 until count) {
                val serial = SerialGenerator.generateSerial(prefix)
                val token = SerialGenerator.generateToken()
                tagsToInsert.add(
                    QrTagEntity(
                        serialNumber = serial,
                        token = token,
                        batchName = if (batchName.isBlank()) "Batch ${java.text.SimpleDateFormat("MMM dd", java.util.Locale.US).format(now)}" else batchName,
                        status = QrTagEntity.STATUS_UNLINKED,
                        notes = initialNotes,
                        createdAt = now + i
                    )
                )
            }

            repository.insertTags(tagsToInsert)
            _userMessage.value = "Generated $count dynamic QR codes ($prefix*). Status: Unlinked"
        }
    }

    /**
     * One-Time Shop QR Registration & Linking:
     * Assigns shop name, owner WhatsApp number, Instagram page, Google Reviews link, QRs taken, and money received.
     */
    fun linkShopQr(
        serial: String,
        shopName: String,
        whatsappNumber: String,
        googleReviewUrl: String,
        qrCountTaken: Int = 1,
        moneyReceived: Double = 0.0,
        currency: String = "₹",
        notes: String? = null,
        address: String? = null,
        latitude: Double? = null,
        longitude: Double? = null,
        instagramHandle: String? = null
    ) {
        viewModelScope.launch {
            val current = repository.findTagBySerial(serial) ?: return@launch

            val cleanReviewUrl = if (googleReviewUrl.isNotBlank() && !googleReviewUrl.startsWith("http://") && !googleReviewUrl.startsWith("https://")) {
                "https://$googleReviewUrl"
            } else googleReviewUrl

            val updated = current.copy(
                status = QrTagEntity.STATUS_LINKED,
                shopName = shopName.trim(),
                whatsappNumber = whatsappNumber.trim(),
                instagramHandle = instagramHandle?.trim()?.takeIf { it.isNotBlank() },
                googleReviewUrl = cleanReviewUrl.trim(),
                qrCountTaken = if (qrCountTaken > 0) qrCountTaken else 1,
                moneyReceived = moneyReceived,
                currency = currency,
                title = shopName.trim(),
                contactName = shopName.trim(),
                contactPhone = whatsappNumber.trim(),
                destinationUrl = cleanReviewUrl.trim(),
                linkType = "trust_review",
                address = address ?: current.address,
                latitude = latitude ?: current.latitude,
                longitude = longitude ?: current.longitude,
                notes = notes ?: current.notes,
                linkedAt = System.currentTimeMillis()
            )

            repository.updateTag(updated)
            _selectedTag.value = updated
            _linkingTag.value = null
            _userMessage.value = "Assigned $serial to ${updated.shopName}. Added to Excel ledger!"
        }
    }

    /**
     * Assigns/links physical or simulated NFC tag to this dynamic QR serial
     * Both QR and NFC open the exact same URL.
     */
    fun updateNfcLinkedStatus(serial: String, nfcUid: String? = null) {
        viewModelScope.launch {
            val current = repository.findTagBySerial(serial) ?: return@launch
            val updated = current.copy(
                nfcLinked = true,
                nfcTagUid = nfcUid ?: "NFC-${serial.takeLast(6)}",
                nfcLinkedAt = System.currentTimeMillis()
            )
            repository.updateTag(updated)
            _selectedTag.value = updated
            _userMessage.value = "⚡ NFC Tag paired with $serial! QR and NFC now open the same link."
        }
    }

    /**
     * Legacy linkGoogleLocation compatibility wrapper
     */
    fun linkGoogleLocation(
        serial: String,
        title: String,
        address: String?,
        latitude: Double?,
        longitude: Double?,
        rawUrlOrInput: String?,
        operatorName: String?,
        contactName: String?,
        contactPhone: String?,
        notes: String?
    ) {
        linkShopQr(
            serial = serial,
            shopName = title.ifBlank { "Shop $serial" },
            whatsappNumber = contactPhone ?: "",
            googleReviewUrl = rawUrlOrInput ?: "",
            qrCountTaken = 1,
            moneyReceived = 0.0,
            notes = notes,
            address = address,
            latitude = latitude,
            longitude = longitude
        )
    }

    /**
     * Legacy linkCustomWebLink compatibility wrapper
     */
    fun linkCustomWebLink(
        serial: String,
        title: String,
        destinationUrl: String,
        operatorName: String?,
        contactName: String?,
        contactPhone: String?,
        notes: String?
    ) {
        linkShopQr(
            serial = serial,
            shopName = title.ifBlank { "Shop $serial" },
            whatsappNumber = contactPhone ?: "",
            googleReviewUrl = destinationUrl,
            qrCountTaken = 1,
            moneyReceived = 0.0,
            notes = notes
        )
    }

    /**
     * Records customer review simulation in app:
     * - Stars >= 9/15: records positive review redirected to Google
     * - Stars < 9/15: records private feedback (not redirected)
     */
    fun recordReviewSubmission(serial: String, totalStars: Int, reviewText: String) {
        viewModelScope.launch {
            val current = repository.findTagBySerial(serial) ?: return@launch
            val isHighPraise = totalStars >= 9
            val updated = current.copy(
                scanCount = current.scanCount + 1,
                lastScannedAt = System.currentTimeMillis(),
                positiveReviewsCount = if (isHighPraise) current.positiveReviewsCount + 1 else current.positiveReviewsCount,
                privateFeedbacksCount = if (!isHighPraise) current.privateFeedbacksCount + 1 else current.privateFeedbacksCount
            )
            repository.updateTag(updated)
            if (_selectedTag.value?.serialNumber.equals(serial, ignoreCase = true)) {
                _selectedTag.value = updated
            }
        }
    }

    /**
     * Directly updates contact/WhatsApp details for an address tag
     */
    fun updateTagContact(
        serial: String,
        contactName: String?,
        contactPhone: String?
    ) {
        viewModelScope.launch {
            val current = repository.findTagBySerial(serial) ?: return@launch
            val updated = current.copy(
                contactName = contactName?.trim()?.ifBlank { null },
                contactPhone = contactPhone?.trim()?.ifBlank { null },
                whatsappNumber = contactPhone?.trim()?.ifBlank { current.whatsappNumber }
            )
            repository.updateTag(updated)
            _selectedTag.value = updated
            _userMessage.value = "Updated WhatsApp contact for $serial"
        }
    }

    /**
     * Unlinks a tag back to unlinked state
     */
    fun unlinkTag(serial: String) {
        viewModelScope.launch {
            val current = repository.findTagBySerial(serial) ?: return@launch
            val updated = current.copy(
                status = QrTagEntity.STATUS_UNLINKED,
                shopName = null,
                whatsappNumber = null,
                googleReviewUrl = null,
                qrCountTaken = 1,
                moneyReceived = 0.0,
                title = null,
                address = null,
                latitude = null,
                longitude = null,
                destinationUrl = null,
                linkType = null,
                linkedAt = null
            )
            repository.updateTag(updated)
            _selectedTag.value = updated
            _userMessage.value = "Unlinked $serial. QR code is ready for new shop assignment."
        }
    }

    /**
     * Deletes a tag
     */
    fun deleteTag(tag: QrTagEntity) {
        viewModelScope.launch {
            repository.deleteTag(tag)
            if (_selectedTag.value?.id == tag.id) {
                _selectedTag.value = null
            }
            _userMessage.value = "Deleted tag ${tag.serialNumber}"
        }
    }

    /**
     * Records a scan for a serial number
     */
    fun recordScan(serial: String) {
        viewModelScope.launch {
            repository.recordScan(serial)
            val updated = repository.findTagBySerial(serial)
            if (_selectedTag.value?.serialNumber.equals(serial, ignoreCase = true)) {
                _selectedTag.value = updated
            }
        }
    }

    suspend fun getTagBySerial(serial: String): QrTagEntity? {
        return repository.findTagBySerial(serial)
    }

    /**
     * Exports all assigned shops and QR codes to an Excel-compatible spreadsheet (.CSV)
     * and shares via Android Chooser
     */
    fun exportExcelLedger(context: Context) {
        ExcelExportHelper.exportAndShareExcel(context, allTags.value)
    }
}
