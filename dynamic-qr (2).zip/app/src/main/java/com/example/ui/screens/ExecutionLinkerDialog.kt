package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import android.content.Intent
import android.net.Uri
import com.example.util.SerialGenerator
import com.example.util.WhatsAppHelper

@Composable
fun ExecutionLinkerDialog(
    tag: QrTagEntity,
    initialReviewUrl: String? = null,
    initialShopName: String? = null,
    onDismiss: () -> Unit,
    onLinkShop: (
        shopName: String,
        whatsappNumber: String,
        googleReviewUrl: String,
        qrCountTaken: Int,
        moneyReceived: Double,
        currency: String,
        notes: String?,
        address: String?,
        instagramHandle: String?
    ) -> Unit,
    onNfcLinked: ((nfcUid: String) -> Unit)? = null
) {
    val context = LocalContext.current

    var shopNameInput by remember {
        mutableStateOf(initialShopName ?: tag.shopName ?: tag.title ?: "")
    }
    var whatsappInput by remember {
        mutableStateOf(tag.whatsappNumber ?: tag.contactPhone ?: "")
    }
    var instagramInput by remember {
        mutableStateOf(tag.instagramHandle ?: "")
    }
    var googleReviewUrlInput by remember {
        mutableStateOf(initialReviewUrl ?: tag.googleReviewUrl ?: tag.destinationUrl ?: "")
    }
    var qrCountInput by remember {
        mutableStateOf(if (tag.qrCountTaken > 0) tag.qrCountTaken.toString() else "1")
    }
    var moneyReceivedInput by remember {
        mutableStateOf(if (tag.moneyReceived > 0) "%.0f".format(tag.moneyReceived) else "1500")
    }
    var selectedCurrency by remember {
        mutableStateOf(tag.currency.ifBlank { "₹" })
    }
    var addressInput by remember {
        mutableStateOf(tag.address ?: "")
    }
    var notesInput by remember {
        mutableStateOf(tag.notes ?: "")
    }

    var showNfcProgrammer by remember { mutableStateOf(false) }
    var sendWelcomeWhatsAppOnSave by remember { mutableStateOf(true) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .testTag("execution_linker_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = SlateLightSurface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = CyanLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AddBusiness,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (tag.isLinked) "Edit Dynamic QR Link" else "Link Dynamic QR Code",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Assign shop & Google Reviews destination (editable anytime)",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("close_linker_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Serial Number Banner Card
                Surface(
                    color = SlateLightSurfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "DYNAMIC QR UNIQUE ID",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextTertiaryLight,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = tag.serialNumber,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimaryLight
                                )
                            }

                            Surface(
                                color = if (tag.isLinked) EmeraldLightContainer else AmberLightContainer,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = if (tag.isLinked) "● Linked" else "● Unlinked (Ready)",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (tag.isLinked) EmeraldLight else AmberWarning
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Live QR Redirect Payload
                        val qrPayload = remember(tag.serialNumber) { SerialGenerator.buildQrPayload(tag.serialNumber) }
                        Text(
                            text = "Dynamic Redirect Link:",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextTertiaryLight
                        )
                        Text(
                            text = qrPayload,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            color = CyanAccent
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Form Fields
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // FIELD 1: SHOP NAME
                    OutlinedTextField(
                        value = shopNameInput,
                        onValueChange = { shopNameInput = it },
                        label = { Text("Shop / Business Name *") },
                        placeholder = { Text("e.g. Gourmet Cafe & Bakery") },
                        leadingIcon = {
                            Icon(Icons.Default.Storefront, contentDescription = null, tint = CyanAccent)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = CyanAccent,
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_shop_name")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // FIELD 2: OWNER WHATSAPP NUMBER
                    OutlinedTextField(
                        value = whatsappInput,
                        onValueChange = { whatsappInput = it },
                        label = { Text("Owner WhatsApp Connect Number *") },
                        placeholder = { Text("e.g. +91 98765 43210") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = Color(0xFF16A34A))
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF16A34A),
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = Color(0xFF16A34A),
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_whatsapp_number")
                    )
                    Text(
                        text = "Customer reviews and feedback will be sent directly to this WhatsApp number.",
                        fontSize = 11.sp,
                        color = TextSecondaryLight,
                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // FIELD 3: GOOGLE REVIEWS / ASSIGNED LINK
                    OutlinedTextField(
                        value = googleReviewUrlInput,
                        onValueChange = { googleReviewUrlInput = it },
                        label = { Text("Assigned Link (Google Reviews / Maps / Direct Review) *") },
                        placeholder = { Text("e.g. https://search.google.com/local/writereview?placeid=...") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        leadingIcon = {
                            Icon(Icons.Default.Star, contentDescription = null, tint = AmberWarning)
                        },
                        trailingIcon = {
                            if (googleReviewUrlInput.isNotBlank()) {
                                IconButton(onClick = { googleReviewUrlInput = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondaryLight)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberWarning,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = AmberWarning,
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_google_review_url")
                    )

                    // Quick Actions for Google Review Link Formatting
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Action 1: Direct Write Review Popup (5 Stars Dialog)
                        Button(
                            onClick = {
                                if (googleReviewUrlInput.isNotBlank()) {
                                    val writeUrl = com.example.util.GoogleReviewLinkHelper.getDirectWriteReviewUrl(googleReviewUrlInput, shopNameInput)
                                    googleReviewUrlInput = writeUrl
                                    Toast.makeText(context, "Converted to Direct Write Review Popup link!", Toast.LENGTH_SHORT).show()
                                } else if (shopNameInput.isNotBlank()) {
                                    val writeUrl = com.example.util.GoogleReviewLinkHelper.getDirectWriteReviewUrl("", shopNameInput)
                                    googleReviewUrlInput = writeUrl
                                    Toast.makeText(context, "Generated direct review link for $shopNameInput", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Enter shop name or paste link first", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.RateReview, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("✍️ Direct Write Review", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        // Action 2: Review Tab (!9m1!1b1)
                        OutlinedButton(
                            onClick = {
                                if (googleReviewUrlInput.isNotBlank()) {
                                    val converted = com.example.util.GoogleReviewLinkHelper.convertToGoogleMapsReviewTabUrl(googleReviewUrlInput)
                                    googleReviewUrlInput = converted
                                    Toast.makeText(context, "Converted to Reviews Tab (!9m1!1b1)", Toast.LENGTH_SHORT).show()
                                } else if (shopNameInput.isNotBlank()) {
                                    val encoded = java.net.URLEncoder.encode(shopNameInput.trim(), "UTF-8")
                                    googleReviewUrlInput = "https://www.google.com/maps/search/?api=1&query=$encoded&action=openreviews"
                                    Toast.makeText(context, "Generated review search link", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, SlateLightBorder),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("Maps Tab (!9m1!1b1)", fontSize = 11.sp, color = TextPrimaryLight, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Assigned Destination Link Preview Card (Exact link, NO /review?sn= appended)
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Link, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Assigned Link Destination (Exact):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AmberWarning)
                                }
                                if (googleReviewUrlInput.isNotBlank()) {
                                    TextButton(
                                        onClick = {
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(googleReviewUrlInput.trim()))
                                                context.startActivity(intent)
                                            } catch (_: Exception) {
                                                Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                        modifier = Modifier.height(26.dp)
                                    ) {
                                        Text("Test Link", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyanAccent)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (googleReviewUrlInput.isNotBlank()) googleReviewUrlInput.trim() else "Enter link above (destination is kept exact, no /review?sn= added)",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (googleReviewUrlInput.isNotBlank()) TextPrimaryLight else TextTertiaryLight
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "✓ Directly opens the 5-star write review dialog for customer submission.",
                                fontSize = 10.sp,
                                color = EmeraldLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // FIELD 4: INSTAGRAM PAGE / HANDLE
                    OutlinedTextField(
                        value = instagramInput,
                        onValueChange = { instagramInput = it },
                        label = { Text("Shop Instagram Page / Handle") },
                        placeholder = { Text("e.g. @chahatsweets or instagram.com/chahatsweets") },
                        leadingIcon = {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color(0xFFE1306C))
                        },
                        trailingIcon = {
                            if (instagramInput.isNotBlank()) {
                                IconButton(onClick = {
                                    val clean = instagramInput.trim().removePrefix("@")
                                    val url = if (instagramInput.startsWith("http")) instagramInput else "https://instagram.com/$clean"
                                    try {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                    } catch (_: Exception) {}
                                }) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = "Test Instagram", tint = Color(0xFFE1306C))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFE1306C),
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = Color(0xFFE1306C),
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_instagram_handle")
                    )
                    Text(
                        text = "Linked directly to the dynamic QR & NFC portal so customers can follow your shop on Instagram.",
                        fontSize = 11.sp,
                        color = TextSecondaryLight,
                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // NFC TAG PAIRING CARD (Both QR and NFC open same link)
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (tag.nfcLinked) EmeraldSuccess else SlateLightBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Nfc, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("NFC Standee & Tag Pairing", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimaryLight)
                                    Text(
                                        text = if (tag.nfcLinked) "✓ NFC Chip Linked (Opens same link)" else "Assign physical NFC standee/chip to open same link",
                                        fontSize = 10.sp,
                                        color = if (tag.nfcLinked) EmeraldLight else TextSecondaryLight
                                    )
                                }
                            }

                            Button(
                                onClick = { showNfcProgrammer = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (tag.nfcLinked) EmeraldSuccess else CyanAccent,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("open_nfc_programmer_button")
                            ) {
                                Icon(Icons.Default.Nfc, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (tag.nfcLinked) "NFC Paired" else "Pair NFC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // FIELDS 4 & 5: QRS TAKEN & MONEY RECEIVED (EXCEL LEDGER FIELDS)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Number of QRs Taken
                        OutlinedTextField(
                            value = qrCountInput,
                            onValueChange = { qrCountInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("QRs Taken *") },
                            placeholder = { Text("1") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = {
                                Icon(Icons.Default.QrCode, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = SlateLightBorder,
                                focusedTextColor = TextPrimaryLight,
                                unfocusedTextColor = TextPrimaryLight,
                                focusedContainerColor = SlateLightSurface,
                                unfocusedContainerColor = SlateLightSurface
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_qr_count_taken")
                        )

                        // Money Received
                        OutlinedTextField(
                            value = moneyReceivedInput,
                            onValueChange = { moneyReceivedInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Money Received *") },
                            placeholder = { Text("1500") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            leadingIcon = {
                                Text(
                                    text = selectedCurrency,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldLight,
                                    modifier = Modifier.padding(start = 12.dp, end = 4.dp)
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldSuccess,
                                unfocusedBorderColor = SlateLightBorder,
                                focusedTextColor = TextPrimaryLight,
                                unfocusedTextColor = TextPrimaryLight,
                                focusedContainerColor = SlateLightSurface,
                                unfocusedContainerColor = SlateLightSurface
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("input_money_received")
                        )
                    }

                    // Currency Toggle Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Currency:", fontSize = 11.sp, color = TextTertiaryLight)
                        listOf("₹", "$", "€", "£", "AED").forEach { curr ->
                            val isSel = selectedCurrency == curr
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) CyanAccent else SlateLightSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSel) CyanAccent else SlateLightBorder),
                                modifier = Modifier
                                    .height(28.dp)
                                    .padding(vertical = 2.dp)
                            ) {
                                TextButton(
                                    onClick = { selectedCurrency = curr },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                ) {
                                    Text(
                                        text = curr,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color.White else TextSecondaryLight
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // FIELD 6: ADDRESS (Optional)
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        label = { Text("Shop Address / Landmark (Optional)") },
                        placeholder = { Text("e.g. 14 MG Road, Indiranagar, Bengaluru") },
                        leadingIcon = {
                            Icon(Icons.Default.Place, contentDescription = null, tint = TextSecondaryLight)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_shop_address")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // FIELD 7: NOTES (Optional)
                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("Execution Notes / Placement Details") },
                        placeholder = { Text("e.g. Cash counter standee, 2 table stickers") },
                        leadingIcon = {
                            Icon(Icons.Default.Note, contentDescription = null, tint = TextSecondaryLight)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_linking_notes")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // WhatsApp Welcome Confirmation Checkbox
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = sendWelcomeWhatsAppOnSave,
                            onCheckedChange = { sendWelcomeWhatsAppOnSave = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = Color(0xFF16A34A),
                                checkmarkColor = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Send WhatsApp confirmation to owner on save",
                            fontSize = 12.sp,
                            color = TextPrimaryLight
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("cancel_linking_button")
                    ) {
                        Text("Cancel", color = TextSecondaryLight, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            val cleanShop = shopNameInput.trim()
                            val cleanPhone = whatsappInput.trim()
                            val cleanReviewUrl = googleReviewUrlInput.trim()

                            if (cleanShop.isBlank()) {
                                Toast.makeText(context, "Please enter the Shop Name", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (cleanPhone.isBlank()) {
                                Toast.makeText(context, "Please enter Owner WhatsApp number", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (cleanReviewUrl.isBlank()) {
                                Toast.makeText(context, "Please enter Google Reviews / Maps link", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val qrs = qrCountInput.toIntOrNull() ?: 1
                            val money = moneyReceivedInput.toDoubleOrNull() ?: 0.0

                            onLinkShop(
                                cleanShop,
                                cleanPhone,
                                cleanReviewUrl,
                                qrs,
                                money,
                                selectedCurrency,
                                notesInput.trim().ifBlank { null },
                                addressInput.trim().ifBlank { null },
                                instagramInput.trim().ifBlank { null }
                            )

                            if (sendWelcomeWhatsAppOnSave && cleanPhone.isNotBlank()) {
                                val welcomeMsg = WhatsAppHelper.buildShopWelcomeMessage(
                                    shopName = cleanShop,
                                    serial = tag.serialNumber,
                                    qrCount = qrs,
                                    moneyReceived = money,
                                    currency = selectedCurrency,
                                    googleReviewUrl = cleanReviewUrl
                                )
                                WhatsAppHelper.sendWhatsAppMessage(context, cleanPhone, welcomeMsg)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanAccent,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.6f)
                            .height(48.dp)
                            .testTag("save_and_link_shop_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (tag.isLinked) "Update Link" else "Link & Save", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showNfcProgrammer) {
        NfcLinkerDialog(
            tag = tag,
            onDismiss = { showNfcProgrammer = false },
            onNfcLinked = { nfcUid ->
                showNfcProgrammer = false
                onNfcLinked?.invoke(nfcUid)
            }
        )
    }
}
