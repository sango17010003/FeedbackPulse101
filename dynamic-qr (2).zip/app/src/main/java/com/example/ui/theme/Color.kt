package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean, bright, high-contrast Light Theme Palette
val SlateLightBackground = Color(0xFFF8FAFC) // Crisp off-white (Slate 50)
val SlateLightSurface = Color(0xFFFFFFFF)    // Pure white card surfaces
val SlateLightSurfaceVariant = Color(0xFFF1F5F9) // Subtle light contrast (Slate 100)
val SlateLightBorder = Color(0xFFCBD5E1)     // Crisp border (Slate 300)
val SlateLightBorderSubtle = Color(0xFFE2E8F0) // Subtle border (Slate 200)

val TextPrimaryLight = Color(0xFF0F172A)     // Dark slate text (Slate 900)
val TextSecondaryLight = Color(0xFF475569)   // Mid slate text (Slate 600)
val TextTertiaryLight = Color(0xFF94A3B8)    // Soft caption text (Slate 400)

// Vibrant modern brand colors
val IndigoPrimary = Color(0xFF4F46E5)        // Indigo 600
val IndigoDark = Color(0xFF3730A3)           // Indigo 800
val IndigoLightContainer = Color(0xFFEEF2FF) // Indigo 50

val CyanAccent = Color(0xFF0284C7)           // Cyan / Sky 600
val CyanAccentGlow = Color(0xFF0369A1)       // Deep Cyan for text readability on light
val CyanLightContainer = Color(0xFFE0F2FE)   // Sky 100

val EmeraldSuccess = Color(0xFF059669)       // Emerald 600
val EmeraldLight = Color(0xFF047857)         // Emerald 700 (high contrast for text)
val EmeraldLightContainer = Color(0xFFD1FAE5) // Emerald 100

val AmberWarning = Color(0xFFD97706)         // Amber 600 (rich gold for stars & warnings)
val AmberLightContainer = Color(0xFFFEF3C7)  // Amber 100

val RoseError = Color(0xFFDC2626)            // Red 600
val RoseLightContainer = Color(0xFFFEE2E2)   // Red 100

// Compatibility aliases mapped to light theme for clean consistency throughout all screens
val SlateDark = SlateLightBackground
val SlateSurface = SlateLightSurface
val SlateSurfaceVariant = SlateLightSurfaceVariant
val SlateBorder = SlateLightBorder

val TextPrimaryDark = TextPrimaryLight
val TextSecondaryDark = TextSecondaryLight
val TextTertiaryDark = TextTertiaryLight
