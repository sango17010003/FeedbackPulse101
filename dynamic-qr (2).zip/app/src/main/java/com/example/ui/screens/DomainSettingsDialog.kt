package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*
import com.example.util.SerialGenerator

@Composable
fun DomainSettingsDialog(
    currentDomain: String,
    onDismiss: () -> Unit,
    onSaveDomain: (String) -> Unit,
    onExportJson: () -> String
) {
    val context = LocalContext.current
    var domainInput by remember { mutableStateOf(currentDomain) }
    var showSetupGuide by remember { mutableStateOf(false) }

    val sampleSerial = "TR-8492-X7K"
    val previewUrl = remember(domainInput) {
        SerialGenerator.buildQrPayload(sampleSerial, domainInput)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .testTag("domain_settings_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = SlateLightSurface,
            tonalElevation = 6.dp,
            border = BorderStroke(1.dp, SlateLightBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = CyanLightContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Personal Domain & Redirector",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                            Text(
                                text = "Configured dynamic redirect domain",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_domain_dialog_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "When anyone scans your dynamic QR codes, they redirect through this domain with their unique ID to open the assigned destination.",
                        fontSize = 12.sp,
                        color = TextSecondaryLight,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Domain Input Field
                    OutlinedTextField(
                        value = domainInput,
                        onValueChange = { domainInput = it },
                        label = { Text("Redirector Domain / Website URL *") },
                        placeholder = { Text("https://qr-redirector-xb5h.onrender.com/r/") },
                        leadingIcon = {
                            Icon(Icons.Default.Public, contentDescription = null, tint = CyanAccent)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight,
                            focusedLabelColor = CyanAccent,
                            focusedContainerColor = SlateLightSurface,
                            unfocusedContainerColor = SlateLightSurface
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("domain_input_field")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick domain presets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SuggestionChip(
                            onClick = { domainInput = "https://qr-redirector-xb5h.onrender.com/r/" },
                            label = { Text("onrender.com/r/", fontSize = 11.sp) }
                        )
                        SuggestionChip(
                            onClick = { domainInput = SerialGenerator.DEFAULT_DOMAIN },
                            label = { Text("Reset Default", fontSize = 11.sp) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // LIVE QR CODE URL PREVIEW CARD
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "LIVE QR PAYLOAD PREVIEW",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextTertiaryLight,
                                    letterSpacing = 0.5.sp
                                )
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("QR URL", previewUrl))
                                        Toast.makeText(context, "URL copied", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyanAccent, modifier = Modifier.size(14.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = previewUrl,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = IndigoPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Path pattern: $domainInput{UNIQUE_ID}",
                                fontSize = 10.sp,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // WEBSITE WEB RESOLVER EXPORT
                    Surface(
                        color = SlateLightSurfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, EmeraldLightContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Web,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Personal Website Ready (/website)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldLight
                                )
                            }
                            Text(
                                text = "A complete modern website interface is included under /website/index.html to host on your domain with 1-click Google Reviews and WhatsApp routing.",
                                fontSize = 11.sp,
                                color = TextSecondaryLight,
                                modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val json = onExportJson()
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Tags Data JSON", json))
                                        Toast.makeText(context, "Database JSON copied! Paste into website.", Toast.LENGTH_LONG).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, EmeraldSuccess),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.DataObject, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy Tags JSON", fontSize = 11.sp, color = EmeraldLight)
                                }

                                OutlinedButton(
                                    onClick = { showSetupGuide = !showSetupGuide },
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, SlateLightBorder),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = TextPrimaryLight, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (showSetupGuide) "Hide Guide" else "Setup Guide", fontSize = 11.sp, color = TextPrimaryLight)
                                }
                            }

                            if (showSetupGuide) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    color = SlateLightSurface,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, SlateLightBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("How to link your personal domain:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimaryLight)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("1. Upload /website/index.html to your hosting (Cloudflare Pages, Render, Vercel, Netlify).", fontSize = 11.sp, color = TextSecondaryLight)
                                        Text("2. Point your custom DNS (e.g. qr-redirector-xb5h.onrender.com) to the hosting.", fontSize = 11.sp, color = TextSecondaryLight)
                                        Text("3. Save domain above. New dynamic QR codes will instantly point to your domain!", fontSize = 11.sp, color = TextSecondaryLight)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SlateLightBorder),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("cancel_domain_button")
                    ) {
                        Text("Cancel", color = TextSecondaryLight, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            onSaveDomain(domainInput)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanAccent,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("save_domain_button")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save & Apply Domain", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
