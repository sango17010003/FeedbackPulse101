package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ReviewStandRepository
import com.example.data.local.FeedbackLogEntity
import com.example.data.local.QrStandEntity
import com.example.data.local.QrTagEntity
import com.example.util.OwnerRegistrationValidator
import com.example.util.PositivePresetTone
import com.example.util.PositiveReviewPresetHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppMode {
    SURVEY,
    LOGIN,
    DASHBOARD,
    SUPER_ADMIN
}

enum class SurveyStep {
    RATE,
    COMPLAINT,
    DONE
}

data class ReviewStandUiState(
    val mode: AppMode = AppMode.SURVEY,
    val standSlug: String = ReviewStandRepository.DEFAULT_STAND_SLUG,
    val shop: QrStandEntity? = null,
    val loadingShop: Boolean = true,

    // Customer Survey state
    val q1: Int = 0,
    val q2: Int = 0,
    val q3: Int = 0,
    val surveyStep: SurveyStep = SurveyStep.RATE,
    val comment: String = "",
    val phone: String = "",
    val busy: Boolean = false,
    val surveyErrorMsg: String? = null,
    val externalUrlToLaunch: String? = null,
    val pendingClipboardText: String? = null,
    val positiveReviewPreset: String = PositiveReviewPresetHelper.buildPreset(null),
    val selectedPresetTone: PositivePresetTone = PositivePresetTone.WARM,

    // Login / Shop Owner Registration state
    val ownerNameInput: String = "",
    val isBelow18Checked: Boolean = false,
    val showParentalConsentPrompt: Boolean = false,
    val parentGuardianNameInput: String = "",
    val parentConsentChecked: Boolean = false,
    val emailInput: String = "",
    val otpInput: String = "",
    val otpSent: Boolean = false,
    val authMsg: String? = null,
    val loggedInEmail: String? = null,

    // 2-OTP Account Deletion state (Shop Owner safeguard)
    val showDeleteAccountDialog: Boolean = false,
    val deleteAccountStep: Int = 0, // 0 = confirm warning, 1 = waiting 1st OTP, 2 = waiting 2nd OTP
    val deleteOtp1Input: String = "",
    val deleteOtp2Input: String = "",
    val deleteAuthMsg: String? = null,
    val deleteBusy: Boolean = false,

    // Distinct Super Admin View (Global Shop Registry)
    val isSuperAdmin: Boolean = false,
    val superAdminStands: List<QrStandEntity> = emptyList(),
    val superAdminReviews: List<FeedbackLogEntity> = emptyList(),
    val superAdminSearchQuery: String = "",

    // Distinct Shop Owner View (Owner Reviews + Stands + Scoped Local Ledger & Unlinked Serials)
    val reviews: List<FeedbackLogEntity> = emptyList(),
    val stands: List<QrStandEntity> = emptyList(),
    val ownerLedgerTags: List<QrTagEntity> = emptyList(),
    val unlinkedSerials: List<QrTagEntity> = emptyList(),

    // Merchant Unique QR String Generator controls
    val serialPrefixInput: String = "TR-",
    val serialBatchCount: Int = 3,
    val serialBatchLabel: String = "Counter Stand",
    val serialGenMsg: String? = null,

    // Dynamic Editable QR Generator & Link Resolver
    val editingSlug: String? = null,
    val newSlug: String = "",
    val newShopName: String = "",
    val newOwnerName: String = "",
    val newOwnerEmail: String = "",
    val mapsLink: String = "",
    val resolvedDirectReviewUrl: String = "",
    val resolvedLinkType: String = "",
    val resolvedOpensWriteReviewModal: Boolean = false,
    val generatedQrUrl: String = "",
    val lastSavedStandSlug: String = "",
    val editorMsg: String? = null,

    // Environment indicator
    val isSupabaseConfigured: Boolean = false,
    val toastMessage: String? = null
)

class ReviewStandViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ReviewStandRepository(application)

    private val _uiState = MutableStateFlow(
        ReviewStandUiState(
            isSupabaseConfigured = repository.isSupabaseConfigured()
        )
    )
    val uiState: StateFlow<ReviewStandUiState> = _uiState.asStateFlow()

    init {
        observeScopedLocalLedger()
        restoreSessionAndLoadInitialStand()
    }

    private fun observeScopedLocalLedger() {
        viewModelScope.launch {
            repository.ensureSeededLocally()
            repository.observeAllLocalTags()
                .combine(_uiState.map { it.loggedInEmail to it.stands }.distinctUntilChanged()) { allTags, (email, stands) ->
                    val ownerShopNames = stands.map { it.shopName }.toSet()
                    val scoped = ReviewStandRepository.filterTagsForOwner(
                        tags = allTags,
                        ownerEmail = email,
                        ownerStandShopNames = ownerShopNames
                    )
                    val linked = scoped.filter { it.isLinked }
                    val unlinked = scoped.filter { !it.isLinked }
                    linked to unlinked
                }
                .collect { (linked, unlinked) ->
                    _uiState.update {
                        it.copy(
                            ownerLedgerTags = linked,
                            unlinkedSerials = unlinked
                        )
                    }
                }
        }
    }

    private fun restoreSessionAndLoadInitialStand() {
        val savedSession = repository.getCurrentSession()
        if (savedSession != null) {
            val adminAccess = repository.isSuperAdmin(savedSession.email)
            _uiState.update {
                it.copy(
                    loggedInEmail = savedSession.email,
                    isSuperAdmin = adminAccess,
                    newOwnerEmail = savedSession.email
                )
            }
            refreshDashboardData()
            if (adminAccess) refreshSuperAdminData()
        }
        loadStand(_uiState.value.standSlug)
    }

    fun loadStand(slug: String) {
        val clean = ReviewStandRepository.cleanSlug(slug).ifBlank { ReviewStandRepository.DEFAULT_STAND_SLUG }
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    standSlug = clean,
                    loadingShop = true,
                    surveyStep = SurveyStep.RATE,
                    q1 = 0,
                    q2 = 0,
                    q3 = 0,
                    comment = "",
                    phone = "",
                    surveyErrorMsg = null
                )
            }
            val found = repository.fetchStand(clean)
            _uiState.update {
                it.copy(
                    shop = found,
                    loadingShop = false,
                    positiveReviewPreset = PositiveReviewPresetHelper.buildPreset(found, it.selectedPresetTone)
                )
            }
        }
    }

    fun openStandFromExternalLink(slug: String) {
        _uiState.update { it.copy(mode = AppMode.SURVEY) }
        loadStand(slug)
    }

    fun navigateTo(mode: AppMode) {
        when (mode) {
            AppMode.DASHBOARD -> {
                val sessionEmail = _uiState.value.loggedInEmail
                if (sessionEmail == null) {
                    _uiState.update { it.copy(mode = AppMode.LOGIN) }
                    return
                }
                _uiState.update {
                    it.copy(
                        mode = AppMode.DASHBOARD,
                        newOwnerEmail = sessionEmail
                    )
                }
                refreshDashboardData()
            }
            AppMode.SUPER_ADMIN -> {
                if (!_uiState.value.isSuperAdmin) {
                    navigateTo(AppMode.DASHBOARD)
                    return
                }
                _uiState.update { it.copy(mode = AppMode.SUPER_ADMIN) }
                refreshSuperAdminData()
            }
            else -> _uiState.update { it.copy(mode = mode) }
        }
    }

    fun onTopActionClick() {
        when (_uiState.value.mode) {
            AppMode.SURVEY -> {
                val state = _uiState.value
                when {
                    state.loggedInEmail == null -> navigateTo(AppMode.LOGIN)
                    state.isSuperAdmin -> navigateTo(AppMode.SUPER_ADMIN)
                    else -> navigateTo(AppMode.DASHBOARD)
                }
            }
            AppMode.LOGIN, AppMode.DASHBOARD -> {
                _uiState.update { it.copy(mode = AppMode.SURVEY) }
            }
            AppMode.SUPER_ADMIN -> {
                _uiState.update { it.copy(mode = AppMode.SURVEY) }
            }
        }
    }

    fun setQ1(score: Int) {
        _uiState.update { it.copy(q1 = score.coerceIn(0, 5), surveyErrorMsg = null) }
    }

    fun setQ2(score: Int) {
        _uiState.update { it.copy(q2 = score.coerceIn(0, 5), surveyErrorMsg = null) }
    }

    fun setQ3(score: Int) {
        _uiState.update { it.copy(q3 = score.coerceIn(0, 5), surveyErrorMsg = null) }
    }

    fun updateComment(value: String) {
        _uiState.update { it.copy(comment = value, surveyErrorMsg = null) }
    }

    fun updatePhone(value: String) {
        _uiState.update { it.copy(phone = value) }
    }

    fun updatePositiveReviewPreset(value: String) {
        _uiState.update { it.copy(positiveReviewPreset = value) }
    }

    fun selectPositivePresetTone(tone: PositivePresetTone) {
        _uiState.update { current ->
            current.copy(
                selectedPresetTone = tone,
                positiveReviewPreset = PositiveReviewPresetHelper.buildPreset(current.shop, tone)
            )
        }
    }

    fun submitRating() {
        val state = _uiState.value
        if (state.q1 == 0 || state.q2 == 0 || state.q3 == 0) {
            _uiState.update { it.copy(toastMessage = "Please select stars for all 3 questions.") }
            return
        }

        if (ReviewStandRepository.shouldRedirectToGoogleReview(state.q1, state.q2, state.q3)) {
            val reviewUrl = state.shop?.googleReviewUrl?.trim().orEmpty()
            val textToCopy = state.positiveReviewPreset.trim().ifBlank {
                PositiveReviewPresetHelper.buildPreset(state.shop, state.selectedPresetTone)
            }
            if (reviewUrl.isNotBlank()) {
                _uiState.update {
                    it.copy(
                        pendingClipboardText = textToCopy,
                        externalUrlToLaunch = reviewUrl
                    )
                }
            } else {
                _uiState.update { it.copy(toastMessage = "Google Review URL not set for this stand.") }
            }
        } else {
            _uiState.update { it.copy(surveyStep = SurveyStep.COMPLAINT, surveyErrorMsg = null) }
        }
    }

    fun launchExternalUrl(url: String) {
        val trimmed = url.trim()
        if (trimmed.isNotBlank()) {
            _uiState.update { it.copy(externalUrlToLaunch = trimmed) }
        }
    }

    fun consumeExternalUrlEvent() {
        _uiState.update {
            it.copy(
                externalUrlToLaunch = null,
                pendingClipboardText = null
            )
        }
    }

    fun submitComplaint() {
        val state = _uiState.value
        if (state.comment.isBlank()) {
            _uiState.update { it.copy(toastMessage = "Please enter your feedback.") }
            return
        }
        val shopName = state.shop?.shopName ?: state.standSlug
        val totalScore = state.q1 + state.q2 + state.q3

        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, surveyErrorMsg = null) }
            val result = repository.submitNegativeFeedback(
                standSlug = state.standSlug,
                shopName = shopName,
                totalScore = totalScore,
                customerPhone = state.phone,
                customerComment = state.comment
            )
            result.fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            busy = false,
                            surveyStep = SurveyStep.DONE,
                            comment = "",
                            phone = ""
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            toastMessage = "Submission failed: ${error.message}"
                        )
                    }
                }
            )
        }
    }

    fun resetSurvey() {
        _uiState.update { current ->
            current.copy(
                q1 = 0,
                q2 = 0,
                q3 = 0,
                comment = "",
                phone = "",
                surveyStep = SurveyStep.RATE,
                surveyErrorMsg = null,
                positiveReviewPreset = PositiveReviewPresetHelper.buildPreset(current.shop, current.selectedPresetTone)
            )
        }
    }

    // ==========================================
    // AUTHENTICATION (SHOP OWNERS & SUPER ADMIN)
    // ==========================================

    fun updateOwnerNameInput(value: String) {
        _uiState.update { it.copy(ownerNameInput = value, authMsg = null) }
    }

    fun updateBelow18Checked(checked: Boolean) {
        _uiState.update {
            it.copy(
                isBelow18Checked = checked,
                showParentalConsentPrompt = checked,
                parentConsentChecked = if (!checked) false else it.parentConsentChecked,
                authMsg = null
            )
        }
    }

    fun dismissParentalConsentPrompt() {
        _uiState.update { it.copy(showParentalConsentPrompt = false) }
    }

    fun openParentalConsentPrompt() {
        _uiState.update { it.copy(showParentalConsentPrompt = true) }
    }

    fun confirmParentalConsent(guardianName: String) {
        val trimmed = guardianName.trim()
        if (trimmed.isBlank()) {
            _uiState.update {
                it.copy(authMsg = "Parental consent required: please enter Parent / Guardian Full Name.")
            }
            return
        }
        _uiState.update {
            it.copy(
                parentGuardianNameInput = trimmed,
                parentConsentChecked = true,
                showParentalConsentPrompt = false,
                authMsg = null
            )
        }
    }

    fun updateParentGuardianNameInput(value: String) {
        _uiState.update { it.copy(parentGuardianNameInput = value, authMsg = null) }
    }

    fun updateParentConsentChecked(checked: Boolean) {
        _uiState.update { it.copy(parentConsentChecked = checked, authMsg = null) }
    }

    fun updateEmailInput(value: String) {
        _uiState.update { it.copy(emailInput = value, authMsg = null) }
    }

    fun updateOtpInput(value: String) {
        _uiState.update { it.copy(otpInput = value, authMsg = null) }
    }

    fun resetOtpFlow() {
        _uiState.update { it.copy(otpSent = false, otpInput = "", authMsg = null) }
    }

    fun sendOtp() {
        val state = _uiState.value
        val email = state.emailInput.trim()
        val ageValidation = OwnerRegistrationValidator.validate(
            isBelow18 = state.isBelow18Checked,
            parentGuardianName = state.parentGuardianNameInput,
            parentConsentChecked = state.parentConsentChecked
        )
        if (!ageValidation.isValid) {
            _uiState.update {
                it.copy(
                    authMsg = ageValidation.errorMessage,
                    showParentalConsentPrompt = state.isBelow18Checked
                )
            }
            return
        }
        if (email.isBlank()) {
            _uiState.update { it.copy(authMsg = "Please enter your email address.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, authMsg = null) }
            val result = repository.sendLoginOtp(email)
            result.fold(
                onSuccess = { message ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            otpSent = true,
                            authMsg = message
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            authMsg = "Error: ${error.message}"
                        )
                    }
                }
            )
        }
    }

    fun verifyOtp() {
        val state = _uiState.value
        val email = state.emailInput.trim()
        val otp = state.otpInput.trim()
        val ownerName = state.ownerNameInput.trim()
        val ageValidation = OwnerRegistrationValidator.validate(
            isBelow18 = state.isBelow18Checked,
            parentGuardianName = state.parentGuardianNameInput,
            parentConsentChecked = state.parentConsentChecked
        )
        if (!ageValidation.isValid) {
            _uiState.update {
                it.copy(
                    authMsg = ageValidation.errorMessage,
                    showParentalConsentPrompt = state.isBelow18Checked
                )
            }
            return
        }
        if (otp.length < 6) {
            _uiState.update { it.copy(authMsg = "Enter the 6-digit OTP code.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, authMsg = null) }
            val result = repository.verifyLoginOtp(
                email = email,
                otp = otp,
                ownerName = ownerName,
                isBelow18 = state.isBelow18Checked,
                parentGuardianName = state.parentGuardianNameInput.trim()
            )
            result.fold(
                onSuccess = { session ->
                    val adminAccess = repository.isSuperAdmin(session.email)
                    val targetMode = if (adminAccess) AppMode.SUPER_ADMIN else AppMode.DASHBOARD
                    _uiState.update {
                        it.copy(
                            busy = false,
                            loggedInEmail = session.email,
                            isSuperAdmin = adminAccess,
                            newOwnerEmail = session.email,
                            otpSent = false,
                            otpInput = "",
                            ownerNameInput = "",
                            isBelow18Checked = false,
                            showParentalConsentPrompt = false,
                            parentGuardianNameInput = "",
                            parentConsentChecked = false,
                            authMsg = null,
                            mode = targetMode
                        )
                    }
                    refreshDashboardData()
                    if (adminAccess) refreshSuperAdminData()
                    if (ownerName.isNotBlank()) {
                        loadStand(_uiState.value.standSlug)
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            authMsg = "Invalid OTP: ${error.message}"
                        )
                    }
                }
            )
        }
    }

    fun prefillDemoOwnerLogin() {
        _uiState.update {
            it.copy(
                ownerNameInput = "Chahat Gupta",
                isBelow18Checked = false,
                showParentalConsentPrompt = false,
                parentGuardianNameInput = "",
                parentConsentChecked = false,
                emailInput = "owner@chahatsweets.com",
                otpSent = true,
                otpInput = ReviewStandRepository.DEMO_OTP_CODE,
                authMsg = "Shop Owner preview ready — tap Verify & Login (or check 'Below 18' to test parental consent)."
            )
        }
    }

    fun prefillDemoSuperAdminLogin() {
        _uiState.update {
            it.copy(
                ownerNameInput = "",
                isBelow18Checked = false,
                showParentalConsentPrompt = false,
                parentGuardianNameInput = "",
                parentConsentChecked = false,
                emailInput = ReviewStandRepository.DEMO_SUPER_ADMIN_EMAIL,
                otpSent = true,
                otpInput = ReviewStandRepository.DEMO_OTP_CODE,
                authMsg = "Super Admin preview ready — tap Verify & Login for Global Registry."
            )
        }
    }

    // ==========================================
    // SHOP OWNER 2-OTP ACCOUNT DELETION
    // ==========================================

    fun openDeleteAccountDialog() {
        _uiState.update {
            it.copy(
                showDeleteAccountDialog = true,
                deleteAccountStep = 0,
                deleteOtp1Input = "",
                deleteOtp2Input = "",
                deleteAuthMsg = null,
                deleteBusy = false
            )
        }
    }

    fun cancelDeleteAccountDialog() {
        _uiState.update {
            it.copy(
                showDeleteAccountDialog = false,
                deleteAccountStep = 0,
                deleteOtp1Input = "",
                deleteOtp2Input = "",
                deleteAuthMsg = null,
                deleteBusy = false
            )
        }
    }

    fun updateDeleteOtp1Input(value: String) {
        val clean = value.filter { it.isDigit() }.take(6)
        _uiState.update { it.copy(deleteOtp1Input = clean, deleteAuthMsg = null) }
    }

    fun updateDeleteOtp2Input(value: String) {
        val clean = value.filter { it.isDigit() }.take(6)
        _uiState.update { it.copy(deleteOtp2Input = clean, deleteAuthMsg = null) }
    }

    fun requestFirstDeleteOtp() {
        val email = _uiState.value.loggedInEmail?.trim().orEmpty()
        if (email.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(deleteBusy = true, deleteAuthMsg = null) }
            val result = repository.sendAccountDeletionOtp(email = email, step = 1)
            result.fold(
                onSuccess = { msg ->
                    _uiState.update {
                        it.copy(
                            deleteBusy = false,
                            deleteAccountStep = 1,
                            deleteAuthMsg = msg
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            deleteBusy = false,
                            deleteAuthMsg = error.message ?: "Could not send 1st deletion OTP."
                        )
                    }
                }
            )
        }
    }

    fun verifyFirstDeleteOtpAndSendSecond() {
        val state = _uiState.value
        val email = state.loggedInEmail?.trim().orEmpty()
        val otp1 = state.deleteOtp1Input.trim()
        if (email.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(deleteBusy = true, deleteAuthMsg = null) }
            val verify1 = repository.verifyAccountDeletionOtp(email = email, otp = otp1, step = 1)
            if (verify1.isFailure) {
                _uiState.update {
                    it.copy(
                        deleteBusy = false,
                        deleteAuthMsg = verify1.exceptionOrNull()?.message ?: "Invalid 1st OTP."
                    )
                }
                return@launch
            }
            val send2 = repository.sendAccountDeletionOtp(email = email, step = 2)
            send2.fold(
                onSuccess = { msg ->
                    _uiState.update {
                        it.copy(
                            deleteBusy = false,
                            deleteAccountStep = 2,
                            deleteAuthMsg = "1st OTP verified. $msg"
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            deleteBusy = false,
                            deleteAuthMsg = error.message ?: "1st OTP verified, but failed to send 2nd OTP."
                        )
                    }
                }
            )
        }
    }

    fun confirmSecondDeleteOtpAndDeleteAccount() {
        val state = _uiState.value
        val email = state.loggedInEmail?.trim().orEmpty()
        val otp1 = state.deleteOtp1Input.trim()
        val otp2 = state.deleteOtp2Input.trim()
        if (email.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(deleteBusy = true, deleteAuthMsg = null) }
            val verify2 = repository.verifyAccountDeletionOtp(
                email = email,
                otp = otp2,
                step = 2,
                firstOtpUsed = otp1
            )
            if (verify2.isFailure) {
                _uiState.update {
                    it.copy(
                        deleteBusy = false,
                        deleteAuthMsg = verify2.exceptionOrNull()?.message ?: "Invalid 2nd OTP."
                    )
                }
                return@launch
            }
            val deletion = repository.deleteShopOwnerAccount(email)
            deletion.fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            deleteBusy = false,
                            showDeleteAccountDialog = false,
                            deleteAccountStep = 0,
                            deleteOtp1Input = "",
                            deleteOtp2Input = "",
                            deleteAuthMsg = null,
                            loggedInEmail = null,
                            isSuperAdmin = false,
                            mode = AppMode.SURVEY,
                            reviews = emptyList(),
                            stands = emptyList(),
                            ownerLedgerTags = emptyList(),
                            unlinkedSerials = emptyList(),
                            superAdminReviews = emptyList(),
                            superAdminStands = emptyList(),
                            toastMessage = "Account & local shop data permanently deleted."
                        )
                    }
                    loadStand(ReviewStandRepository.DEFAULT_STAND_SLUG)
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            deleteBusy = false,
                            deleteAuthMsg = "Deletion failed: ${error.message}"
                        )
                    }
                }
            )
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _uiState.update {
                it.copy(
                    loggedInEmail = null,
                    isSuperAdmin = false,
                    mode = AppMode.SURVEY,
                    reviews = emptyList(),
                    stands = emptyList(),
                    ownerLedgerTags = emptyList(),
                    unlinkedSerials = emptyList(),
                    superAdminReviews = emptyList(),
                    superAdminStands = emptyList(),
                    superAdminSearchQuery = "",
                    editingSlug = null,
                    newSlug = "",
                    newShopName = "",
                    newOwnerName = "",
                    newOwnerEmail = "",
                    mapsLink = "",
                    resolvedDirectReviewUrl = "",
                    resolvedLinkType = "",
                    resolvedOpensWriteReviewModal = false,
                    generatedQrUrl = "",
                    ownerNameInput = "",
                    isBelow18Checked = false,
                    showParentalConsentPrompt = false,
                    parentGuardianNameInput = "",
                    parentConsentChecked = false,
                    showDeleteAccountDialog = false,
                    deleteAccountStep = 0,
                    deleteOtp1Input = "",
                    deleteOtp2Input = "",
                    deleteAuthMsg = null,
                    deleteBusy = false,
                    otpSent = false,
                    otpInput = "",
                    authMsg = null,
                    serialGenMsg = null
                )
            }
        }
    }

    // ==========================================
    // SHOP OWNER & SUPER ADMIN DATA REFRESH
    // ==========================================

    fun refreshDashboardData() {
        val email = _uiState.value.loggedInEmail ?: return
        viewModelScope.launch {
            val ownerReviews = repository.loadOwnerReviews(email)
            val ownerStands = repository.loadOwnerStands(email)
            _uiState.update {
                it.copy(
                    reviews = ownerReviews,
                    stands = ownerStands
                )
            }
        }
    }

    fun refreshSuperAdminData() {
        if (!_uiState.value.isSuperAdmin) return
        viewModelScope.launch {
            val allStands = repository.loadAllStandsDirectory()
            val allReviews = repository.loadAllReviewsDirectory()
            _uiState.update {
                it.copy(
                    superAdminStands = allStands,
                    superAdminReviews = allReviews
                )
            }
        }
    }

    fun updateSuperAdminSearchQuery(query: String) {
        _uiState.update { it.copy(superAdminSearchQuery = query) }
    }

    // ==========================================
    // MERCHANT UNIQUE QR STRING GENERATOR & UNLINKED SERIALS
    // ==========================================

    fun updateSerialPrefixInput(value: String) {
        _uiState.update { it.copy(serialPrefixInput = value.take(8), serialGenMsg = null) }
    }

    fun updateSerialBatchCount(count: Int) {
        _uiState.update { it.copy(serialBatchCount = count.coerceIn(1, 25), serialGenMsg = null) }
    }

    fun updateSerialBatchLabel(value: String) {
        _uiState.update { it.copy(serialBatchLabel = value, serialGenMsg = null) }
    }

    fun generateUniqueQrSerials() {
        val state = _uiState.value
        val owner = state.loggedInEmail?.takeIf { it.isNotBlank() } ?: run {
            _uiState.update { it.copy(toastMessage = "Please sign in first.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, serialGenMsg = null) }
            val created = repository.generateUniqueSerialBatch(
                count = state.serialBatchCount,
                prefix = state.serialPrefixInput,
                batchName = state.serialBatchLabel,
                ownerEmail = owner
            )
            _uiState.update {
                it.copy(
                    busy = false,
                    serialGenMsg = "Generated ${created.size} unique QR serial(s) ready to assign to your shop!"
                )
            }
        }
    }

    fun assignSerialToShop(
        serial: String,
        shopName: String,
        mapsLink: String,
        whatsappNumber: String,
        instagramHandle: String,
        qrCountTaken: Int,
        moneyReceived: Double,
        notes: String,
        onCompleted: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val owner = _uiState.value.loggedInEmail?.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true) }
            val result = repository.assignUnlinkedSerialToShop(
                serial = serial,
                shopName = shopName,
                ownerEmail = owner,
                mapsLink = mapsLink,
                whatsappNumber = whatsappNumber,
                instagramHandle = instagramHandle,
                qrCountTaken = qrCountTaken,
                moneyReceived = moneyReceived,
                notes = notes
            )
            result.fold(
                onSuccess = { saved ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            generatedQrUrl = saved.qrUrl,
                            lastSavedStandSlug = saved.stand.standSlug,
                            resolvedDirectReviewUrl = saved.stand.googleReviewUrl,
                            toastMessage = "Serial $serial assigned to ${saved.stand.shopName}!"
                        )
                    }
                    refreshDashboardData()
                    if (_uiState.value.isSuperAdmin) refreshSuperAdminData()
                    onCompleted(true, "Assigned $serial -> ${saved.stand.googleReviewUrl}")
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            toastMessage = "Assignment failed: ${error.message}"
                        )
                    }
                    onCompleted(false, error.message ?: "Failed to assign serial")
                }
            )
        }
    }

    fun unlinkSerial(serial: String) {
        viewModelScope.launch {
            repository.unlinkLocalTag(serial)
            _uiState.update { it.copy(toastMessage = "$serial moved back to Unlinked Serials.") }
        }
    }

    fun markSerialNfcLinked(serial: String, nfcUid: String) {
        viewModelScope.launch {
            repository.markTagNfcLinked(serial, nfcUid)
        }
    }

    suspend fun resolveReviewUrlDirect(mapsLink: String) = repository.resolveDirectReviewUrl(mapsLink)

    // ==========================================
    // DYNAMIC EDITABLE QR GENERATOR
    // ==========================================

    fun updateNewSlug(value: String) {
        _uiState.update { it.copy(newSlug = value, editorMsg = null) }
    }

    fun updateNewShopName(value: String) {
        _uiState.update { it.copy(newShopName = value, editorMsg = null) }
    }

    fun updateNewOwnerName(value: String) {
        _uiState.update { it.copy(newOwnerName = value, editorMsg = null) }
    }

    fun updateNewOwnerEmail(value: String) {
        _uiState.update { it.copy(newOwnerEmail = value, editorMsg = null) }
    }

    fun updateMapsLink(value: String) {
        _uiState.update {
            it.copy(
                mapsLink = value,
                resolvedDirectReviewUrl = "",
                resolvedLinkType = "",
                resolvedOpensWriteReviewModal = false,
                editorMsg = null
            )
        }
    }

    fun startEditingStand(stand: QrStandEntity, targetMode: AppMode = _uiState.value.mode) {
        val resolvedMode = when {
            targetMode == AppMode.SUPER_ADMIN && _uiState.value.isSuperAdmin -> AppMode.SUPER_ADMIN
            else -> AppMode.DASHBOARD
        }
        val qrUrl = ReviewStandRepository.buildStandQrUrl(stand.standSlug)
        _uiState.update {
            it.copy(
                mode = resolvedMode,
                editingSlug = stand.standSlug,
                newSlug = stand.standSlug,
                newShopName = stand.shopName,
                newOwnerName = stand.ownerName,
                newOwnerEmail = stand.ownerEmail,
                mapsLink = stand.googleReviewUrl,
                resolvedDirectReviewUrl = stand.googleReviewUrl,
                resolvedLinkType = "Saved Direct Review URL",
                resolvedOpensWriteReviewModal = stand.googleReviewUrl.contains("writereview", true) ||
                    stand.googleReviewUrl.contains("#lrd=", true),
                generatedQrUrl = qrUrl,
                lastSavedStandSlug = stand.standSlug,
                editorMsg = "Editing '${stand.shopName}' (#${stand.standSlug}) — paste any Google Maps link to update."
            )
        }
    }

    fun cancelEditingStand() {
        val owner = _uiState.value.loggedInEmail.orEmpty()
        _uiState.update {
            it.copy(
                editingSlug = null,
                newSlug = "",
                newShopName = "",
                newOwnerName = "",
                newOwnerEmail = owner,
                mapsLink = "",
                resolvedDirectReviewUrl = "",
                resolvedLinkType = "",
                resolvedOpensWriteReviewModal = false,
                editorMsg = null
            )
        }
    }

    fun previewDirectReviewLink() {
        val mapsLink = _uiState.value.mapsLink.trim()
        if (mapsLink.isBlank()) {
            _uiState.update { it.copy(editorMsg = "Paste a Google Maps share link or Place ID first.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, editorMsg = "Resolving direct Google Write-Review link...") }
            val resolved = repository.resolveDirectReviewUrl(mapsLink)
            _uiState.update {
                it.copy(
                    busy = false,
                    resolvedDirectReviewUrl = resolved.directUrl,
                    resolvedLinkType = resolved.linkType,
                    resolvedOpensWriteReviewModal = resolved.opensWriteReviewModal,
                    editorMsg = if (resolved.opensWriteReviewModal) {
                        "Ready (${resolved.linkType}): opens Write Review modal on mobile!"
                    } else {
                        "Converted (${resolved.linkType}): ready to test or save!"
                    }
                )
            }
        }
    }

    fun handleSaveDynamicQr() {
        val state = _uiState.value
        val effectiveSlug = (state.editingSlug ?: state.newSlug).trim()
        val effectiveOwner = if (state.isSuperAdmin && state.mode == AppMode.SUPER_ADMIN) {
            state.newOwnerEmail.ifBlank { state.loggedInEmail.orEmpty() }
        } else {
            state.loggedInEmail.orEmpty()
        }

        if (effectiveSlug.isBlank() || state.newShopName.isBlank() || effectiveOwner.isBlank() || state.mapsLink.isBlank()) {
            _uiState.update { it.copy(editorMsg = "Please fill Stand ID, Shop Name, Owner Email, and Google Maps link.") }
            return
        }

        val isEditing = state.editingSlug != null
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true, editorMsg = "Converting link to direct Write-Review URL & saving...") }
            val result = repository.saveDynamicQrStand(
                rawSlug = effectiveSlug,
                shopName = state.newShopName,
                ownerEmail = effectiveOwner,
                mapsLink = state.mapsLink,
                ownerName = state.newOwnerName
            )
            result.fold(
                onSuccess = { saved ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            editingSlug = null,
                            generatedQrUrl = saved.qrUrl,
                            lastSavedStandSlug = saved.stand.standSlug,
                            resolvedDirectReviewUrl = saved.stand.googleReviewUrl,
                            resolvedOpensWriteReviewModal = saved.stand.googleReviewUrl.contains("writereview", true) ||
                                saved.stand.googleReviewUrl.contains("#lrd=", true),
                            editorMsg = if (isEditing) {
                                "Updated Dynamic QR '#${saved.stand.standSlug}' -> Write-Review URL saved!"
                            } else {
                                "Dynamic QR for '${saved.stand.shopName}' is live!"
                            },
                            newSlug = "",
                            newShopName = "",
                            newOwnerName = "",
                            mapsLink = ""
                        )
                    }
                    refreshDashboardData()
                    if (state.isSuperAdmin) refreshSuperAdminData()
                    if (state.standSlug.equals(saved.stand.standSlug, ignoreCase = true)) {
                        loadStand(saved.stand.standSlug)
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            busy = false,
                            editorMsg = "Error: ${error.message}"
                        )
                    }
                }
            )
        }
    }

    fun toggleReviewStatus(review: FeedbackLogEntity) {
        viewModelScope.launch {
            val result = repository.toggleReviewStatus(review.id, review.status)
            result.fold(
                onSuccess = { nextStatus ->
                    _uiState.update { current ->
                        current.copy(
                            reviews = current.reviews.map { item ->
                                if (item.id == review.id) item.copy(status = nextStatus) else item
                            },
                            superAdminReviews = current.superAdminReviews.map { item ->
                                if (item.id == review.id) item.copy(status = nextStatus) else item
                            }
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update { it.copy(toastMessage = "Could not update status: ${error.message}") }
                }
            )
        }
    }

    fun buildStandQrUrl(slug: String): String {
        return ReviewStandRepository.buildStandQrUrl(slug)
    }

    fun consumeToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
