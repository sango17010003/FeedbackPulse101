package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.IndigoDark
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.SlateLightBackground
import com.example.ui.viewmodel.AppMode
import com.example.ui.viewmodel.ReviewStandViewModel

@Composable
fun ReviewStandApp(viewModel: ReviewStandViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    BackHandler(enabled = uiState.mode != AppMode.SURVEY) {
        if (uiState.mode == AppMode.SUPER_ADMIN && uiState.loggedInEmail != null) {
            viewModel.navigateTo(AppMode.SURVEY)
        } else {
            viewModel.navigateTo(AppMode.SURVEY)
        }
    }

    // Copy positive AI review preset (when >9★) and launch Google Write-Review URL
    LaunchedEffect(uiState.externalUrlToLaunch) {
        val target = uiState.externalUrlToLaunch ?: return@LaunchedEffect
        val copyText = uiState.pendingClipboardText
        if (!copyText.isNullOrBlank()) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Positive Google Review", copyText))
            Toast.makeText(
                context,
                "Positive review copied! Ready to paste on Google.",
                Toast.LENGTH_SHORT
            ).show()
        }
        viewModel.consumeExternalUrlEvent()
        launchReviewUrlPreferringBrowser(context, target)
    }

    LaunchedEffect(uiState.toastMessage) {
        val msg = uiState.toastMessage ?: return@LaunchedEffect
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        viewModel.consumeToast()
    }

    Scaffold(
        containerColor = SlateLightBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            val headerTitle = when (uiState.mode) {
                AppMode.SURVEY -> uiState.shop?.shopName ?: "FeedbackPulse101"
                AppMode.LOGIN -> "Merchant & Admin Login"
                AppMode.DASHBOARD -> "Shop Owner Dashboard"
                AppMode.SUPER_ADMIN -> "Super Admin · Global Registry"
            }
            val topActionText = when (uiState.mode) {
                AppMode.SURVEY -> when {
                    uiState.loggedInEmail == null -> "Login"
                    uiState.isSuperAdmin -> "Super Admin"
                    else -> "Dashboard"
                }
                AppMode.LOGIN, AppMode.DASHBOARD, AppMode.SUPER_ADMIN -> "← Back to QR"
            }

            Surface(
                color = IndigoPrimary,
                shadowElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (uiState.mode == AppMode.SUPER_ADMIN) {
                                Icons.Default.AdminPanelSettings
                            } else {
                                Icons.Default.Storefront
                            },
                            contentDescription = if (uiState.mode == AppMode.SUPER_ADMIN) "Super Admin" else "Store",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = headerTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        color = IndigoDark,
                        shape = RoundedCornerShape(10.dp),
                        onClick = { viewModel.onTopActionClick() },
                        modifier = Modifier.testTag("top_mode_action_button")
                    ) {
                        Text(
                            text = topActionText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SlateLightBackground)
                .padding(innerPadding)
                .navigationBarsPadding()
                .imePadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 560.dp)
            ) {
                AnimatedContent(
                    targetState = uiState.mode,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "app_mode_transition"
                ) { mode ->
                    when (mode) {
                        AppMode.SURVEY -> SurveyScreen(
                            uiState = uiState,
                            onQ1Change = viewModel::setQ1,
                            onQ2Change = viewModel::setQ2,
                            onQ3Change = viewModel::setQ3,
                            onPositivePresetChange = viewModel::updatePositiveReviewPreset,
                            onPresetToneSelect = viewModel::selectPositivePresetTone,
                            onSubmitRating = viewModel::submitRating,
                            onCommentChange = viewModel::updateComment,
                            onPhoneChange = viewModel::updatePhone,
                            onSubmitComplaint = viewModel::submitComplaint,
                            onResetSurvey = viewModel::resetSurvey,
                            onSwitchStandSlug = viewModel::loadStand
                        )

                        AppMode.LOGIN -> LoginScreen(
                            uiState = uiState,
                            onOwnerNameChange = viewModel::updateOwnerNameInput,
                            onBelow18CheckedChange = viewModel::updateBelow18Checked,
                            onConfirmParentalConsentPrompt = viewModel::confirmParentalConsent,
                            onDismissParentalConsentPrompt = viewModel::dismissParentalConsentPrompt,
                            onOpenParentalConsentPrompt = viewModel::openParentalConsentPrompt,
                            onParentGuardianNameChange = viewModel::updateParentGuardianNameInput,
                            onParentConsentChange = viewModel::updateParentConsentChecked,
                            onEmailChange = viewModel::updateEmailInput,
                            onOtpChange = viewModel::updateOtpInput,
                            onSendOtp = viewModel::sendOtp,
                            onVerifyOtp = viewModel::verifyOtp,
                            onResetOtp = viewModel::resetOtpFlow,
                            onDemoOwnerPrefill = viewModel::prefillDemoOwnerLogin,
                            onDemoSuperAdminPrefill = viewModel::prefillDemoSuperAdminLogin
                        )

                        AppMode.DASHBOARD -> DashboardScreen(
                            uiState = uiState,
                            onRefresh = viewModel::refreshDashboardData,
                            onLogout = viewModel::logout,
                            onOpenSuperAdmin = { viewModel.navigateTo(AppMode.SUPER_ADMIN) },
                            onOpenDeleteAccount = viewModel::openDeleteAccountDialog,
                            onCancelDeleteAccount = viewModel::cancelDeleteAccountDialog,
                            onSendDeleteOtp1 = viewModel::requestFirstDeleteOtp,
                            onVerifyDeleteOtp1 = viewModel::verifyFirstDeleteOtpAndSendSecond,
                            onConfirmDeleteOtp2 = viewModel::confirmSecondDeleteOtpAndDeleteAccount,
                            onDeleteOtp1Change = viewModel::updateDeleteOtp1Input,
                            onDeleteOtp2Change = viewModel::updateDeleteOtp2Input,
                            onMarkTagNfcLinked = viewModel::markSerialNfcLinked,
                            buildQrUrlForStand = viewModel::buildStandQrUrl
                        )

                        AppMode.SUPER_ADMIN -> SuperAdminScreen(
                            uiState = uiState,
                            onSearchQueryChange = viewModel::updateSuperAdminSearchQuery,
                            onSlugChange = viewModel::updateNewSlug,
                            onShopNameChange = viewModel::updateNewShopName,
                            onOwnerNameChange = viewModel::updateNewOwnerName,
                            onOwnerEmailChange = viewModel::updateNewOwnerEmail,
                            onMapsLinkChange = viewModel::updateMapsLink,
                            onPreviewDirectLink = viewModel::previewDirectReviewLink,
                            onSaveGlobalStand = viewModel::handleSaveDynamicQr,
                            onEditStand = { stand -> viewModel.startEditingStand(stand, AppMode.SUPER_ADMIN) },
                            onCancelEdit = viewModel::cancelEditingStand,
                            onTestReviewUrl = viewModel::launchExternalUrl,
                            onOpenStandSurvey = viewModel::openStandFromExternalLink,
                            onToggleReviewStatus = viewModel::toggleReviewStatus,
                            onRefreshGlobal = viewModel::refreshSuperAdminData,
                            onSwitchToOwnerView = { viewModel.navigateTo(AppMode.DASHBOARD) },
                            onLogout = viewModel::logout,
                            buildQrUrlForStand = viewModel::buildStandQrUrl
                        )
                    }
                }
            }
        }
    }
}

/**
 * Ensures Write-Review modal links (`search.google.com/local/writereview`, `google.com/search?...#lrd=`,
 * and `google.com/maps` review-tab links) open directly in Chrome or an installed mobile browser
 * rather than allowing the native Google Maps Android app to hijack them to a plain map pin.
 */
private fun launchReviewUrlPreferringBrowser(context: Context, targetUrl: String) {
    try {
        val uri = Uri.parse(targetUrl)
        val isGoogleReviewDestination =
            targetUrl.contains("search.google.com/local/writereview", ignoreCase = true) ||
                targetUrl.contains("#lrd=", ignoreCase = true) ||
                targetUrl.contains("!9m1!1b1", ignoreCase = true) ||
                targetUrl.contains("action=openreviews", ignoreCase = true)

        if (isGoogleReviewDestination) {
            val browserPackage = resolveNonMapsBrowserPackage(context)
            if (!browserPackage.isNullOrBlank()) {
                val browserIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserPackage)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                return
            }
        }

        val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(fallbackIntent)
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to open review link: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

private fun resolveNonMapsBrowserPackage(context: Context): String? {
    val pm = context.packageManager
    val probeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
    val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        pm.queryIntentActivities(probeIntent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
    } else {
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(probeIntent, PackageManager.MATCH_DEFAULT_ONLY)
    }
    val nonMapsBrowsers = resolved
        .mapNotNull { it.activityInfo?.packageName }
        .filter { !it.equals("com.google.android.apps.maps", ignoreCase = true) }

    return nonMapsBrowsers.firstOrNull { it.equals("com.android.chrome", ignoreCase = true) }
        ?: nonMapsBrowsers.firstOrNull()
}
