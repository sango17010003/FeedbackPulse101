package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QrTagEntity
import com.example.ui.theme.*
import com.example.util.QrCodeGenerator
import com.example.util.SerialGenerator
import com.example.util.SoundHapticHelper
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneratorScreen(
    unlinkedTags: List<QrTagEntity>,
    onGenerateBatch: (count: Int, prefix: String, batchName: String, notes: String?) -> Unit,
    onSelectTag: (QrTagEntity) -> Unit,
    onLinkTag: (QrTagEntity) -> Unit,
    onOpenBatchModal: () -> Unit = {}
) {
    val context = LocalContext.current

    var batchCount by remember { mutableIntStateOf(5) }
    var customCountInput by remember { mutableStateOf("5") }
    var prefix by remember { mutableStateOf("TR-") }
    var batchName by remember { mutableStateOf("Merchant Rollout Batch") }
    var batchNotes by remember { mutableStateOf("Dynamic QR tags ready for one-time shop linking") }

    // Live preview serial & QR
    val sampleSerial = remember(prefix) { SerialGenerator.generateSerial(prefix) }
    val sampleQrBitmap = remember(sampleSerial) {
        val payload = SerialGenerator.buildQrPayload(sampleSerial)
        QrCodeGenerator.generateQrImageBitmap(payload, size = 300)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateLightBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("generator_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Dynamic QR Generator",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Generate dynamic QR codes with unique IDs to assign and edit later",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight
                )
            }
            Surface(
                color = CyanLightContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode2,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier
                        .padding(10.dp)
                        .size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Pre-Generation Configuration Card
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, SlateLightBorder),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Create Dynamic QR Codes",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Text(
                    text = "Creates unlinked QR codes with unique IDs for physical sticker printing:",
                    fontSize = 12.sp,
                    color = TextSecondaryLight,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Quantity Selector Chips
                Text(
                    text = "HOW MANY QR CODES DO YOU NEED?",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiaryLight,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 3, 5, 10, 20, 50).forEach { count ->
                        val isSelected = batchCount == count
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("count_chip_$count"),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) CyanAccent else SlateLightSurfaceVariant,
                            border = BorderStroke(1.dp, if (isSelected) CyanAccent else SlateLightBorder),
                            onClick = {
                                batchCount = count
                                customCountInput = count.toString()
                            }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$count",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) Color.White else TextPrimaryLight
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Custom exact number input field
                OutlinedTextField(
                    value = customCountInput,
                    onValueChange = {
                        customCountInput = it.filter { ch -> ch.isDigit() }
                        val parsed = customCountInput.toIntOrNull()
                        if (parsed != null && parsed in 1..200) {
                            batchCount = parsed
                        }
                    },
                    label = { Text("Exact Quantity (1 to 200)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    leadingIcon = {
                        Icon(Icons.Default.Pin, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = SlateLightBorder,
                        focusedTextColor = TextPrimaryLight,
                        unfocusedTextColor = TextPrimaryLight,
                        focusedContainerColor = SlateLightSurface,
                        unfocusedContainerColor = SlateLightSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_quantity_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Prefix & Batch Name Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = prefix,
                        onValueChange = { prefix = it.uppercase() },
                        label = { Text("Unique ID Prefix") },
                        placeholder = { Text("TR-") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("serial_prefix_input")
                    )

                    OutlinedTextField(
                        value = batchName,
                        onValueChange = { batchName = it },
                        label = { Text("Batch / Campaign") },
                        placeholder = { Text("Commercial Market") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanAccent,
                            unfocusedBorderColor = SlateLightBorder,
                            focusedTextColor = TextPrimaryLight,
                            unfocusedTextColor = TextPrimaryLight
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("batch_name_input")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Batch Notes
                OutlinedTextField(
                    value = batchNotes,
                    onValueChange = { batchNotes = it },
                    label = { Text("Notes / Target Area (Optional)") },
                    placeholder = { Text("e.g. Stickers for Main Street merchants") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = SlateLightBorder,
                        focusedTextColor = TextPrimaryLight,
                        unfocusedTextColor = TextPrimaryLight
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("batch_notes_input")
                )

                Spacer(modifier = Modifier.height(18.dp))

                // GENERATE BUTTON
                Button(
                    onClick = {
                        val count = customCountInput.toIntOrNull() ?: batchCount
                        onGenerateBatch(
                            count.coerceIn(1, 200),
                            prefix.ifBlank { "TR-" },
                            batchName.ifBlank { "Trust Review Lot" },
                            batchNotes.ifBlank { null }
                        )
                        SoundHapticHelper.playSuccessFeedback(context)
                        Toast.makeText(context, "Generated $count unlinked dynamic QR tags!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("generate_batch_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Generate $batchCount Dynamic QR Codes",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onOpenBatchModal,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyanAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("open_batch_modal_button")
                ) {
                    Icon(Icons.Default.ListAlt, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Batch Serials Modal (Copy to Clipboard)", color = CyanAccent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // LIVE QR STICKER PREVIEW
        Surface(
            color = SlateLightSurface,
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, SlateLightBorder),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dynamic QR Preview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                    Surface(
                        color = AmberLightContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "● Unlinked / Ready",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AmberWarning,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Printable Physical Sticker Mockup
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .testTag("sample_sticker_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TR REVIEWERS",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = IndigoPrimary,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (sampleQrBitmap != null) {
                            Image(
                                bitmap = sampleQrBitmap,
                                contentDescription = "QR Code Preview",
                                modifier = Modifier
                                    .size(180.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = sampleSerial,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimaryLight
                        )

                        Text(
                            text = "SCAN TO REVIEW / LINK SHOP",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Share / Save Sample Sticker Button
                OutlinedButton(
                    onClick = {
                        val payload = SerialGenerator.buildQrPayload(sampleSerial)
                        val bitmap = QrCodeGenerator.generateStickerBitmap(sampleSerial, payload, batchName)
                        shareBitmap(context, bitmap, sampleSerial)
                    },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyanAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("export_sample_sticker_button")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export / Share Printable Sticker", color = CyanAccent, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // UNLINKED TAGS LIST (Pre-generated codes ready for assignment)
        if (unlinkedTags.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Unlinked Codes Ready to Assign (${unlinkedTags.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryLight
                )
                Surface(
                    color = AmberLightContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Unlinked",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberWarning,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            unlinkedTags.take(8).forEach { tag ->
                Surface(
                    color = SlateLightSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SlateLightBorder),
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectTag(tag) }
                        .testTag("unlinked_tag_${tag.serialNumber}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = AmberLightContainer,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.QrCode,
                                        contentDescription = null,
                                        tint = AmberWarning,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = tag.serialNumber,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPrimaryLight,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Ready to assign · ${tag.batchName}",
                                    fontSize = 12.sp,
                                    color = TextSecondaryLight
                                )
                            }
                        }

                        Button(
                            onClick = { onLinkTag(tag) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanAccent,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("quick_link_${tag.serialNumber}")
                        ) {
                            Icon(imageVector = Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Link Shop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

private fun shareBitmap(context: Context, bitmap: android.graphics.Bitmap, serial: String) {
    try {
        val cachePath = File(context.cacheDir, "stickers").apply { mkdirs() }
        val file = File(cachePath, "sticker_$serial.png")
        FileOutputStream(file).use { stream ->
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, stream)
        }

        val contentUri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            putExtra(Intent.EXTRA_TEXT, "Dynamic QR Sticker ($serial)")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Sticker"))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not share image", Toast.LENGTH_SHORT).show()
    }
}
