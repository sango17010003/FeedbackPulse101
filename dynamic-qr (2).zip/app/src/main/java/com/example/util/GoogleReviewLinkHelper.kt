package com.example.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.math.BigInteger
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class ReviewLinkResult(
    val input: String,
    val directReviewUrl: String,           // Primary link opening directly to the Google Write Review modal
    val googleMapsReviewUrl: String,       // Google Maps Reviews Tab URL
    val writeReviewUrl: String? = null,    // Direct Write-Review modal URL (writereview?placeid=... or #lrd=...,3)
    val placeId: String? = null,
    val cid: String? = null,
    val placeName: String? = null,
    val opensWriteReviewModal: Boolean = false,
    val linkType: String = "Google Review Link",
    val description: String = "Directly opens the write review & rating modal."
)

object GoogleReviewLinkHelper {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .build()

    private const val PLACE_ID_MAPS_REVIEW_BASE = "https://www.google.com/maps/place/?q=place_id:"
    private const val PLACE_ID_WRITE_REVIEW_BASE = "https://search.google.com/local/writereview?placeid="
    private const val CID_MAPS_REVIEW_BASE = "https://maps.google.com/?cid="
    private const val CONSENT_COOKIE = "CONSENT=YES+cb.20210328-17-p0.en+FX+999; SOCS=CAESHAgBEhJnd3NfMjAyNDAxMTAtMF9SQzIaAmVuIAEaBgiA_LyuBg"

    /**
     * Converts any modern Google Maps URL (maps.app.goo.gl, share.google, g.co/kgs, g.page,
     * /maps/place/..., /maps/search/?query_place_id=..., ?cid=..., ludocid=..., or Place ID)
     * into a direct Write-Review modal link for mobile and desktop users.
     */
    suspend fun generateDirectReviewLink(rawInput: String): ReviewLinkResult = withContext(Dispatchers.IO) {
        val trimmed = rawInput.trim()
        if (trimmed.isBlank()) {
            return@withContext ReviewLinkResult(
                input = "",
                directReviewUrl = "",
                googleMapsReviewUrl = "",
                opensWriteReviewModal = false,
                linkType = "Empty",
                description = "Please paste a shareable Google Maps link or Place ID."
            )
        }

        // 1. Direct Place ID input (e.g. "ChIJN1t_tDeuEmsRUsoyG83frY4")
        if (isValidPlaceId(trimmed)) {
            val writeReviewUrl = "$PLACE_ID_WRITE_REVIEW_BASE$trimmed"
            val mapsReviewUrl = "$PLACE_ID_MAPS_REVIEW_BASE$trimmed&action=openreviews"
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = writeReviewUrl,
                googleMapsReviewUrl = mapsReviewUrl,
                writeReviewUrl = writeReviewUrl,
                placeId = trimmed,
                opensWriteReviewModal = true,
                linkType = "Direct Write-Review Modal (Place ID)",
                description = "Opens Google's direct 5-star Write Review modal on mobile."
            )
        }

        // 2. Numeric CID input (also attempt Place ID upgrade via HTTP when online)
        if (trimmed.all { it.isDigit() } && trimmed.length >= 10) {
            val mapsReviewUrl = "$CID_MAPS_REVIEW_BASE$trimmed&action=openreviews"
            val resolution = resolveMapsUrlAndHtml("https://www.google.com/maps?cid=$trimmed")
            val resolvedPid = extractPlaceId(resolution.finalUrl)
                ?: extractPlaceIdFromHtml(resolution.htmlBody, null)
            if (!resolvedPid.isNullOrBlank()) {
                val writeReviewUrl = "$PLACE_ID_WRITE_REVIEW_BASE$resolvedPid"
                return@withContext ReviewLinkResult(
                    input = trimmed,
                    directReviewUrl = writeReviewUrl,
                    googleMapsReviewUrl = mapsReviewUrl,
                    writeReviewUrl = writeReviewUrl,
                    placeId = resolvedPid,
                    cid = trimmed,
                    placeName = extractPlaceNameFromUrl(resolution.finalUrl),
                    opensWriteReviewModal = true,
                    linkType = "Direct Write-Review Modal (Place ID via CID)",
                    description = "Resolved Place ID from CID — opens the Write Review modal on mobile."
                )
            }
            val modalSearchUrl = buildSearchWriteReviewModalUrl(cid = trimmed, hexPair = null, placeName = null)
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = modalSearchUrl,
                googleMapsReviewUrl = mapsReviewUrl,
                writeReviewUrl = modalSearchUrl,
                cid = trimmed,
                opensWriteReviewModal = true,
                linkType = "Write-Review Modal (CID)",
                description = "Opens the Google Write Review dialog via business CID."
            )
        }

        // 3. Direct g.page/<handle> or g.page/r/<token>/review link
        if (trimmed.contains("g.page/", ignoreCase = true) && !trimmed.contains("g.page/r/", ignoreCase = true)) {
            val baseWithoutQuery = trimmed.substringBefore("?").substringBefore("#").trimEnd('/')
            val cleanGPage = if (baseWithoutQuery.endsWith("/review", ignoreCase = true)) {
                baseWithoutQuery
            } else {
                "$baseWithoutQuery/review"
            }
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = cleanGPage,
                googleMapsReviewUrl = cleanGPage,
                writeReviewUrl = cleanGPage,
                opensWriteReviewModal = true,
                linkType = "Google Business Profile Review",
                description = "Opens the Google Business Profile direct Write Review dialog."
            )
        }

        // 4. Expand shortened URLs (maps.app.goo.gl, goo.gl/maps, share.google, g.co/kgs, g.page/r) and fetch HTML
        val resolution = resolveMapsUrlAndHtml(trimmed)
        val resolvedUrl = resolution.finalUrl.ifBlank { trimmed }

        // 5. Already a direct search.google.com/local/writereview link
        if (resolvedUrl.contains("search.google.com/local/writereview", ignoreCase = true)) {
            val pid = extractPlaceId(resolvedUrl)
            val mapsUrl = if (!pid.isNullOrBlank()) "$PLACE_ID_MAPS_REVIEW_BASE$pid&action=openreviews" else resolvedUrl
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = resolvedUrl,
                googleMapsReviewUrl = mapsUrl,
                writeReviewUrl = resolvedUrl,
                placeId = pid,
                opensWriteReviewModal = true,
                linkType = "Direct Write-Review Modal",
                description = "Opens Google's direct 5-star Write Review modal."
            )
        }

        // 6. Resolved g.page/r/... review link
        if (resolvedUrl.contains("g.page/", ignoreCase = true)) {
            val cleanGPage = if (resolvedUrl.endsWith("/review", ignoreCase = true)) {
                resolvedUrl
            } else {
                "${resolvedUrl.trimEnd('/')}/review"
            }
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = cleanGPage,
                googleMapsReviewUrl = cleanGPage,
                writeReviewUrl = cleanGPage,
                opensWriteReviewModal = true,
                linkType = "Google Business Profile Review",
                description = "Opens the Google Business Profile direct Write Review dialog."
            )
        }

        // 6. Extract Place ID (ChIJ / GhIJ / Ei), Hex FTID, CID, and Place Name
        val hexPair = extractHexPair(resolvedUrl)
        var cid = extractCid(resolvedUrl) ?: extractCidFromHtml(resolution.htmlBody)
        var placeId = extractPlaceId(resolvedUrl)
        if (placeId.isNullOrBlank()) {
            placeId = extractPlaceIdFromHtml(resolution.htmlBody, hexPair)
        }

        // 6b. If we still don't have a Place ID but we DO have a CID (or hexPair -> CID),
        // fetch https://www.google.com/maps?cid=<CID> which frequently embeds data-pid="ChIJ..."
        if (placeId.isNullOrBlank() && !cid.isNullOrBlank() && !resolvedUrl.contains("cid=$cid")) {
            val cidResolution = resolveMapsUrlAndHtml("https://www.google.com/maps?cid=$cid")
            placeId = extractPlaceId(cidResolution.finalUrl)
                ?: extractPlaceIdFromHtml(cidResolution.htmlBody, hexPair)
            if (cidResolution.finalUrl.contains("google.com/maps/place/")) {
                cid = extractCid(cidResolution.finalUrl) ?: cid
            }
        }

        val placeName = extractPlaceNameFromUrl(resolvedUrl) ?: extractPlaceNameFromHtml(resolution.htmlBody)

        if (!placeId.isNullOrBlank()) {
            val writeReviewUrl = "$PLACE_ID_WRITE_REVIEW_BASE$placeId"
            val mapsReviewUrl = "$PLACE_ID_MAPS_REVIEW_BASE$placeId&action=openreviews"
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = writeReviewUrl,
                googleMapsReviewUrl = mapsReviewUrl,
                writeReviewUrl = writeReviewUrl,
                placeId = placeId,
                cid = cid,
                placeName = placeName,
                opensWriteReviewModal = true,
                linkType = "Direct Write-Review Modal (Place ID)",
                description = "Directly opens Google's 5-star Write a Review modal on mobile."
            )
        }

        // 7. If Place ID could not be resolved (e.g. offline) but we have CID / hexPair,
        // generate a Google Search #lrd=...,3 modal link (avoids Google Maps app hijacking to plain map pin!)
        if (!cid.isNullOrBlank()) {
            val modalSearchUrl = buildSearchWriteReviewModalUrl(cid = cid, hexPair = hexPair, placeName = placeName)
            val mapsTabUrl = if (resolvedUrl.contains("/maps/place/") || resolvedUrl.contains("/maps/search/")) {
                convertToGoogleMapsReviewTabUrl(resolvedUrl)
            } else {
                "$CID_MAPS_REVIEW_BASE$cid&action=openreviews"
            }
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = modalSearchUrl,
                googleMapsReviewUrl = mapsTabUrl,
                writeReviewUrl = modalSearchUrl,
                cid = cid,
                placeName = placeName,
                opensWriteReviewModal = true,
                linkType = "Mobile Write-Review Modal (CID)",
                description = "Uses Google Business CID to open the Write Review modal in mobile browser instead of just the map pin."
            )
        }

        // 8. If /maps/place/ or /maps/search/ without Place ID or CID, convert to Reviews Tab (!9m1!1b1)
        if (resolvedUrl.contains("/maps/place/") || resolvedUrl.contains("/maps/search/")) {
            val reviewsTabUrl = convertToGoogleMapsReviewTabUrl(resolvedUrl)
            return@withContext ReviewLinkResult(
                input = trimmed,
                directReviewUrl = reviewsTabUrl,
                googleMapsReviewUrl = reviewsTabUrl,
                writeReviewUrl = reviewsTabUrl,
                placeName = placeName,
                opensWriteReviewModal = false,
                linkType = "Google Maps Reviews Tab",
                description = "Opens directly to the Reviews & Ratings tab in browser."
            )
        }

        // 9. Fallback formatting
        val formattedUrl = if (!resolvedUrl.startsWith("http://", ignoreCase = true) &&
            !resolvedUrl.startsWith("https://", ignoreCase = true)
        ) {
            "https://$resolvedUrl"
        } else {
            resolvedUrl
        }
        val finalFallback = if (formattedUrl.contains("google.com/maps") || formattedUrl.contains("maps.google.com")) {
            convertToGoogleMapsReviewTabUrl(formattedUrl)
        } else {
            formattedUrl
        }

        ReviewLinkResult(
            input = trimmed,
            directReviewUrl = finalFallback,
            googleMapsReviewUrl = finalFallback,
            writeReviewUrl = finalFallback,
            cid = cid,
            placeName = placeName,
            opensWriteReviewModal = false,
            linkType = "Direct Review URL",
            description = "Configured to open the review destination."
        )
    }

    /**
     * Ensures a URL returned by an external extractor or saved earlier is upgraded to a direct
     * Write-Review modal URL rather than a plain map location.
     */
    suspend fun ensureDirectReviewUrl(urlOrInput: String): String {
        val trimmed = urlOrInput.trim()
        if (trimmed.isBlank()) return ""
        if (trimmed.contains("search.google.com/local/writereview", ignoreCase = true)) return trimmed
        if (trimmed.contains("g.page/", ignoreCase = true) && trimmed.endsWith("/review", ignoreCase = true)) return trimmed
        val resolved = generateDirectReviewLink(trimmed)
        return resolved.writeReviewUrl?.takeIf { it.isNotBlank() }
            ?: resolved.directReviewUrl.takeIf { it.isNotBlank() }
            ?: trimmed
    }

    private fun buildSearchWriteReviewModalUrl(cid: String, hexPair: String?, placeName: String?): String {
        val hexFtid = hexPair ?: try {
            "0x0:0x${BigInteger(cid).toString(16)}"
        } catch (_: Exception) {
            null
        }
        val qPart = placeName?.trim()?.takeIf { it.isNotBlank() }?.let {
            "q=${URLEncoder.encode(it, "UTF-8")}&"
        }.orEmpty()
        val lrdFragment = if (!hexFtid.isNullOrBlank()) "#lrd=$hexFtid,3,,," else ""
        return "https://www.google.com/search?${qPart}ludocid=$cid$lrdFragment"
    }

    private data class UrlResolutionResult(
        val finalUrl: String,
        val htmlBody: String? = null
    )

    private fun isValidPlaceId(str: String): Boolean {
        return (str.startsWith("ChIJ") || str.startsWith("GhIJ") || str.startsWith("Eh") || str.startsWith("Ei")) &&
            str.length in 24..60 && !str.contains(" ") && !str.contains("/")
    }

    private fun isShortMapsUrl(url: String): Boolean {
        return url.contains("maps.app.goo.gl", ignoreCase = true) ||
            url.contains("goo.gl/maps", ignoreCase = true) ||
            url.contains("goo.gl/", ignoreCase = true) ||
            url.contains("share.google", ignoreCase = true) ||
            url.contains("g.co/kgs", ignoreCase = true) ||
            url.contains("g.page", ignoreCase = true) ||
            url.contains("bit.ly", ignoreCase = true) ||
            url.contains("tinyurl.com", ignoreCase = true)
    }

    private fun isGoogleLocationUrl(url: String): Boolean {
        return isShortMapsUrl(url) ||
            url.contains("google.com/maps", ignoreCase = true) ||
            url.contains("maps.google.com", ignoreCase = true) ||
            url.contains("local.google.com", ignoreCase = true) ||
            (url.contains("google.com/search", ignoreCase = true) &&
                (url.contains("ludocid=", ignoreCase = true) || url.contains("kgmid=", ignoreCase = true)))
    }

    /**
     * Resolves redirects across modern short URLs (maps.app.goo.gl, share.google, g.co/kgs, etc.)
     * and fetches the final Google Maps / Search HTML with consent cookies so Place IDs (ChIJ...)
     * embedded in SSR JSON or DOM attributes can be extracted.
     */
    private suspend fun resolveMapsUrlAndHtml(inputUrl: String): UrlResolutionResult = withContext(Dispatchers.IO) {
        var currentUrl = if (!inputUrl.startsWith("http://", ignoreCase = true) &&
            !inputUrl.startsWith("https://", ignoreCase = true)
        ) {
            "https://$inputUrl"
        } else inputUrl

        if (!isGoogleLocationUrl(currentUrl)) {
            return@withContext UrlResolutionResult(currentUrl, null)
        }

        // If URL already contains a Place ID, no network hop required
        if (!extractPlaceId(currentUrl).isNullOrBlank()) {
            return@withContext UrlResolutionResult(currentUrl, null)
        }

        var lastHtml: String? = null
        var hops = 0
        val maxHops = 8

        while (hops < maxHops) {
            hops++
            try {
                if (currentUrl.startsWith("intent://", ignoreCase = true)) {
                    val parsed = parseIntentUrl(currentUrl)
                    if (!parsed.isNullOrBlank()) {
                        currentUrl = parsed
                    } else break
                }

                if (currentUrl.contains("consent.google.com", ignoreCase = true)) {
                    val continueUrl = extractQueryParam(currentUrl, "continue")
                    if (!continueUrl.isNullOrBlank()) {
                        currentUrl = continueUrl
                        continue
                    }
                }

                val request = Request.Builder()
                    .url(currentUrl)
                    .header(
                        "User-Agent",
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                    )
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Cookie", CONSENT_COOKIE)
                    .build()

                val response = httpClient.newCall(request).execute()
                val statusCode = response.code
                val location = response.header("Location")
                val responseBody = if (statusCode == 200) response.body?.string() else null
                response.close()

                if (statusCode in 300..399 && !location.isNullOrBlank()) {
                    var nextUrl = location
                    if (nextUrl.startsWith("/")) {
                        val base = java.net.URI(currentUrl)
                        nextUrl = "${base.scheme}://${base.host}$nextUrl"
                    }
                    if (nextUrl.contains("consent.google.com", ignoreCase = true)) {
                        val continueUrl = extractQueryParam(nextUrl, "continue")
                        if (!continueUrl.isNullOrBlank()) nextUrl = continueUrl
                    }
                    if (nextUrl.startsWith("intent://", ignoreCase = true)) {
                        val parsed = parseIntentUrl(nextUrl)
                        if (!parsed.isNullOrBlank()) nextUrl = parsed
                    }
                    currentUrl = nextUrl
                } else if (statusCode == 200 && responseBody != null) {
                    lastHtml = responseBody
                    val metaRefresh = extractMetaRefreshUrl(responseBody)
                    if (!metaRefresh.isNullOrBlank() && metaRefresh != currentUrl) {
                        currentUrl = metaRefresh
                        continue
                    }
                    // If on a shortener or share.google landing page, follow embedded canonical / maps place link
                    if (isShortMapsUrl(currentUrl) || currentUrl.contains("google.com/search", ignoreCase = true)) {
                        val nextEmbeddedUrl = extractCanonicalUrl(responseBody)
                            ?: extractEmbeddedMapsPlaceUrl(responseBody)
                        if (!nextEmbeddedUrl.isNullOrBlank() && nextEmbeddedUrl != currentUrl &&
                            (nextEmbeddedUrl.contains("google.com/maps") || nextEmbeddedUrl.contains("maps.google.com"))
                        ) {
                            currentUrl = nextEmbeddedUrl
                            continue
                        }
                    }
                    break
                } else {
                    break
                }
            } catch (_: Exception) {
                break
            }
        }
        UrlResolutionResult(currentUrl, lastHtml)
    }

    private fun extractEmbeddedMapsPlaceUrl(html: String): String? {
        return try {
            val matcher = Pattern.compile("""(https://(?:www\.)?google\.com/maps/place/[^"'\s<>\\]+)""")
                .matcher(html)
            if (matcher.find()) matcher.group(1)?.replace("&amp;", "&") else null
        } catch (_: Exception) {
            null
        }
    }

    private fun extractPlaceIdFromHtml(html: String?, hexPair: String?): String? {
        if (html.isNullOrBlank()) return null
        try {
            // 1. Check canonical or meta URLs first
            val canonical = extractCanonicalUrl(html)
            if (!canonical.isNullOrBlank()) {
                extractPlaceId(canonical)?.let { return it }
            }

            // 2. Check data-pid attribute (common on Google Search / Knowledge Panel / Maps)
            val dataPidMatcher = Pattern.compile("""data-pid=["']([A-Za-z0-9_-]{20,60})["']""").matcher(html)
            if (dataPidMatcher.find()) {
                val pid = dataPidMatcher.group(1)
                if (!pid.isNullOrBlank() && isValidPlaceId(pid)) return pid
            }

            // 3. Check explicit placeid= / place_id= query parameters inside HTML
            val paramMatcher = Pattern.compile("""(?:placeid|place_id|query_place_id)(?:=|\\u003d|\\x3d)([A-Za-z0-9_-]{22,55})""").matcher(html)
            if (paramMatcher.find()) {
                val pid = paramMatcher.group(1)
                if (!pid.isNullOrBlank() && isValidPlaceId(pid)) return pid
            }

            // 4. If we have the shop's hex pair (0x...:0x...), look for the Place ID within +/- 2500 chars around it
            if (!hexPair.isNullOrBlank()) {
                val hexIdx = html.indexOf(hexPair)
                if (hexIdx != -1) {
                    val start = (hexIdx - 2500).coerceAtLeast(0)
                    val end = (hexIdx + hexPair.length + 2500).coerceAtMost(html.length)
                    val window = html.substring(start, end)
                    val pidMatcher = Pattern.compile("""((?:ChIJ|GhIJ)[A-Za-z0-9_-]{20,45})""").matcher(window)
                    if (pidMatcher.find()) {
                        return pidMatcher.group(1)
                    }
                }
            }

            // 5. Look for quoted or escaped-quoted Place ID in SSR JSON (APP_INITIALIZATION_STATE)
            val jsonQuoted = Pattern.compile("""(?:\\?"|\\u0022|\\x22)((?:ChIJ|GhIJ)[A-Za-z0-9_-]{22,45})(?:\\?"|\\u0022|\\x22)""")
                .matcher(html)
            if (jsonQuoted.find()) {
                return jsonQuoted.group(1)
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun extractCidFromHtml(html: String?): String? {
        if (html.isNullOrBlank()) return null
        return try {
            val ludocidMatcher = Pattern.compile("""(?:ludocid|cid)(?:=|\\u003d|\\x3d|":\s*"?)([0-9]{10,25})""").matcher(html)
            if (ludocidMatcher.find()) ludocidMatcher.group(1) else null
        } catch (_: Exception) {
            null
        }
    }

    private fun extractPlaceNameFromHtml(html: String?): String? {
        if (html.isNullOrBlank()) return null
        return try {
            val ogTitle = Pattern.compile(
                """<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']""",
                Pattern.CASE_INSENSITIVE
            ).matcher(html)
            if (ogTitle.find()) {
                val raw = ogTitle.group(1)?.trim().orEmpty()
                val cleaned = raw.substringBefore(" · Google Maps").substringBefore(" - Google Maps").trim()
                if (cleaned.isNotBlank() && !cleaned.equals("Google Maps", ignoreCase = true)) {
                    return cleaned
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun extractCanonicalUrl(html: String): String? {
        return try {
            val canonicalMatcher = Pattern.compile(
                """<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']""",
                Pattern.CASE_INSENSITIVE
            ).matcher(html)
            if (canonicalMatcher.find()) {
                canonicalMatcher.group(1)?.replace("&amp;", "&")
            } else {
                val ogMatcher = Pattern.compile(
                    """<meta[^>]+property=["']og:url["'][^>]+content=["']([^"']+)["']""",
                    Pattern.CASE_INSENSITIVE
                ).matcher(html)
                if (ogMatcher.find()) ogMatcher.group(1)?.replace("&amp;", "&") else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun extractQueryParam(rawUrl: String, key: String): String? {
        return try {
            val query = rawUrl.substringAfter("?", "").substringBefore("#")
            for (pair in query.split("&")) {
                if (pair.substringBefore("=", "") == key) {
                    val v = pair.substringAfter("=", "")
                    if (v.isNotBlank()) return URLDecoder.decode(v, "UTF-8")
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun parseIntentUrl(intentUrl: String): String? {
        try {
            val afterScheme = intentUrl.substringAfter("intent://")
            val hostAndPath = afterScheme.substringBefore("#Intent;")
            val intentParams = afterScheme.substringAfter("#Intent;", "")
            val scheme = if (intentParams.contains("scheme=http;")) "http" else "https"
            return "$scheme://$hostAndPath"
        } catch (_: Exception) {
        }
        return null
    }

    private fun extractMetaRefreshUrl(html: String): String? {
        try {
            val pattern = Pattern.compile("""content=["'][0-9]+;\s*url=([^"']+)["']""", Pattern.CASE_INSENSITIVE)
            val matcher = pattern.matcher(html)
            if (matcher.find()) {
                val found = matcher.group(1)
                if (!found.isNullOrBlank()) {
                    return found.replace("&amp;", "&")
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    fun extractPlaceId(url: String): String? {
        try {
            val queryPattern = Pattern.compile("""(?:placeid|place_id|query_place_id)=([A-Za-z0-9_-]+)""")
            val queryMatcher = queryPattern.matcher(url)
            if (queryMatcher.find()) {
                val pid = queryMatcher.group(1)
                if (!pid.isNullOrBlank() && (pid.startsWith("ChIJ") || pid.startsWith("GhIJ") || pid.startsWith("Eh") || pid.startsWith("Ei") || pid.length > 20)) {
                    return pid
                }
            }

            val dataPattern = Pattern.compile("""!1s((?:ChIJ|GhIJ)[A-Za-z0-9_-]{20,})""")
            val dataMatcher = dataPattern.matcher(url)
            if (dataMatcher.find()) {
                val pid = dataMatcher.group(1)
                if (!pid.isNullOrBlank()) return pid
            }

            val chijPattern = Pattern.compile("""((?:ChIJ|GhIJ)[A-Za-z0-9_-]{24,})""")
            val chijMatcher = chijPattern.matcher(url)
            if (chijMatcher.find()) {
                return chijMatcher.group(1)
            }
        } catch (_: Exception) {
        }
        return null
    }

    fun extractCid(url: String): String? {
        try {
            val cidPattern = Pattern.compile("""(?:cid|ludocid)=([0-9]+)""")
            val cidMatcher = cidPattern.matcher(url)
            if (cidMatcher.find()) {
                val cid = cidMatcher.group(1)
                if (!cid.isNullOrBlank()) return cid
            }

            val hexPairPattern = Pattern.compile("""(?:!1s|ftid=)0x[0-9a-fA-F]+:0x([0-9a-fA-F]+)""")
            val hexMatcher = hexPairPattern.matcher(url)
            if (hexMatcher.find()) {
                val hexCid = hexMatcher.group(1)
                if (!hexCid.isNullOrBlank()) {
                    try {
                        return BigInteger(hexCid, 16).toString()
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun extractPlaceNameFromUrl(url: String): String? {
        try {
            if (url.contains("/maps/place/")) {
                val afterPlace = url.substringAfter("/maps/place/").substringBefore("/@").substringBefore("?")
                val decoded = URLDecoder.decode(afterPlace.replace("+", " "), "UTF-8")
                if (decoded.isNotBlank() && !decoded.startsWith("data=") && !decoded.startsWith("ChIJ")) {
                    return decoded
                }
            }
            if (url.contains("/maps/search/")) {
                val query = extractQueryParam(url, "query") ?: extractQueryParam(url, "q")
                if (!query.isNullOrBlank()) return query
            }
        } catch (_: Exception) {
        }
        return null
    }

    /**
     * Converts a Google Maps Place URL into the Reviews & Ratings Tab URL (with !9m1!1b1).
     */
    fun convertToGoogleMapsReviewTabUrl(url: String): String {
        var result = url.trim()

        if (result.contains("google.com/maps") || result.contains("maps.google.com")) {
            if (!result.contains("!9m1!1b1")) {
                if (result.contains("!16s")) {
                    result = result.replace("!16s", "!9m1!1b1!16s")
                    result = result.replace("!4m6!3m5!", "!4m8!3m7!")
                        .replace("!4m5!3m4!", "!4m7!3m6!")
                        .replace("!4m4!3m3!", "!4m6!3m5!")
                } else if (result.contains("data=")) {
                    val queryIdx = result.indexOf('?')
                    result = if (queryIdx != -1) {
                        val before = result.substring(0, queryIdx)
                        val query = result.substring(queryIdx)
                        "$before!9m1!1b1$query"
                    } else {
                        "$result!9m1!1b1"
                    }
                } else {
                    result = if (result.contains("?")) {
                        val parts = result.split("?", limit = 2)
                        "${parts[0].trimEnd('/')}/data=!9m1!1b1?${parts[1]}"
                    } else {
                        "${result.trimEnd('/')}/data=!9m1!1b1"
                    }
                }
            }

            if (!result.contains("action=openreviews", ignoreCase = true)) {
                result = if (result.contains("?")) {
                    "$result&action=openreviews"
                } else {
                    "$result?action=openreviews"
                }
            }
        }

        return result
    }

    fun extractHexPair(url: String): String? {
        try {
            val pattern = Pattern.compile("""(?:!1s|ftid=)(0x[0-9a-fA-F]+:0x[0-9a-fA-F]+)""")
            val matcher = pattern.matcher(url)
            if (matcher.find()) {
                val pair = matcher.group(1)
                if (!pair.isNullOrBlank()) return pair
            }
        } catch (_: Exception) {
        }
        return null
    }

    /**
     * Synchronously returns the best direct review URL from a given input (preferring Place ID write-review,
     * g.page/review, or Maps !9m1!1b1 Reviews Tab).
     */
    fun getDirectWriteReviewUrl(urlOrInput: String, shopName: String? = null): String {
        val trimmed = urlOrInput.trim()
        if (trimmed.isBlank()) {
            val name = shopName?.trim()?.takeIf { it.isNotBlank() } ?: "Google Review"
            return "https://www.google.com/maps/search/?api=1&query=${URLEncoder.encode(name, "UTF-8")}&action=openreviews"
        }

        if (trimmed.contains("search.google.com/local/writereview") ||
            (trimmed.contains("g.page/") && trimmed.endsWith("/review")) ||
            trimmed.contains("#lrd=")
        ) {
            return trimmed
        }

        if (isValidPlaceId(trimmed)) {
            return "$PLACE_ID_WRITE_REVIEW_BASE$trimmed"
        }

        val placeId = extractPlaceId(trimmed)
        if (!placeId.isNullOrBlank()) {
            return "$PLACE_ID_WRITE_REVIEW_BASE$placeId"
        }

        if (trimmed.contains("google.com/maps") || trimmed.contains("maps.google.com")) {
            return convertToGoogleMapsReviewTabUrl(trimmed)
        }

        val cid = extractCid(trimmed)
        if (!cid.isNullOrBlank()) {
            return "$CID_MAPS_REVIEW_BASE$cid&action=openreviews"
        }

        return trimmed
    }
}
