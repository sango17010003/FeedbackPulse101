package com.example.util

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.local.QrTagEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExcelExportHelper {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    private val fileTimestampFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())

    /**
     * Generates standard RFC-4180 CSV spreadsheet content compatible with Microsoft Excel,
     * Google Sheets, and LibreOffice.
     * Includes all fields: Serial Number, Shop Name, WhatsApp Number, Number of QRs Taken, Money Received, etc.
     */
    fun generateCsvString(tags: List<QrTagEntity>): String {
        val sb = StringBuilder()

        // Excel-compatible BOM for UTF-8 so international currencies (₹, €, etc.) render cleanly
        sb.append("\uFEFF")

        // Header Row as explicitly required:
        // Serial Number, Shop Name, WhatsApp Number, No. of QRs Taken, Money Received, Currency, etc.
        sb.append("Serial Number,Shop Name,WhatsApp Number,No. of QRs Taken,Money Received,Currency,Google Review Link,Status,Date Assigned,Total Scans,High Praise Reviews (>=9/15),Private Feedbacks (<9/15),Notes\n")

        tags.forEach { tag ->
            val serial = escapeCsv(tag.serialNumber)
            val shop = escapeCsv(tag.shopName ?: tag.title ?: "Unassigned")
            val phone = escapeCsv(tag.whatsappNumber ?: tag.contactPhone ?: "")
            val qrs = tag.qrCountTaken.toString()
            val money = "%.2f".format(tag.moneyReceived)
            val curr = escapeCsv(tag.currency)
            val reviewLink = escapeCsv(tag.googleReviewUrl ?: tag.destinationUrl ?: "")
            val status = escapeCsv(if (tag.isLinked) "Linked" else "Unlinked")
            val dateAssigned = escapeCsv(tag.linkedAt?.let { dateFormat.format(Date(it)) } ?: dateFormat.format(Date(tag.createdAt)))
            val scans = tag.scanCount.toString()
            val positiveReviews = tag.positiveReviewsCount.toString()
            val privateFeedbacks = tag.privateFeedbacksCount.toString()
            val notes = escapeCsv(tag.notes ?: "")

            sb.append("$serial,$shop,$phone,$qrs,$money,$curr,$reviewLink,$status,$dateAssigned,$scans,$positiveReviews,$privateFeedbacks,$notes\n")
        }

        return sb.toString()
    }

    /**
     * Exports the tags ledger to a CSV file and triggers an Android Share / Open intent
     * via FileProvider, allowing the user to open directly in Excel or send to WhatsApp/Drive.
     */
    fun exportAndShareExcel(context: Context, tags: List<QrTagEntity>): Boolean {
        return try {
            val csvContent = generateCsvString(tags)
            val excelDir = File(context.cacheDir, "excel").apply { mkdirs() }
            val fileName = "Trust_Review_Ledger_${fileTimestampFormat.format(Date())}.csv"
            val file = File(excelDir, fileName)

            FileOutputStream(file).use { out ->
                out.write(csvContent.toByteArray(Charsets.UTF_8))
            }

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_SUBJECT, "Trust Review Shop Ledger & QR Registry")
                putExtra(Intent.EXTRA_TEXT, "Attached is the Trust Review Shop QR Registry & Revenue Ledger containing ${tags.size} records.")
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, "Open or Send Shop Ledger (Excel / Sheets)")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Export failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun escapeCsv(value: String): String {
        return if (value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r")) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
    }
}
