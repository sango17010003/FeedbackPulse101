package com.example.util

import java.security.SecureRandom

object SerialGenerator {
    private val random = SecureRandom()
    private const val ALPHANUM = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ" // Excludes 0, 1, I, O to avoid confusion

    const val DEFAULT_DOMAIN = "https://qr-redirector-xb5h.onrender.com/r/"
    var customDomain: String = DEFAULT_DOMAIN

    /**
     * Generates a readable, collision-resistant serial number:
     * e.g. "TR-8492-X7K" or "REV-3910-9MA"
     */
    fun generateSerial(prefix: String = "TR-"): String {
        val cleanPrefix = if (prefix.isNotBlank()) {
            if (prefix.endsWith("-")) prefix.uppercase() else "${prefix.uppercase()}-"
        } else "TR-"

        val part1 = buildString {
            repeat(4) { append(ALPHANUM[random.nextInt(ALPHANUM.length)]) }
        }
        val part2 = buildString {
            repeat(3) { append(ALPHANUM[random.nextInt(ALPHANUM.length)]) }
        }

        return "$cleanPrefix$part1-$part2"
    }

    /**
     * Generates a unique secure URL token
     */
    fun generateToken(): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val sb = StringBuilder("tkn_")
        repeat(8) {
            sb.append(chars[random.nextInt(chars.length)])
        }
        return sb.toString()
    }

    /**
     * Normalizes a personal domain URL into a clean base URL (e.g. "https://qr-redirector-xb5h.onrender.com/r/")
     */
    fun normalizeDomain(domain: String): String {
        val trimmed = domain.trim()
        if (trimmed.isBlank()) return DEFAULT_DOMAIN
        return if (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true)) {
            "https://$trimmed"
        } else {
            trimmed
        }
    }

    /**
     * Standard URL payload embedded inside the dynamic QR code.
     * Links directly to the redirector domain with the unique QR serial number:
     * e.g. "https://qr-redirector-xb5h.onrender.com/r/TR-8421-MPK"
     * Always adds the QR unique ID after "r/" and NEVER appends "/review?sn=".
     */
    fun buildQrPayload(serialNumber: String, domain: String = customDomain): String {
        val base = normalizeDomain(domain).trimEnd('/')
        return if (base.endsWith("/r", ignoreCase = true)) {
            "$base/$serialNumber"
        } else {
            "$base/r/$serialNumber"
        }
    }

    /**
     * Parses a serial number from scanned QR payload string or raw text
     */
    fun extractSerialNumber(scannedContent: String): String {
        val trimmed = scannedContent.trim()
        
        // If it contains sn= or serial= or id=
        if (trimmed.contains("sn=", ignoreCase = true)) {
            val sn = trimmed.substringAfter("sn=", "").substringBefore("&").substringBefore("#")
            if (sn.isNotBlank()) return sn.uppercase()
        }
        if (trimmed.contains("serial=", ignoreCase = true)) {
            val sn = trimmed.substringAfter("serial=", "").substringBefore("&").substringBefore("#")
            if (sn.isNotBlank()) return sn.uppercase()
        }

        // If it's a URL path like /r/TR-8421-MPK or /review/TR-8421-MPK or /qr/TR-8421-MPK
        if (trimmed.contains("/r/")) {
            val afterSlash = trimmed.substringAfterLast("/r/").substringBefore("?").substringBefore("/").substringBefore("#")
            if (afterSlash.isNotBlank()) return afterSlash.uppercase()
        }
        if (trimmed.contains("/review/")) {
            val afterSlash = trimmed.substringAfterLast("/review/").substringBefore("?").substringBefore("/").substringBefore("#")
            if (afterSlash.isNotBlank()) return afterSlash.uppercase()
        }
        if (trimmed.contains("/qr/")) {
            val afterSlash = trimmed.substringAfterLast("/qr/").substringBefore("?").substringBefore("/").substringBefore("#")
            if (afterSlash.isNotBlank()) return afterSlash.uppercase()
        }

        // If URL has hash #TR-1234-XYZ
        if (trimmed.contains("#") && (trimmed.startsWith("http://") || trimmed.startsWith("https://"))) {
            val hashPart = trimmed.substringAfter("#")
            if (hashPart.isNotBlank() && hashPart.length >= 6) return hashPart.uppercase()
        }

        // Otherwise treat entire string as serial
        return trimmed.uppercase()
    }
}
