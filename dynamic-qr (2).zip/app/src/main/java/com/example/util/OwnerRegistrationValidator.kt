package com.example.util

data class OwnerAgeValidationResult(
    val isValid: Boolean,
    val isBelow18: Boolean = false,
    val requiresParentalConsent: Boolean = false,
    val errorMessage: String? = null
)

object OwnerRegistrationValidator {

    fun validate(
        isBelow18: Boolean,
        parentGuardianName: String,
        parentConsentChecked: Boolean
    ): OwnerAgeValidationResult {
        if (!isBelow18) {
            return OwnerAgeValidationResult(
                isValid = true,
                isBelow18 = false,
                requiresParentalConsent = false
            )
        }

        if (parentGuardianName.trim().isBlank()) {
            return OwnerAgeValidationResult(
                isValid = false,
                isBelow18 = true,
                requiresParentalConsent = true,
                errorMessage = "Parental consent required: please enter Parent / Guardian Full Name."
            )
        }

        if (!parentConsentChecked) {
            return OwnerAgeValidationResult(
                isValid = false,
                isBelow18 = true,
                requiresParentalConsent = true,
                errorMessage = "Please confirm parental consent to continue registration under 18."
            )
        }

        return OwnerAgeValidationResult(
            isValid = true,
            isBelow18 = true,
            requiresParentalConsent = true
        )
    }
}
