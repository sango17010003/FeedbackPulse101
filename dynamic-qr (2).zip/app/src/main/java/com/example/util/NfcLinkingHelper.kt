package com.example.util

import android.content.Context
import android.net.Uri
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import java.nio.charset.Charset

sealed class NfcWriteState {
    object Idle : NfcWriteState()
    data class WaitingForTag(val serialNumber: String, val url: String) : NfcWriteState()
    data class Reading(val serialNumber: String, val url: String, val existingUrl: String? = null) : NfcWriteState()
    object Writing : NfcWriteState()
    data class Success(val info: NfcTagInfo) : NfcWriteState()
    data class Error(val message: String) : NfcWriteState()
}

sealed class NfcWriteResult {
    data class Success(val info: NfcTagInfo) : NfcWriteResult()
    data class Failure(val message: String) : NfcWriteResult()
}

data class NfcTagInfo(
    val uid: String,
    val type: String = "NTAG213 / NTAG215 (Type 2 Tag)",
    val isWritable: Boolean = true,
    val capacityBytes: Int = 540,
    val payloadUrl: String,
    val serialNumber: String,
    val previousUrl: String? = null,
    val formattedTimestamp: Long = System.currentTimeMillis()
)

object NfcLinkingHelper {

    private val _writeState = kotlinx.coroutines.flow.MutableStateFlow<NfcWriteState>(NfcWriteState.Idle)
    val writeState: kotlinx.coroutines.flow.StateFlow<NfcWriteState> = _writeState

    val isWaitingForTag: Boolean
        get() = _writeState.value is NfcWriteState.WaitingForTag || _writeState.value is NfcWriteState.Reading

    var pendingSerial: String? = null
        private set
    var pendingPayload: String? = null
        private set

    fun startWaitingForTag(serial: String, url: String) {
        pendingSerial = serial
        pendingPayload = url
        _writeState.value = NfcWriteState.WaitingForTag(serial, url)
    }

    fun markReadingState(serial: String, url: String, existingUrl: String? = null) {
        pendingSerial = serial
        pendingPayload = url
        _writeState.value = NfcWriteState.Reading(serial, url, existingUrl)
    }

    fun markWritingState() {
        _writeState.value = NfcWriteState.Writing
    }

    fun cancelWaitingForTag() {
        pendingSerial = null
        pendingPayload = null
        _writeState.value = NfcWriteState.Idle
    }

    fun handleTagDetectedForWriting(tag: Tag): NfcWriteResult? {
        val payload = pendingPayload ?: return null
        val serial = pendingSerial ?: ""

        // Step 1: Reading existing tag data & UID
        val existingUrl = readNdefUriFromTag(tag)
        _writeState.value = NfcWriteState.Reading(serial, payload, existingUrl)

        // Step 2: Writing dynamic feedback URL
        _writeState.value = NfcWriteState.Writing
        val result = writeNdefUriToTag(tag, payload)
        val uid = bytesToHex(tag.id)

        // Step 3: Success or Error
        return if (result.isSuccess) {
            val tech = tag.techList.map { it.substringAfterLast('.') }.joinToString(", ")
            val info = NfcTagInfo(
                uid = uid,
                type = if (tech.isNotBlank()) "Physical NFC Tag ($tech)" else "NTAG213 / NTAG215",
                isWritable = true,
                capacityBytes = 540,
                payloadUrl = payload,
                serialNumber = serial,
                previousUrl = existingUrl
            )
            _writeState.value = NfcWriteState.Success(info)
            pendingSerial = null
            pendingPayload = null
            NfcWriteResult.Success(info)
        } else {
            val err = result.exceptionOrNull()?.message ?: "Failed to write NFC tag"
            _writeState.value = NfcWriteState.Error(err)
            NfcWriteResult.Failure(err)
        }
    }

    fun simulateTagWrite(serial: String, url: String): NfcTagInfo {
        val info = simulateNfcTagLink(serial, url)
        _writeState.value = NfcWriteState.Success(info)
        pendingSerial = null
        pendingPayload = null
        return info
    }

    fun resetWriteState() {
        _writeState.value = NfcWriteState.Idle
        pendingSerial = null
        pendingPayload = null
    }

    fun enableReaderModeForWriting(activity: android.app.Activity, serial: String, url: String) {
        startWaitingForTag(serial, url)
        try {
            val adapter = NfcAdapter.getDefaultAdapter(activity.applicationContext) ?: return
            if (!adapter.isEnabled) return
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V
            adapter.enableReaderMode(
                activity,
                { tag ->
                    if (tag != null && isWaitingForTag) {
                        handleTagDetectedForWriting(tag)
                    }
                },
                flags,
                null
            )
        } catch (_: Exception) {
        }
    }

    fun disableReaderMode(activity: android.app.Activity) {
        try {
            NfcAdapter.getDefaultAdapter(activity.applicationContext)?.disableReaderMode(activity)
        } catch (_: Exception) {
        }
    }

    fun isNfcSupported(context: Context): Boolean {
        return try {
            NfcAdapter.getDefaultAdapter(context.applicationContext) != null
        } catch (_: Exception) {
            false
        }
    }

    fun isNfcEnabled(context: Context): Boolean {
        return try {
            val adapter = NfcAdapter.getDefaultAdapter(context.applicationContext)
            adapter?.isEnabled == true
        } catch (_: Exception) {
            false
        }
    }

    fun buildNfcPayload(serial: String): String {
        return SerialGenerator.buildQrPayload(serial)
    }

    fun createNdefUriMessage(url: String): NdefMessage {
        val record = NdefRecord.createUri(Uri.parse(url))
        return NdefMessage(arrayOf(record))
    }

    fun readNdefUrl(tag: Tag): String? = readNdefUriFromTag(tag)

    fun writeNdefUriToTag(tag: Tag, url: String): Result<String> {
        val ndefMessage = createNdefUriMessage(url)
        val size = ndefMessage.toByteArray().size

        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                if (!ndef.isWritable) {
                    ndef.close()
                    return Result.failure(Exception("NFC Tag is locked or write-protected."))
                }
                if (ndef.maxSize < size) {
                    val max = ndef.maxSize
                    ndef.close()
                    return Result.failure(Exception("NFC Tag capacity ($max bytes) is too small for payload ($size bytes)."))
                }
                ndef.writeNdefMessage(ndefMessage)
                ndef.close()
                return Result.success("Successfully programmed NFC tag with $url")
            } else {
                val formatable = NdefFormatable.get(tag)
                if (formatable != null) {
                    formatable.connect()
                    formatable.format(ndefMessage)
                    formatable.close()
                    return Result.success("Formatted and programmed NFC tag with $url")
                }
                return Result.failure(Exception("Tag does not support standard NDEF formatting."))
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    fun readNdefUriFromTag(tag: Tag): String? {
        try {
            val ndef = Ndef.get(tag) ?: return null
            ndef.connect()
            val message = ndef.ndefMessage
            ndef.close()

            if (message != null && message.records.isNotEmpty()) {
                val record = message.records[0]
                val uri = record.toUri()
                if (uri != null) return uri.toString()

                // Fallback manual URI extraction
                if (record.tnf == NdefRecord.TNF_WELL_KNOWN && record.type.contentEquals(NdefRecord.RTD_URI)) {
                    val payload = record.payload
                    val prefixByte = payload[0].toInt()
                    val prefix = getUriPrefix(prefixByte)
                    val body = String(payload, 1, payload.size - 1, Charset.forName("UTF-8"))
                    return "$prefix$body"
                }
            }
        } catch (_: Exception) {}
        return null
    }

    fun bytesToHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (b in bytes) {
            sb.append(String.format("%02X", b))
        }
        return sb.toString()
    }

    fun simulateNfcTagLink(serialNumber: String, url: String): NfcTagInfo {
        val randomHex = (100000..999999).random().toString(16).uppercase()
        val uid = "04:$randomHex:${serialNumber.takeLast(4)}"
        return NfcTagInfo(
            uid = uid,
            type = "NXP NTAG213 (Standard Smart Standee Chip)",
            isWritable = true,
            capacityBytes = 144,
            payloadUrl = url,
            serialNumber = serialNumber
        )
    }

    private fun getUriPrefix(prefixByte: Int): String {
        return when (prefixByte) {
            0x01 -> "http://www."
            0x02 -> "https://www."
            0x03 -> "http://"
            0x04 -> "https://"
            0x05 -> "tel:"
            0x06 -> "mailto:"
            else -> ""
        }
    }
}
