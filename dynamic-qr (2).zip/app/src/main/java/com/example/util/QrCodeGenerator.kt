package com.example.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object QrCodeGenerator {

    private const val FALLBACK_QR_CONTENT = "https://qr-redirector-xb5h.onrender.com/r/stand1"

    /**
     * Encodes [content] into a ZXing QR [com.google.zxing.common.BitMatrix].
     * Safely falls back if [content] is blank and clamps [size] so QR generation never crashes.
     */
    fun encodeQrMatrix(
        content: String,
        size: Int = 512
    ): com.google.zxing.common.BitMatrix {
        val safeContent = content.trim().ifBlank { FALLBACK_QR_CONTENT }
        val safeSize = size.coerceIn(64, 2048)
        val hints = HashMap<EncodeHintType, Any>().apply {
            put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H)
            put(EncodeHintType.MARGIN, 2)
            put(EncodeHintType.CHARACTER_SET, "UTF-8")
        }
        return QRCodeWriter().encode(safeContent, BarcodeFormat.QR_CODE, safeSize, safeSize, hints)
    }

    /**
     * Generates a high-quality QR code Bitmap using the ZXing library.
     * Safely falls back if [content] is blank so Compose UI never crashes on empty inputs.
     */
    fun generateQrBitmap(
        content: String,
        size: Int = 512,
        foregroundColor: Int = android.graphics.Color.BLACK,
        backgroundColor: Int = android.graphics.Color.WHITE
    ): Bitmap {
        val bitMatrix = encodeQrMatrix(content, size)
        val width = bitMatrix.width
        val height = bitMatrix.height
        val pixels = IntArray(width * height)
        for (y in 0 until height) {
            val offset = y * width
            for (x in 0 until width) {
                pixels[offset + x] = if (bitMatrix.get(x, y)) foregroundColor else backgroundColor
            }
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, width, 0, 0, width, height)
        }
    }

    /**
     * Generates a Compose ImageBitmap directly using ZXing.
     */
    fun generateQrImageBitmap(
        content: String,
        size: Int = 512,
        foregroundColor: Int = android.graphics.Color.BLACK,
        backgroundColor: Int = android.graphics.Color.WHITE
    ): ImageBitmap {
        return generateQrBitmap(content, size, foregroundColor, backgroundColor).asImageBitmap()
    }

    /**
     * Generates a complete printable Sticker Card Bitmap with:
     * - Top tag header ("DYNAMIC QR TAG")
     * - Centered ZXing QR code
     * - Serial Number in bold monospace font
     * - Status / Instructions
     */
    fun generateStickerBitmap(
        serialNumber: String,
        qrContent: String,
        batchName: String = "Dynamic Location Tag",
        width: Int = 600,
        height: Int = 750
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgPaint = Paint().apply {
            color = android.graphics.Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val borderPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawRoundRect(16f, 16f, width - 16f, height - 16f, 24f, 24f, borderPaint)

        val headerPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#0F172A")
            textSize = 28f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("DYNAMIC QR TAG", width / 2f, 65f, headerPaint)

        val subHeaderPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#64748B")
            textSize = 20f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(batchName.take(30), width / 2f, 100f, subHeaderPaint)

        val qrSize = 380
        val qrBitmap = generateQrBitmap(qrContent, qrSize)
        val qrLeft = (width - qrSize) / 2f
        val qrTop = 130f
        canvas.drawBitmap(qrBitmap, qrLeft, qrTop, null)

        val serialBoxPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#F1F5F9")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(40f, 540f, width - 40f, 620f, 16f, 16f, serialBoxPaint)

        val serialTextPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#0F172A")
            textSize = 34f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(serialNumber.ifBlank { "STAND1" }, width / 2f, 592f, serialTextPaint)

        val footerPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#0284C7")
            textSize = 20f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("SCAN TO SHARE FEEDBACK", width / 2f, 670f, footerPaint)

        val tipPaint = Paint().apply {
            color = android.graphics.Color.parseColor("#94A3B8")
            textSize = 16f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("Powered by Dynamic QR Redirector", width / 2f, 705f, tipPaint)

        return bitmap
    }
}
