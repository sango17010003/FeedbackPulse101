package com.example.util

import com.example.data.local.QrStandEntity

enum class PositivePresetTone(val label: String) {
    WARM("Warm"),
    SHORT("Quick"),
    DETAILED("Detailed")
}

object PositiveReviewPresetHelper {

    fun buildPreset(
        shop: QrStandEntity?,
        tone: PositivePresetTone = PositivePresetTone.WARM
    ): String {
        val shopName = shop?.shopName?.trim()?.takeIf { it.isNotBlank() } ?: "this shop"
        val ownerName = shop?.displayOwnerName?.trim().orEmpty()
        val ownerHostClause = if (ownerName.isNotBlank()) " and warm hospitality from $ownerName" else ""
        val ownerHostedBy = if (ownerName.isNotBlank()) " hosted by $ownerName" else ""

        return when (tone) {
            PositivePresetTone.WARM ->
                "Had a wonderful experience at $shopName! Great quality, spotless cleanliness,$ownerHostClause. Highly recommended!"

            PositivePresetTone.SHORT ->
                "Loved visiting $shopName! Excellent quality, super clean, and friendly service. 5 stars!"

            PositivePresetTone.DETAILED ->
                "Visited $shopName$ownerHostedBy and couldn't be happier! Everything stood out for its great quality, attentive staff service, and clean, welcoming atmosphere. Will definitely come back!"
        }
    }
}
