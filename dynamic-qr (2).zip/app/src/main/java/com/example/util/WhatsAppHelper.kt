package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

object WhatsAppHelper {

    /**
     * Cleans phone number by removing spaces, brackets, hyphens, and leading '+'
     * so it is in E.164 numerical format required by WhatsApp (e.g. 16505551234 or 919876543210)
     */
    fun cleanPhoneNumber(phone: String): String {
        return phone.replace(Regex("[^0-9]"), "")
    }

    /**
     * Sends a direct WhatsApp message to the given phone number with prefilled text.
     * Supports standard WhatsApp, WhatsApp Business, and browser fallback.
     */
    fun sendWhatsAppMessage(context: Context, rawPhone: String, message: String) {
        val cleanPhone = cleanPhoneNumber(rawPhone)
        if (cleanPhone.isBlank()) {
            Toast.makeText(context, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage")

            val intent = Intent(Intent.ACTION_VIEW, uri)

            // Attempt to launch via WhatsApp package directly if installed
            val packageManager = context.packageManager
            val isWhatsAppInstalled = try {
                packageManager.getPackageInfo("com.whatsapp", 0)
                true
            } catch (e: Exception) {
                false
            }

            val isWhatsAppBusinessInstalled = try {
                packageManager.getPackageInfo("com.whatsapp.w4b", 0)
                true
            } catch (e: Exception) {
                false
            }

            when {
                isWhatsAppInstalled -> intent.setPackage("com.whatsapp")
                isWhatsAppBusinessInstalled -> intent.setPackage("com.whatsapp.w4b")
            }

            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                // If package launch fails, fallback to general ACTION_VIEW with universal link
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$cleanPhone?text=$encodedMessage"))
                context.startActivity(fallbackIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Could not open WhatsApp: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Builds onboarding/welcome message sent to the shop owner upon one-time registration
     */
    fun buildShopWelcomeMessage(
        shopName: String,
        serial: String,
        qrCount: Int,
        moneyReceived: Double,
        currency: String = "₹",
        googleReviewUrl: String?
    ): String {
        val linkText = if (!googleReviewUrl.isNullOrBlank()) "\n⭐ Linked Google Review: $googleReviewUrl" else ""
        return """
            🎉 Welcome to TR Reviewers!
            
            Hello $shopName,
            Your Dynamic QR Code has been registered and activated.
            
            🏷️ QR Serial: $serial
            📦 QRs Provided: $qrCount
            💰 Payment Received: $currency${"%.0f".format(moneyReceived)}$linkText
            
            Customers scanning your QR code will be prompted for a 3-question review (15 stars total). High-praise reviews (>=9/15) will be copied and redirected to your official Google Reviews!
        """.trimIndent()
    }

    /**
     * Builds message alert when a customer rates >= 9/15 stars and is redirected to Google Reviews
     */
    fun buildHighPraiseAlertMessage(
        shopName: String,
        serial: String,
        totalScore: Int,
        reviewText: String
    ): String {
        val snippet = if (reviewText.isNotBlank()) "\nReview: \"$reviewText\"" else ""
        return """
            ⭐ High Praise Review Alert!
            
            Shop: $shopName
            Rating: $totalScore / 15 Stars ⭐⭐⭐⭐⭐
            Serial: $serial$snippet
            
            The customer's review was copied to their clipboard and they were redirected to your Google Reviews page to post!
        """.trimIndent()
    }

    /**
     * Builds message when customer rates < 9/15 stars (private feedback captured, not redirected)
     */
    fun buildPrivateFeedbackMessage(
        shopName: String,
        serial: String,
        totalScore: Int,
        reviewText: String,
        q1Score: Int = 0,
        q2Score: Int = 0,
        q3Score: Int = 0
    ): String {
        val breakdown = if (q1Score > 0) "\n- Service/Quality: $q1Score/5\n- Staff/Ambience: $q2Score/5\n- Recommendation: $q3Score/5" else ""
        val comment = if (reviewText.isNotBlank()) "\nFeedback Details: \"$reviewText\"" else ""
        return """
            💬 Private Customer Feedback
            
            Shop: $shopName
            Score: $totalScore / 15 Stars (Constructive Feedback)
            Serial: $serial$breakdown$comment
            
            Notice: This review was kept PRIVATE and NOT redirected to Google Reviews. We have assured the customer of betterment. You may connect with them to resolve their concern.
        """.trimIndent()
    }

    /**
     * Builds a structured, professional message linking the serial number and exact coordinates
     */
    fun buildDefaultMessage(
        serial: String,
        contactName: String?,
        latitude: Double?,
        longitude: Double?,
        notes: String?
    ): String {
        val greeting = if (!contactName.isNullOrBlank()) "Hello $contactName," else "Hello,"
        val mapLink = if (latitude != null && longitude != null) {
            "Google Map Location (Lat: $latitude, Lng: $longitude):\nhttps://www.google.com/maps/search/?api=1&query=$latitude,$longitude"
        } else ""

        val notesPart = if (!notes.isNullOrBlank()) "\nNotes: $notes" else ""

        return "$greeting\nReaching out regarding Dynamic QR Tag Serial: $serial\n$mapLink$notesPart"
    }

    /**
     * Opens the device phone dialer with the contact number
     */
    fun openDialer(context: Context, rawPhone: String) {
        val trimmed = rawPhone.trim()
        if (trimmed.isBlank()) return
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$trimmed"))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open dialer", Toast.LENGTH_SHORT).show()
        }
    }
}
