package com.example.util

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.widget.Toast
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.regex.Pattern
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object LocationHelper {

    private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { result ->
            if (cont.isActive) cont.resume(result)
        }
        addOnFailureListener { e ->
            if (cont.isActive) cont.resumeWithException(e)
        }
        addOnCanceledListener {
            cont.cancel()
        }
    }

    data class LocationResult(
        val latitude: Double,
        val longitude: Double,
        val formattedAddress: String?,
        val mapsUrl: String
    )

    /**
     * Gets current GPS coordinates and geocoded address
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentGpsLocation(context: Context): LocationResult? {
        return try {
            val fusedClient = LocationServices.getFusedLocationProviderClient(context)
            val cts = CancellationTokenSource()
            val location: Location? = fusedClient.getCurrentLocation(
                Priority.PRIORITY_HIGH_ACCURACY,
                cts.token
            ).awaitResult() ?: fusedClient.lastLocation.awaitResult()

            if (location != null) {
                val lat = location.latitude
                val lng = location.longitude
                val address = resolveAddress(context, lat, lng)
                // Always strictly use latitude and longitude only for map navigation
                val mapsUrl = buildGoogleMapsUrl(lat, lng)
                LocationResult(lat, lng, address, mapsUrl)
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Reverse geocodes coordinates to human readable address
     */
    fun resolveAddress(context: Context, latitude: Double, longitude: Double): String? {
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val list = geocoder.getFromLocation(latitude, longitude, 1)
            if (!list.isNullOrEmpty()) {
                val addr = list[0]
                val lines = mutableListOf<String>()
                for (i in 0..addr.maxAddressLineIndex) {
                    addr.getAddressLine(i)?.let { lines.add(it) }
                }
                if (lines.isNotEmpty()) lines.joinToString(", ") else addr.locality
            } else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Forward geocodes an address to latitude and longitude
     */
    fun geocodeAddressToCoordinates(context: Context, address: String): Pair<Double, Double>? {
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val list = geocoder.getFromLocationName(address, 1)
            if (!list.isNullOrEmpty()) {
                Pair(list[0].latitude, list[0].longitude)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Parses latitude and longitude from Google Maps URLs, Apple Maps URLs, or query text.
     * Extracts coordinates from:
     * - Protobuf URLs: !3d<lat>!4d<lng>
     * - Viewport/center URLs: @<lat>,<lng>
     * - Query parameters: ?q=<lat>,<lng> or ?query=<lat>,<lng> or &ll=<lat>,<lng>
     * - Geo scheme: geo:<lat>,<lng>
     * - Raw lat, lng strings: "37.4220, -122.0841"
     */
    fun parseCoordinatesFromUrlOrText(input: String): Pair<Double, Double>? {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return null

        // 1. Protobuf format in Google Maps URLs: !3d<lat>!4d<lng>
        val protoPattern = Pattern.compile("!3d(-?\\d+\\.\\d+)!4d(-?\\d+\\.\\d+)")
        val protoMatcher = protoPattern.matcher(trimmed)
        if (protoMatcher.find()) {
            val lat = protoMatcher.group(1)?.toDoubleOrNull()
            val lng = protoMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }

        // 2. Viewport format @<lat>,<lng> e.g. https://www.google.com/maps/place/.../@37.4220,-122.0841,17z
        val atPattern = Pattern.compile("@(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)")
        val atMatcher = atPattern.matcher(trimmed)
        if (atMatcher.find()) {
            val lat = atMatcher.group(1)?.toDoubleOrNull()
            val lng = atMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }

        // 3. Query param like ?q=37.4220,-122.0841 or &query=37.4220,-122.0841 or ll=... or destination=...
        val queryPattern = Pattern.compile("[?&](?:q|query|ll|sll|center|destination|daddr|saddr|loc)=(-?\\d+\\.\\d+)(?:,|%2C|\\+)(-?\\d+\\.\\d+)", Pattern.CASE_INSENSITIVE)
        val queryMatcher = queryPattern.matcher(trimmed)
        if (queryMatcher.find()) {
            val lat = queryMatcher.group(1)?.toDoubleOrNull()
            val lng = queryMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }

        // 4. Geo scheme: geo:37.4220,-122.0841 or geo:0,0?q=37.4220,-122.0841
        val geoPattern = Pattern.compile("geo:(?:0,0\\?q=)?(-?\\d+\\.\\d+),(?:%20)?(-?\\d+\\.\\d+)", Pattern.CASE_INSENSITIVE)
        val geoMatcher = geoPattern.matcher(trimmed)
        if (geoMatcher.find()) {
            val lat = geoMatcher.group(1)?.toDoubleOrNull()
            val lng = geoMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }

        // 5. Named keys like "latitude: 37.4220, longitude: -122.0841" or "lat: 37.4220, lng: -122.0841"
        val namedPattern = Pattern.compile("(?:lat|latitude)[:=\\s]+(-?\\d+\\.\\d+)[,\\s]+(?:lng|lon|longitude)[:=\\s]+(-?\\d+\\.\\d+)", Pattern.CASE_INSENSITIVE)
        val namedMatcher = namedPattern.matcher(trimmed)
        if (namedMatcher.find()) {
            val lat = namedMatcher.group(1)?.toDoubleOrNull()
            val lng = namedMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }

        // 6. Raw "lat, lng" e.g. "37.4220, -122.0841" or "37.4220 -122.0841"
        val rawPattern = Pattern.compile("^(-?\\d+\\.\\d+)(?:\\s*,\\s*|\\s+)(-?\\d+\\.\\d+)$")
        val rawMatcher = rawPattern.matcher(trimmed)
        if (rawMatcher.find()) {
            val lat = rawMatcher.group(1)?.toDoubleOrNull()
            val lng = rawMatcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) return Pair(lat, lng)
        }

        return null
    }

    /**
     * Resolves coordinates from an input string, Google Maps URL, short link (e.g. maps.app.goo.gl),
     * or address text. Follows HTTP redirects in background if needed.
     */
    suspend fun resolveCoordinatesFromInputOrUrl(context: Context, input: String): Pair<Double, Double>? {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return null

        // 1. Direct parse
        val direct = parseCoordinatesFromUrlOrText(trimmed)
        if (direct != null) return direct

        // 2. If it's a web link (e.g. maps.app.goo.gl, goo.gl/maps), resolve redirect
        if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
            val resolvedUrl = withContext(Dispatchers.IO) {
                try {
                    val url = URL(trimmed)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.instanceFollowRedirects = true
                    conn.connectTimeout = 4000
                    conn.readTimeout = 4000
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    conn.connect()
                    val finalUrl = conn.url.toString()
                    val locationHeader = conn.getHeaderField("Location")
                    conn.disconnect()
                    locationHeader ?: finalUrl
                } catch (e: Exception) {
                    null
                }
            }
            if (resolvedUrl != null) {
                val coords = parseCoordinatesFromUrlOrText(resolvedUrl)
                if (coords != null) return coords
            }
        }

        // 3. Fallback: try geocoding input as address
        return withContext(Dispatchers.IO) {
            geocodeAddressToCoordinates(context, trimmed)
        }
    }

    /**
     * Generates a canonical Google Maps URL using ONLY latitude and longitude.
     * Strictly avoids including place name or title as requested.
     */
    fun buildGoogleMapsUrl(lat: Double, lng: Double): String {
        return "https://www.google.com/maps/search/?api=1&query=$lat,$lng"
    }

    /**
     * Opens the location on map strictly using ONLY latitude and longitude.
     * Never uses place name or title query.
     */
    fun openLocationOnMap(
        context: Context,
        latitude: Double?,
        longitude: Double?,
        fallbackUrl: String? = null
    ) {
        if (latitude != null && longitude != null) {
            val geoUri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude")
            val webUrl = buildGoogleMapsUrl(latitude, longitude)

            val mapIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
                setPackage("com.google.android.apps.maps")
            }
            try {
                context.startActivity(mapIntent)
            } catch (e: Exception) {
                // Fallback to browser or default handler strictly with coordinates URL
                try {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl))
                    context.startActivity(browserIntent)
                } catch (e2: Exception) {
                    Toast.makeText(context, "Could not open map", Toast.LENGTH_SHORT).show()
                }
            }
        } else if (!fallbackUrl.isNullOrBlank()) {
            val coords = parseCoordinatesFromUrlOrText(fallbackUrl)
            if (coords != null) {
                openLocationOnMap(context, coords.first, coords.second)
            } else {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(context, "No coordinates linked to this tag", Toast.LENGTH_SHORT).show()
        }
    }
}
