package com.example

import com.example.data.local.QrTagEntity
import com.example.util.LocationHelper
import com.example.util.QrCodeGenerator
import com.example.util.SerialGenerator
import org.junit.Assert.*
import org.junit.Test
class ExampleUnitTest {
    @Test
    fun testSerialGeneratorFormat() {
        val serial = SerialGenerator.generateSerial("LOC-")
        assertTrue(serial.startsWith("LOC-"))
        val parts = serial.split("-")
        assertEquals(3, parts.size)
        assertEquals(4, parts[1].length)
        assertEquals(3, parts[2].length)
    }

    @Test
    fun testBuildQrPayloadFormat() {
        val serial = "TR-8421-MPK"
        val payload = SerialGenerator.buildQrPayload(serial)
        assertEquals("https://qr-redirector-xb5h.onrender.com/r/TR-8421-MPK", payload)
        assertFalse("Payload must never contain /review?sn=", payload.contains("/review?sn="))
        assertTrue("Payload must contain /r/ followed by serial number", payload.endsWith("/r/TR-8421-MPK"))

        // Extraction should parse this format accurately
        val extracted = SerialGenerator.extractSerialNumber(payload)
        assertEquals("TR-8421-MPK", extracted)
    }

    @Test
    fun testSerialExtractionFromPayload() {
        val payload = "https://qr-redirector-xb5h.onrender.com/r/LOC-8421-MPK"
        val extracted = SerialGenerator.extractSerialNumber(payload)
        assertEquals("LOC-8421-MPK", extracted)

        val directSerial = "TAG-1234-XYZ"
        assertEquals("TAG-1234-XYZ", SerialGenerator.extractSerialNumber(directSerial))

        val snParam = "https://example.com/scan?sn=LOC-7788-ABC&source=cam"
        assertEquals("LOC-7788-ABC", SerialGenerator.extractSerialNumber(snParam))
    }

    @Test
    fun testCoordinateParsing() {
        // Test @lat,lng format
        val mapsUrl1 = "https://www.google.com/maps/@37.422000,-122.084100,17z"
        val coords1 = LocationHelper.parseCoordinatesFromUrlOrText(mapsUrl1)
        assertNotNull(coords1)
        assertEquals(37.422, coords1!!.first, 0.001)
        assertEquals(-122.0841, coords1.second, 0.001)

        // Test ?q=lat,lng format
        val mapsUrl2 = "https://maps.google.com/?q=37.7749,-122.4194"
        val coords2 = LocationHelper.parseCoordinatesFromUrlOrText(mapsUrl2)
        assertNotNull(coords2)
        assertEquals(37.7749, coords2!!.first, 0.001)
        assertEquals(-122.4194, coords2.second, 0.001)

        // Test raw lat, lng string
        val rawInput = "34.0522, -118.2437"
        val coords3 = LocationHelper.parseCoordinatesFromUrlOrText(rawInput)
        assertNotNull(coords3)
        assertEquals(34.0522, coords3!!.first, 0.001)
        assertEquals(-118.2437, coords3.second, 0.001)

        // Test Google Maps web link with place name and @lat,lng
        val webLinkWithName = "https://www.google.com/maps/place/Googleplex+Headquarters/@37.4220,-122.0841,17z"
        val coords4 = LocationHelper.parseCoordinatesFromUrlOrText(webLinkWithName)
        assertNotNull(coords4)
        assertEquals(37.4220, coords4!!.first, 0.001)
        assertEquals(-122.0841, coords4.second, 0.001)

        // Test Google Maps protobuf URL with !3d<lat>!4d<lng>
        val protoUrl = "https://www.google.com/maps/place/Eiffel+Tower/data=!4m2!3m1!1s0x0:0x0!3d48.8584!4d2.2945"
        val coords5 = LocationHelper.parseCoordinatesFromUrlOrText(protoUrl)
        assertNotNull(coords5)
        assertEquals(48.8584, coords5!!.first, 0.001)
        assertEquals(2.2945, coords5.second, 0.001)
    }

    @Test
    fun testMapUrlOnlyUsesCoordinatesAndNoPlaceName() {
        val lat = 37.4220
        val lng = -122.0841
        val mapUrl = LocationHelper.buildGoogleMapsUrl(lat, lng)

        assertEquals("https://www.google.com/maps/search/?api=1&query=37.422,-122.0841", mapUrl)
        assertFalse("Map URL must not contain any place name", mapUrl.contains("Googleplex"))
        assertFalse("Map URL must not contain words other than query=lat,lng", mapUrl.contains("Headquarters"))
    }

    @Test
    fun testQrTagEntityEffectiveMapUrlUsesOnlyCoordinates() {
        val unlinked = QrTagEntity(
            serialNumber = "LOC-0001-AAA",
            token = "tkn_1",
            status = QrTagEntity.STATUS_UNLINKED
        )
        assertFalse(unlinked.isLinked)
        assertNull(unlinked.effectiveMapUrl)

        // Tag with place title, address, and coordinates: must only use latitude and longitude on map
        val linkedWithCoords = QrTagEntity(
            serialNumber = "LOC-0002-BBB",
            token = "tkn_2",
            status = QrTagEntity.STATUS_LINKED_LOCATION,
            title = "Googleplex Headquarters",
            address = "1600 Amphitheatre Pkwy, Mountain View, CA",
            latitude = 37.422,
            longitude = -122.084
        )
        assertTrue(linkedWithCoords.isLinked)
        assertTrue(linkedWithCoords.isGoogleLocation)

        val url = linkedWithCoords.effectiveMapUrl
        assertNotNull(url)
        assertEquals("https://www.google.com/maps/search/?api=1&query=37.422,-122.084", url)
        assertFalse("Effective map URL must not use place name", url!!.contains("Googleplex"))
        assertFalse("Effective map URL must not use address text", url.contains("Amphitheatre"))

        // Tag saved using web link containing place name in URL: must parse and use only coordinates
        val linkedWithWebLink = QrTagEntity(
            serialNumber = "LOC-0003-CCC",
            token = "tkn_3",
            status = QrTagEntity.STATUS_LINKED_LOCATION,
            title = "Tokyo Station Central",
            destinationUrl = "https://www.google.com/maps/place/Tokyo+Station/@35.6812,139.7671,17z"
        )
        val webLinkMapUrl = linkedWithWebLink.effectiveMapUrl
        assertNotNull(webLinkMapUrl)
        assertEquals("https://www.google.com/maps/search/?api=1&query=35.6812,139.7671", webLinkMapUrl)
        assertFalse("Effective map URL must not contain Tokyo Station name", webLinkMapUrl!!.contains("Tokyo"))
    }

    @Test
    fun testQrCodeBitmapGeneration() {
        val serialPayload = SerialGenerator.buildQrPayload("TR-8421-MPK")
        val matrix = QrCodeGenerator.encodeQrMatrix(serialPayload, size = 640)
        assertTrue(matrix.width >= 640)
        assertTrue(matrix.height >= 640)
        var hasDarkModule = false
        var hasLightModule = false
        for (y in 0 until matrix.height) {
            for (x in 0 until matrix.width) {
                if (matrix.get(x, y)) hasDarkModule = true else hasLightModule = true
                if (hasDarkModule && hasLightModule) break
            }
            if (hasDarkModule && hasLightModule) break
        }
        assertTrue("QR BitMatrix must contain dark modules", hasDarkModule)
        assertTrue("QR BitMatrix must contain light modules", hasLightModule)

        // Blank content and tiny size must never throw ZXing IllegalArgumentException
        val fallbackMatrix = QrCodeGenerator.encodeQrMatrix("   ", size = 0)
        assertEquals(64, fallbackMatrix.width)
        assertEquals(64, fallbackMatrix.height)

        try {
            val bitmap = QrCodeGenerator.generateQrBitmap(serialPayload, size = 640)
            assertNotNull(bitmap)
        } catch (e: IllegalArgumentException) {
            fail("Shop serial QR encoding threw IllegalArgumentException: ${e.message}")
        } catch (_: NullPointerException) {
            // Android Bitmap.createBitmap returns null on host JVM when unitTests.isReturnDefaultValues = true
        } catch (_: RuntimeException) {
            // Android Bitmap.createBitmap is stubbed on standard JVM when running outside device
        }
    }

    @Test
    fun testWhatsAppPhoneNumberCleaning() {
        val phone1 = "+1 (650) 555-1234"
        assertEquals("16505551234", com.example.util.WhatsAppHelper.cleanPhoneNumber(phone1))

        val phone2 = "+91 98765-43210"
        assertEquals("919876543210", com.example.util.WhatsAppHelper.cleanPhoneNumber(phone2))

        val phone3 = "0123 456 789"
        assertEquals("0123456789", com.example.util.WhatsAppHelper.cleanPhoneNumber(phone3))
    }

    @Test
    fun testQrTagEntityContactProperties() {
        val tagWithoutContact = QrTagEntity(
            serialNumber = "LOC-1111-AAA",
            token = "tkn_1",
            contactPhone = null
        )
        assertFalse(tagWithoutContact.hasContact)

        val tagWithContact = QrTagEntity(
            serialNumber = "LOC-2222-BBB",
            token = "tkn_2",
            contactName = "Alice Manager",
            contactPhone = "+1 650 555 9999"
        )
        assertTrue(tagWithContact.hasContact)
        assertEquals("Alice Manager", tagWithContact.contactName)
        assertEquals("+1 650 555 9999", tagWithContact.contactPhone)
    }

    @Test
    fun testGoogleReviewLinkHelperPlaceId() = kotlinx.coroutines.runBlocking {
        val placeId = "ChIJN1t_tDeuEmsRUsoyG83frY4"
        val result = com.example.util.GoogleReviewLinkHelper.generateDirectReviewLink(placeId)
        assertEquals("https://www.google.com/maps/place/?q=place_id:ChIJN1t_tDeuEmsRUsoyG83frY4&action=openreviews", result.googleMapsReviewUrl)
        assertTrue(result.googleMapsReviewUrl.contains("action=openreviews"))
        assertEquals("https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4", result.writeReviewUrl)
    }

    @Test
    fun testGoogleReviewLinkHelperCid() = kotlinx.coroutines.runBlocking {
        val cid = "17933482747120308192"
        val result = com.example.util.GoogleReviewLinkHelper.generateDirectReviewLink(cid)
        assertEquals("https://maps.google.com/?cid=17933482747120308192&action=openreviews", result.googleMapsReviewUrl)
        assertTrue(result.googleMapsReviewUrl.contains("action=openreviews"))
    }

    @Test
    fun testGoogleReviewTabConversionWith9m11b1() {
        // Screenshot 2 Overview URL converted to Screenshot 1 Reviews Tab URL
        val overviewUrl = "https://www.google.com/maps/place/Chahat+Sweets+And+Namkeen/@23.2686941,77.4574795,21z/data=!4m6!3m5!1s0x397c69e557517a07:0xc2b5be90a7626ffe!8m2!3d23.2686216!4d77.4575353!16s%2Fg%2F11csqlt1x6?entry=ttu"
        val reviewTabUrl = com.example.util.GoogleReviewLinkHelper.convertToGoogleMapsReviewTabUrl(overviewUrl)

        assertTrue("Must inject !9m1!1b1 into data protobuf", reviewTabUrl.contains("!9m1!1b1"))
        assertTrue("Must contain action=openreviews", reviewTabUrl.contains("action=openreviews"))
        assertTrue("Must preserve place name", reviewTabUrl.contains("Chahat+Sweets+And+Namkeen"))
    }

    @Test
    fun testQrTagEntityInstagramAndNfcChannels() {
        val tagWithSocial = QrTagEntity(
            serialNumber = "TR-8421-MPK",
            token = "tkn_social",
            status = QrTagEntity.STATUS_LINKED_LOCATION,
            title = "Urban Cafe",
            instagramHandle = "@urbancafe_official",
            whatsappNumber = "+91 98765 43210",
            nfcLinked = true,
            nfcTagUid = "04A1B2C3D4"
        )

        assertTrue(tagWithSocial.hasInstagram)
        assertEquals("https://instagram.com/urbancafe_official", tagWithSocial.effectiveInstagramUrl)
        assertEquals("https://wa.me/919876543210", tagWithSocial.effectiveWhatsAppChatUrl)
        assertTrue(tagWithSocial.nfcLinked)
        assertEquals("04A1B2C3D4", tagWithSocial.nfcTagUid)
    }

    @Test
    fun testNfcAndQrShareExactSamePayload() {
        val serial = "TR-8421-MPK"
        val qrPayload = SerialGenerator.buildQrPayload(serial)
        val nfcPayload = com.example.util.NfcLinkingHelper.buildNfcPayload(serial)

        assertEquals("Both QR Code and NFC Tag must open the exact same URL", qrPayload, nfcPayload)
        assertEquals("https://qr-redirector-xb5h.onrender.com/r/TR-8421-MPK", nfcPayload)
    }

    @Test
    fun testDirectWriteReviewFromGoogleMapsUrl() {
        // Place URL without ChIJ Place ID converts cleanly to Reviews Tab (!9m1!1b1) rather than desktop-only #lrd search
        val mapsUrl = "https://www.google.com/maps/place/Chahat+Sweets+And+Namkeen/@23.2686941,77.4574795,21z/data=!4m6!3m5!1s0x397c69e557517a07:0xc2b5be90a7626ffe!8m2!3d23.2686216!4d77.4575353!16s%2Fg%2F11csqlt1x6?entry=ttu"
        val reviewTabUrl = com.example.util.GoogleReviewLinkHelper.getDirectWriteReviewUrl(mapsUrl, "Chahat Sweets And Namkeen")

        assertTrue("Must inject !9m1!1b1 for Reviews tab", reviewTabUrl.contains("!9m1!1b1"))
        assertTrue("Must include action=openreviews", reviewTabUrl.contains("action=openreviews"))

        // Place ID input must generate official search.google.com/local/writereview link
        val placeIdUrl = com.example.util.GoogleReviewLinkHelper.getDirectWriteReviewUrl("ChIJN1t_tDeuEmsRUsoyG83frY4")
        assertEquals("https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4", placeIdUrl)
    }

    @Test
    fun testNfcWritingStateMachine() {
        val serial = "TR-9900-ABC"
        val url = "https://qr-redirector-xb5h.onrender.com/r/$serial"

        com.example.util.NfcLinkingHelper.startWaitingForTag(serial, url)
        assertTrue(com.example.util.NfcLinkingHelper.isWaitingForTag)
        assertEquals(serial, com.example.util.NfcLinkingHelper.pendingSerial)
        assertEquals(url, com.example.util.NfcLinkingHelper.pendingPayload)

        // Simulate write completion
        val tagInfo = com.example.util.NfcLinkingHelper.simulateTagWrite(serial, url)
        assertFalse(com.example.util.NfcLinkingHelper.isWaitingForTag)
        assertEquals(serial, tagInfo.serialNumber)
        assertEquals(url, tagInfo.payloadUrl)
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.Success)

        com.example.util.NfcLinkingHelper.resetWriteState()
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.Idle)
    }

    @Test
    fun testRatingThresholdRuleOverNine() {
        // Total score > 9 (10..15) redirects directly to Google Reviews; <= 9 (3..9) captures complaint
        assertFalse(com.example.data.ReviewStandRepository.shouldRedirectToGoogleReview(3, 3, 3)) // 9 -> complaint
        assertFalse(com.example.data.ReviewStandRepository.shouldRedirectToGoogleReview(1, 2, 3)) // 6 -> complaint
        assertTrue(com.example.data.ReviewStandRepository.shouldRedirectToGoogleReview(4, 3, 3))  // 10 -> Google redirect
        assertTrue(com.example.data.ReviewStandRepository.shouldRedirectToGoogleReview(5, 5, 5))  // 15 -> Google redirect
    }

    @Test
    fun testStandSlugCleaningAndQrUrl() {
        assertEquals("stand2", com.example.data.ReviewStandRepository.cleanSlug(" Stand 2 "))
        assertEquals(
            "https://qr-redirector-xb5h.onrender.com/r/stand2",
            com.example.data.ReviewStandRepository.buildStandQrUrl("Stand 2", "https://qr-redirector-xb5h.onrender.com")
        )
    }

    @Test
    fun testStandSlugExtractionFromUri() {
        assertEquals(
            "chahat2",
            com.example.data.ReviewStandRepository.extractStandSlugFromUri("https://example.com/?s=Chahat2")
        )
        assertEquals(
            "stand9",
            com.example.data.ReviewStandRepository.extractStandSlugFromUri("https://example.com/?qr_id=stand9")
        )
        assertEquals(
            "stand5",
            com.example.data.ReviewStandRepository.extractStandSlugFromUri("https://qr-redirector-xb5h.onrender.com/r/stand5")
        )
    }

    @Test
    fun testConfiguredDirectoryOperatorCheck() {
        assertTrue(
            com.example.data.ReviewStandRepository.isConfiguredDirectoryOperator(
                email = "Master@Gmail.com",
                configuredAdminEmail = "master@gmail.com"
            )
        )
        assertFalse(
            com.example.data.ReviewStandRepository.isConfiguredDirectoryOperator(
                email = "shopowner@gmail.com",
                configuredAdminEmail = "master@gmail.com"
            )
        )
        assertFalse(
            com.example.data.ReviewStandRepository.isConfiguredDirectoryOperator(
                email = "YOUR_MASTER_EMAIL@gmail.com",
                configuredAdminEmail = "YOUR_MASTER_EMAIL@gmail.com"
            )
        )
    }

    @Test
    fun testOwnerLocalLedgerIsolation() {
        val chahatLinked = QrTagEntity(
            serialNumber = "TR-8421-MPK",
            token = "tkn_1",
            status = QrTagEntity.STATUS_LINKED,
            shopName = "Chahat Sweets & Namkeen",
            operatorName = "owner@chahatsweets.com",
            moneyReceived = 600.0
        )
        val chahatUnlinked = QrTagEntity(
            serialNumber = "TR-4821-KMP",
            token = "tkn_2",
            status = QrTagEntity.STATUS_UNLINKED,
            operatorName = "owner@chahatsweets.com"
        )
        val urbanLinked = QrTagEntity(
            serialNumber = "TR-7102-URB",
            token = "tkn_3",
            status = QrTagEntity.STATUS_LINKED,
            shopName = "Urban Roasters Coffee",
            operatorName = "owner@urbanroasters.com",
            moneyReceived = 900.0
        )

        val scopedForChahat = com.example.data.ReviewStandRepository.filterTagsForOwner(
            tags = listOf(chahatLinked, chahatUnlinked, urbanLinked),
            ownerEmail = "Owner@ChahatSweets.com",
            ownerStandShopNames = setOf("Chahat Sweets & Namkeen")
        )

        assertEquals(2, scopedForChahat.size)
        assertTrue(scopedForChahat.any { it.serialNumber == "TR-8421-MPK" })
        assertTrue(scopedForChahat.any { it.serialNumber == "TR-4821-KMP" })
        assertFalse("Shop owner must never see another owner's ledger entry", scopedForChahat.any { it.serialNumber == "TR-7102-URB" })
    }

    @Test
    fun testModernGoogleMapsWriteReviewModalLinks() = kotlinx.coroutines.runBlocking {
        // 1. Modern query_place_id Maps search link -> official Write Review modal URL
        val queryPlaceIdLink = "https://www.google.com/maps/search/?api=1&query=Urban+Roasters&query_place_id=ChIJN1t_tDeuEmsRUsoyG83frY4"
        val pidResult = com.example.util.GoogleReviewLinkHelper.generateDirectReviewLink(queryPlaceIdLink)
        assertTrue(pidResult.opensWriteReviewModal)
        assertEquals("https://search.google.com/local/writereview?placeid=ChIJN1t_tDeuEmsRUsoyG83frY4", pidResult.directReviewUrl)

        // 2. Modern Google Maps Place URL with hex FTID -> generates mobile Write-Review modal link (#lrd=...,3,,, or writereview)
        val placeHexUrl = "https://www.google.com/maps/place/Chahat+Sweets+And+Namkeen/@23.2686941,77.4574795,21z/data=!4m6!3m5!1s0x397c69e557517a07:0xc2b5be90a7626ffe!8m2!3d23.2686216!4d77.4575353!16s%2Fg%2F11csqlt1x6?entry=ttu"
        val hexResult = com.example.util.GoogleReviewLinkHelper.generateDirectReviewLink(placeHexUrl)
        assertTrue("Modern place URL must open Write Review modal", hexResult.opensWriteReviewModal)
        assertTrue(
            "Direct review URL should target #lrd=...,3 or writereview?placeid=",
            hexResult.directReviewUrl.contains("#lrd=0x397c69e557517a07:0xc2b5be90a7626ffe,3") ||
                hexResult.directReviewUrl.contains("search.google.com/local/writereview?placeid=")
        )

        // 3. Modern g.page link -> appends /review dialog
        val gPageResult = com.example.util.GoogleReviewLinkHelper.generateDirectReviewLink("https://g.page/urban-roasters")
        assertTrue(gPageResult.opensWriteReviewModal)
        assertEquals("https://g.page/urban-roasters/review", gPageResult.directReviewUrl)
    }

    @Test
    fun testUniqueSerialBatchGenerationUniqueness() {
        val batch = (1..10).map { SerialGenerator.generateSerial("SHOP-") }
        assertEquals(10, batch.toSet().size)
        batch.forEach { serial ->
            assertTrue(serial.startsWith("SHOP-"))
            val url = SerialGenerator.buildQrPayload(serial)
            assertEquals("https://qr-redirector-xb5h.onrender.com/r/$serial", url)
        }
    }

    @Test
    fun testResolverPreviewQrMatrixGeneration() = kotlinx.coroutines.runBlocking {
        val resolved = com.example.util.GoogleReviewLinkHelper.generateDirectReviewLink(
            "https://www.google.com/maps/search/?api=1&query=Urban+Roasters&query_place_id=ChIJN1t_tDeuEmsRUsoyG83frY4"
        )
        val qrTarget = resolved.writeReviewUrl?.takeIf { it.isNotBlank() } ?: resolved.directReviewUrl
        assertTrue(qrTarget.startsWith("https://"))

        val matrix = QrCodeGenerator.encodeQrMatrix(qrTarget, size = 512)
        assertTrue(matrix.width >= 512)
        assertTrue(matrix.height >= 512)
    }

    @Test
    fun testOwnerReviewMinimalFields() {
        val now = 1763424000000L
        val log = com.example.data.local.FeedbackLogEntity(
            id = "rev_1",
            standSlug = "stand7",
            shopName = "Chahat Sweets",
            totalScore = 6,
            customerComment = "Counter queue moved slowly during rush hour.",
            customerPhone = "+919999999999",
            createdAt = now
        )
        assertEquals("stand7", log.standSlug)
        assertEquals("Counter queue moved slowly during rush hour.", log.customerComment)
        assertEquals(now, log.createdAt)
    }

    @Test
    fun testShopOwnerNameDisplayAndFallback() {
        val registeredStand = com.example.data.local.QrStandEntity(
            standSlug = "stand10",
            shopName = "Sunrise Bakery",
            ownerEmail = "owner@sunrisebakery.com",
            googleReviewUrl = "https://search.google.com/local/writereview?placeid=abc",
            ownerName = "Rahul Sharma"
        )
        assertEquals("Rahul Sharma", registeredStand.displayOwnerName)

        val emailDerivedStand = com.example.data.local.QrStandEntity(
            standSlug = "stand11",
            shopName = "Bistro 24",
            ownerEmail = "priya.verma@bistro24.com",
            googleReviewUrl = "https://search.google.com/local/writereview?placeid=xyz",
            ownerName = ""
        )
        assertEquals("Priya Verma", emailDerivedStand.displayOwnerName)

        val genericEmailNoName = com.example.data.local.QrStandEntity(
            standSlug = "stand12",
            shopName = "Corner Tea",
            ownerEmail = "owner@cornertea.com",
            googleReviewUrl = "https://search.google.com/local/writereview?placeid=xyz",
            ownerName = ""
        )
        assertEquals("", genericEmailNoName.displayOwnerName)
    }

    @Test
    fun testPositiveAiPresetMessageGeneration() {
        val stand = com.example.data.local.QrStandEntity(
            standSlug = "stand1",
            shopName = "Chahat Sweets & Namkeen",
            ownerEmail = "owner@chahatsweets.com",
            googleReviewUrl = "https://search.google.com/local/writereview?placeid=abc",
            ownerName = "Chahat Gupta"
        )

        val warmMsg = com.example.util.PositiveReviewPresetHelper.buildPreset(
            stand,
            com.example.util.PositivePresetTone.WARM
        )
        assertTrue(warmMsg.contains("Chahat Sweets & Namkeen"))
        assertTrue(warmMsg.contains("Chahat Gupta"))

        val shortMsg = com.example.util.PositiveReviewPresetHelper.buildPreset(
            stand,
            com.example.util.PositivePresetTone.SHORT
        )
        assertTrue(shortMsg.contains("Chahat Sweets & Namkeen"))

        val detailedMsg = com.example.util.PositiveReviewPresetHelper.buildPreset(
            stand,
            com.example.util.PositivePresetTone.DETAILED
        )
        assertTrue(detailedMsg.contains("Chahat Sweets & Namkeen"))
        assertTrue(detailedMsg.contains("Chahat Gupta"))

        // Auto-copy & redirect occurs only when sum > 9
        assertTrue(com.example.data.ReviewStandRepository.shouldRedirectToGoogleReview(4, 3, 3))
        assertFalse(com.example.data.ReviewStandRepository.shouldRedirectToGoogleReview(3, 3, 3))
    }

    @Test
    fun testOwnerAgeAndParentalConsentValidation() {
        // Adult (below-18 checkbox unchecked) passes without parental consent fields
        val adultResult = com.example.util.OwnerRegistrationValidator.validate(
            isBelow18 = false,
            parentGuardianName = "",
            parentConsentChecked = false
        )
        assertTrue(adultResult.isValid)
        assertFalse(adultResult.isBelow18)
        assertFalse(adultResult.requiresParentalConsent)

        // Below-18 checked without parent/guardian name fails
        val missingParentName = com.example.util.OwnerRegistrationValidator.validate(
            isBelow18 = true,
            parentGuardianName = "",
            parentConsentChecked = true
        )
        assertFalse(missingParentName.isValid)
        assertTrue(missingParentName.isBelow18)
        assertTrue(missingParentName.requiresParentalConsent)

        // Below-18 checked without parental consent checkbox fails
        val missingConsentCheck = com.example.util.OwnerRegistrationValidator.validate(
            isBelow18 = true,
            parentGuardianName = "Rajesh Sharma",
            parentConsentChecked = false
        )
        assertFalse(missingConsentCheck.isValid)
        assertTrue(missingConsentCheck.requiresParentalConsent)

        // Below-18 checked with both guardian name and consent checkbox succeeds
        val minorWithConsent = com.example.util.OwnerRegistrationValidator.validate(
            isBelow18 = true,
            parentGuardianName = "Rajesh Sharma",
            parentConsentChecked = true
        )
        assertTrue(minorWithConsent.isValid)
        assertTrue(minorWithConsent.isBelow18)
        assertTrue(minorWithConsent.requiresParentalConsent)
    }

    @Test
    fun testTwoOtpAccountDeletionValidation() {
        // Short OTP rejected on Step 1
        val shortOtp = com.example.data.ReviewStandRepository.validateDeletionOtpInput(
            otp = "123",
            step = 1
        )
        assertTrue(shortOtp.isFailure)

        // Valid 6-digit 1st OTP accepted on Step 1
        val validStep1 = com.example.data.ReviewStandRepository.validateDeletionOtpInput(
            otp = com.example.data.ReviewStandRepository.DEMO_DELETE_OTP_1,
            step = 1
        )
        assertTrue(validStep1.isSuccess)

        // Reusing 1st OTP on Step 2 must be rejected so accidental deletion cannot bypass 2nd check
        val duplicateOtpOnStep2 = com.example.data.ReviewStandRepository.validateDeletionOtpInput(
            otp = com.example.data.ReviewStandRepository.DEMO_DELETE_OTP_1,
            step = 2,
            firstOtpUsed = com.example.data.ReviewStandRepository.DEMO_DELETE_OTP_1
        )
        assertTrue("Reusing 1st OTP on Step 2 must fail", duplicateOtpOnStep2.isFailure)

        // Distinct 2nd 6-digit OTP accepted on Step 2
        val validStep2 = com.example.data.ReviewStandRepository.validateDeletionOtpInput(
            otp = com.example.data.ReviewStandRepository.DEMO_DELETE_OTP_2,
            step = 2,
            firstOtpUsed = com.example.data.ReviewStandRepository.DEMO_DELETE_OTP_1
        )
        assertTrue(validStep2.isSuccess)
    }

    @Test
    fun testSupabaseUrlNormalizationAndInvalidPathDetection() {
        // Dashboard URL converts automatically to project API URL
        assertEquals(
            "https://abcdefghijkl.supabase.co",
            com.example.data.ReviewStandRepository.normalizeSupabaseBaseUrl(
                "https://supabase.com/dashboard/project/abcdefghijkl/editor"
            )
        )

        // URL with accidental /rest/v1 or /auth/v1 path strips path cleanly
        assertEquals(
            "https://myproject.supabase.co",
            com.example.data.ReviewStandRepository.normalizeSupabaseBaseUrl(
                " \"https://myproject.supabase.co/rest/v1/\" "
            )
        )

        // Bare domain without scheme prepends https://
        assertEquals(
            "https://myproject.supabase.co",
            com.example.data.ReviewStandRepository.normalizeSupabaseBaseUrl("myproject.supabase.co/auth/v1")
        )

        // Placeholder or bare supabase.com without project ref returns empty
        assertEquals(
            "",
            com.example.data.ReviewStandRepository.normalizeSupabaseBaseUrl("https://YOUR_PROJECT_REF.supabase.co")
        )
        assertEquals(
            "",
            com.example.data.ReviewStandRepository.normalizeSupabaseBaseUrl("https://supabase.com/dashboard")
        )

        // Invalid path detection triggers cleanly
        assertTrue(com.example.data.ReviewStandRepository.isInvalidUrlPathResponse(404, "Not Found"))
        assertTrue(
            com.example.data.ReviewStandRepository.isInvalidUrlPathResponse(
                400,
                "Invalid path specified in request URL"
            )
        )
        assertFalse(com.example.data.ReviewStandRepository.isInvalidUrlPathResponse(401, "Invalid API key"))
    }

    @Test
    fun testWriteNfcTagDynamicFeedbackUrlState() {
        val dynamicUrl = com.example.data.ReviewStandRepository.buildStandQrUrl(
            standSlug = "stand1",
            backendBaseUrl = "https://qr-redirector-xb5h.onrender.com"
        )
        assertEquals("https://qr-redirector-xb5h.onrender.com/r/stand1", dynamicUrl)

        com.example.util.NfcLinkingHelper.resetWriteState()
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.Idle)

        com.example.util.NfcLinkingHelper.startWaitingForTag("stand1", dynamicUrl)
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.WaitingForTag)

        com.example.util.NfcLinkingHelper.markReadingState("stand1", dynamicUrl, null)
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.Reading)

        com.example.util.NfcLinkingHelper.markWritingState()
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.Writing)

        val info = com.example.util.NfcLinkingHelper.simulateTagWrite("stand1", dynamicUrl)
        assertEquals(dynamicUrl, info.payloadUrl)
        assertTrue(com.example.util.NfcLinkingHelper.writeState.value is com.example.util.NfcWriteState.Success)
    }
}



